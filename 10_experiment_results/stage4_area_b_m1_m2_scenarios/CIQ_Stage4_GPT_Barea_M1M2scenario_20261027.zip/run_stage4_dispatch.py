#!/usr/bin/env python3
"""CIQ Stage4: paired M0/M1/M2 *hypothetical operations*.
Uses the original observed-to-project frozen synthetic orders, OSM directed routes and hourly FCD model proxies.
No regulatory clearance, hardware calibration, cost or emissions claims.  Five specified dates per seed.
Implemented without spreadsheet dependency; `python run_stage4_dispatch.py --bundle <...> --output <...>`
"""
from __future__ import annotations
import argparse,csv,gzip,io,zipfile,collections,math,datetime,json,hashlib,os
from pathlib import Path
DAYS=('2026-05-15','2026-06-15','2026-07-15','2026-08-15','2026-09-15')
P={'max_payload_kg':1.5,'drone_kph':40.0,'leg_limit_km':4.0,'sortie_limit_km':8.0,
 'rain_limit_mm_h':0.1,'gust_limit_m_s':10.0,'daylight_start_hour':6,'daylight_end_hour_exclusive':19,
 'ground_vehicles_per_origin':2,'drones_per_hub':2,'package_prep_min':2.0,'ground_unload_min':2.0,
 'hub_handling_min':3.0,'launch_min':1.5,'drone_drop_min':1.5,'drone_recover_min':1.5,
 'recharge_min':20.0,'ground_feeder_handoff_min':2.0,'vehicle_return_proxy':'directed_reverse_else_assume_outbound',
 'm2_batch_window_min':30.0}
HUBS={'A':('A01','A02','A03','A05'),'B':('B01','B02','B07')}
M2_LAUNCH={'A':('A01','A02','A03','A05'),'B':('B01','B02','B07')}

def hav(x,y):
 a,b=x;c,d=y; ap,bp=map(math.radians,(a,c)); dp=bp-ap;dl=math.radians(d-b)
 return 12742.0176*math.asin(math.sqrt(math.sin(dp/2)**2+math.cos(ap)*math.cos(bp)*math.sin(dl/2)**2))

def csvb(b):return list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'))))
def output_csv(path,rows,fields):
 with open(path,'w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

def data_read(bundle):
 with zipfile.ZipFile(bundle) as z:
  def contents(suffix):
   matches=[x for x in z.namelist() if x.endswith(suffix)]
   assert len(matches)==1,(suffix,matches)
   return z.read(matches[0])
  sites={r['site_id']:r for r in csvb(contents('19_site_reference_anchors_NOT_LAUNCH_PADS.csv'))}
  xy={s:(float(r['latitude']),float(r['longitude'])) for s,r in sites.items()}
  od={}
  for a in ('A','B'):
   for r in csvb(contents('E02_'+a+'_OD_OSM_MODEL_NOT_OBSERVED.csv')):
    if r['OSM_only_minutes_MODEL'] and r['route_length_km']:
     od[(r['origin_id'],r['destination_id'])]=(float(r['OSM_only_minutes_MODEL']),float(r['route_length_km']))
  traffic={}
  for r in csvb(contents('01_AB_24h_hourly_joint.csv')):
   key=(r['area'],r['timestamp_local_hour'][:13]);v=r['median_ratio_to_dev_P90']
   if v:traffic[key]=(float(v),r['passes_70pct_fcd_speed']=='1',float(r['ERA5_precip_mm_hour']),float(r['ERA5_gust10_ms']))
  nested=zipfile.ZipFile(io.BytesIO(contents('JB_CIQ_E05_V5.6_30次重复订单_全天交通天气稳健性_完整归档.zip')))
  picks=sorted(x for x in nested.namelist() if x.endswith('_orders.csv.gz'))
  assert len(picks)==30
  groups=collections.defaultdict(list)
  dayset=set(DAYS)
  for name in picks:
   with gzip.GzipFile(fileobj=io.BytesIO(nested.read(name))) as f:
    reader=csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig'))
    for row in reader:
     day=row['release_time_local'][:10]
     if day not in dayset:continue
     row['release_min']=int(row['release_time_local'][11:13])*60+int(row['release_time_local'][14:16])+int(row['release_time_local'][17:19])/60
     row['payload']=float(row['parcel_kg'])
     groups[(int(row['replicate_seed']),day,row['area'])].append(row)
  for group in groups.values():group.sort(key=lambda x:(x['release_min'],x['replicate_order_id']))
  return xy,od,traffic,groups

def road_time(s,t,clock,day,area,od,traffic):
 if s==t:return (0.,0.,False)
 stamp=(datetime.datetime.fromisoformat(day)+datetime.timedelta(minutes=float(clock))).strftime('%Y-%m-%d %H')
 q=od.get((s,t));v=traffic.get((area,stamp))
 if q is None or v is None or not v[1] or v[0]<=0:return None
 return (q[0]/v[0],q[1],False)

def return_time(s,t,clock,day,area,od,traffic,outbound):
 if s==t:return (0,False)
 real=road_time(s,t,clock,day,area,od,traffic)
 if real is not None:return (real[0],False)
 return (outbound,True)

def flight_window(area,day,clock,traffic):
 if clock<0 or clock>=1440:return False
 hr=int(clock//60)
 if not(P['daylight_start_hour']<=hr<P['daylight_end_hour_exclusive']):return False
 w=traffic.get((area,day+' '+f'{hr:02d}'))
 return bool(w and w[2]<P['rain_limit_mm_h'] and w[3]<P['gust_limit_m_s'])

def eligibility(o):
 return o['payload']<=P['max_payload_kg'] and float(o['era5_rain_mm_h'])<P['rain_limit_mm_h'] and float(o['era5_gust10_ms'])<P['gust_limit_m_s'] and P['daylight_start_hour']<=int(o['release_time_local'][11:13])<P['daylight_end_hour_exclusive']

def common(o,mode,code='',complete=None,route=0,flight=0,wait=0,hub='',paired='',sym=False,sortie=0,vehicle_work=0,drone_work=0):
 return {'seed':o['replicate_seed'],'date':o['release_time_local'][:10],'area':o['area'],
 'demand_class':o['demand_class'],'order_id':o['replicate_order_id'],'mode':mode,
 'origin_site_id':o['origin_site_id'],'destination_site_id':o['destination_site_id'],
 'release_time_local':o['release_time_local'],'parcel_kg':o['parcel_kg'],
 'status':code,'completion_min_from_midnight':round(complete,5) if complete is not None else '',
 'door_to_door_min':round(complete-o['release_min'],5) if complete is not None else '',
 'ground_vehicle_km':round(route,5),'drone_km':round(flight,5),
 'queue_wait_min':round(wait,5),'hub_or_launch_site':hub,'paired_order_id':paired,
 'used_unverified_reverse_proxy':int(sym),'flight_sortie_flag':sortie,
 'ground_resource_occupied_min':round(vehicle_work,5),'drone_resource_occupied_min':round(drone_work,5),
 'cost_MYR':'','CO2e_kg':'','validation_label':'HYPOTHETICAL_DISPATCH_UNVALIDATED_NO_UAV_PERMIT'}

def vnext(pool,origin,at):
 i=min(range(len(pool[origin])),key=lambda j:pool[origin][j]);return i,max(at,pool[origin][i])

def dispatch_ground(o,mode,pool,day,od,traffic,label='GROUND',other=''):
 origin=o['origin_site_id'];dest=o['destination_site_id'];a=o['area'];r=o['release_min']
 # direct road proxy (FCD>=70%) is required for physical path/time and must not be synthesized
 v=road_time(origin,dest,r,day,a,od,traffic)
 if v is None:
  return common(o,mode,'ROAD_PROXY_UNAVAILABLE',hub=other)
 idx,avail=vnext(pool,origin,r)
 depart=avail+P['package_prep_min'];out=road_time(origin,dest,depart,day,a,od,traffic)
 if out is None:return common(o,mode,'TRAFFIC_PROXY_UNAVAILABLE_AT_DISPATCH')
 arrive=depart+out[0];complete=arrive+P['ground_unload_min']
 ret,sym=return_time(dest,origin,complete,day,a,od,traffic,out[0])
 pool[origin][idx]=complete+ret
 return common(o,mode,label if not sym else label+'_RETURN_PROXY_ASSUMED',complete,route=out[1]*2 if sym else out[1]+(od.get((dest,origin),(0,out[1]))[1]),wait=avail-r,sym=sym,vehicle_work=pool[origin][idx]-avail)

def create_pool(rows):
 return {src:[0.0]*P['ground_vehicles_per_origin'] for src in set(o['origin_site_id'] for o in rows)}

def simulate_m0(rows,day,od,traffic):
 pool=create_pool(rows)
 return [dispatch_ground(o,'M0',pool,day,od,traffic) for o in rows]

def simulate_m1(rows,day,xy,od,traffic):
 pool=create_pool(rows)
 drones={hub:[0.0]*P['drones_per_hub'] for hub in HUBS[rows[0]['area']]}
 result=[]
 for o in rows:
  origin=o['origin_site_id'];dest=o['destination_site_id'];a=o['area'];r=o['release_min']; choice=[]
  if eligibility(o):
   for h in HUBS[a]:
    dm=hav(xy[h],xy[dest]);rt=2*dm
    if dm>P['leg_limit_km'] or rt>P['sortie_limit_km']:continue
    feeder=road_time(origin,h,r,day,a,od,traffic)
    if feeder is None:continue
    # predicted package arrival using shared ground vehicles, drone earliest available resource
    if origin==h:
     ix=-1  # Inventory already at a hypothetical hub: no vehicle or feeder trip is consumed.
     t=r
     feeder_finish=r+P['package_prep_min']
    else:
     ix,t=vnext(pool,origin,r)
     feeder_finish=t+P['package_prep_min']+feeder[0]+P['ground_feeder_handoff_min']
    arr=feeder_finish+P['hub_handling_min']
    j=min(range(P['drones_per_hub']),key=lambda k:drones[h][k])
    launch=max(arr,drones[h][j]); flight=dm/P['drone_kph']*60
    if not flight_window(a,day,launch,traffic):continue
    delivered=launch+P['launch_min']+flight+P['drone_drop_min']
    choice.append((delivered,h,ix,feeder,feeder_finish,launch,j,dm,t))
  if not choice:
   out=dispatch_ground(o,'M1',pool,day,od,traffic,label='GROUND_FALLBACK')
   result.append(out);continue
  delivered,h,ix,feeder,feeder_finish,launch,j,dm,t=min(choice,key=lambda k:(k[0],k[1]))
  # Source to hub feeder uses ground van and its own return to source. No free inventory at hub.
  if ix==-1:
   sym=False;rd=0.;vehicle_work=0.
  else:
   ret,sym=return_time(h,origin,feeder_finish,day,a,od,traffic,feeder[0]);pool[origin][ix]=feeder_finish+ret
   rd=(feeder[1]*2 if sym else feeder[1]+od.get((h,origin),(0,feeder[1]))[1]);vehicle_work=pool[origin][ix]-t
  flight=dm/P['drone_kph']*60
  drone_end=delivered+flight+P['drone_recover_min']+P['recharge_min']
  drones[h][j]=drone_end
  result.append(common(o,'M1','DRONE_HUB_HYPOTHETICAL',delivered,rd,2*dm,wait=t-r+max(0,launch-(feeder_finish+P['hub_handling_min'])),hub=h,sym=sym,sortie=1,vehicle_work=vehicle_work,drone_work=drone_end-launch))
 return result

def m2_candidate(o,p,day,xy,od,traffic):
 if not eligibility(o) or not eligibility(p) or o['origin_site_id']!=p['origin_site_id']:return None
 a=o['area'];origin=o['origin_site_id'];d1=o['destination_site_id'];d2=p['destination_site_id'];start=max(o['release_min'],p['release_min'])
 best=None
 for site in dict.fromkeys((origin,)+M2_LAUNCH[a]):
  # truck needs directed OSM connection to launch and rendezvous customer stop
  t1=road_time(origin,site,start,day,a,od,traffic)
  t2=road_time(site,d2,start+(t1[0] if t1 else 0),day,a,od,traffic) if t1 is not None else None
  if t1 is None or t2 is None:continue
  d_air_1=hav(xy[site],xy[d1]);d_air_2=hav(xy[d1],xy[d2]);dist=d_air_1+d_air_2
  if d_air_1>P['leg_limit_km'] or d_air_2>P['leg_limit_km'] or dist>P['sortie_limit_km']:continue
  if road_time(d2,origin,start+t1[0]+t2[0],day,a,od,traffic) is None:
   # return unknown may be represented in scenario as symmetric proxy and is explicitly marked
   pass
  predicted=max(t1[0]+t2[0],t1[0]+P['launch_min']+dist/P['drone_kph']*60+P['drone_drop_min']+P['drone_recover_min'])
  k=(predicted,site,d_air_1,d_air_2,t1,t2)
  if best is None or k[0]<best[0]:best=k
 return best

def simulate_m2(rows,day,xy,od,traffic):
 pool=create_pool(rows); used=set();result=[]
 # Pairing window by origin with future orders: real truck awaits both released; actual waiting included
 buckets=collections.defaultdict(list)
 for i,o in enumerate(rows):buckets[o['origin_site_id']].append(i)
 for i,o in enumerate(rows):
  if i in used:continue
  o_start=o['release_min']; opts=[]
  if eligibility(o):
   for j in buckets[o['origin_site_id']]:
    if j<=i or j in used:continue
    p=rows[j]
    if p['release_min']-o_start>P['m2_batch_window_min']:break
    can=m2_candidate(o,p,day,xy,od,traffic)
    if can is not None:
     opts.append((can[0],j,can))
  if not opts:
   result.append(dispatch_ground(o,'M2',pool,day,od,traffic,label='GROUND_SINGLE'));used.add(i);continue
  _,j,(pred,site,d1,d2,l1,l2)=min(opts,key=lambda x:(x[0],x[1]));p=rows[j]
  r=max(o['release_min'],p['release_min']);origin=o['origin_site_id'];a=o['area'];dst2=p['destination_site_id']
  ix,ready=vnext(pool,origin,r);start=ready+2*P['package_prep_min']
  # recompute planned legs from actual departure hour; if unavailable, revert to single dispatch
  leg1=road_time(origin,site,start,day,a,od,traffic)
  if leg1 is None:
   result.append(dispatch_ground(o,'M2',pool,day,od,traffic,'GROUND_SINGLE'));used.add(i);continue
  launch_at=start+leg1[0]
  leg2=road_time(site,dst2,launch_at,day,a,od,traffic)
  if leg2 is None or not flight_window(a,day,launch_at,traffic):
   result.append(dispatch_ground(o,'M2',pool,day,od,traffic,'GROUND_SINGLE'));used.add(i);continue
  uav_delivery=launch_at+P['launch_min']+d1/P['drone_kph']*60+P['drone_drop_min']
  uav_arrive_rv=uav_delivery+d2/P['drone_kph']*60+P['drone_recover_min']
  truck_delivery=launch_at+leg2[0]+P['ground_unload_min']
  truck_depart=max(uav_arrive_rv,truck_delivery)
  ret,sym=return_time(dst2,origin,truck_depart,day,a,od,traffic,leg1[0]+leg2[0])
  pool[origin][ix]=truck_depart+ret+P['recharge_min'] # single onboard drone recharge, occupies that vehicle
  rd=leg1[1]+leg2[1]+(leg1[1]+leg2[1] if sym else od.get((dst2,origin),(0,leg1[1]+leg2[1]))[1])
  pair_label='DRONE_TRUCK_RENDEZVOUS_HYPOTHETICAL'
  result.append(common(o,'M2',pair_label,uav_delivery,rd/2,d1+d2,wait=ready-r+(r-o_start),hub=site,paired=p['replicate_order_id'],sym=sym,sortie=1,vehicle_work=pool[origin][ix]-ready,drone_work=uav_arrive_rv-launch_at+P['recharge_min']))
  result.append(common(p,'M2','TRUCK_PARALLEL_RENDEZVOUS_HYPOTHETICAL',truck_delivery,rd/2,0.,wait=ready-r,hub=site,paired=o['replicate_order_id'],sym=sym,vehicle_work=pool[origin][ix]-ready))
  used.update((i,j))
 return result

def main(bundle,output):
 out=Path(output);out.mkdir(parents=True,exist_ok=True)
 xy,od,traffic,groups=data_read(bundle)
 orderf=out/'stage4_paired_orders.csv.gz';aggregate=[];sample=[];tot=collections.Counter()
 columns=['seed','date','area','demand_class','order_id','mode','origin_site_id','destination_site_id','release_time_local','parcel_kg','status','completion_min_from_midnight','door_to_door_min','ground_vehicle_km','drone_km','queue_wait_min','hub_or_launch_site','paired_order_id','used_unverified_reverse_proxy','flight_sortie_flag','ground_resource_occupied_min','drone_resource_occupied_min','cost_MYR','CO2e_kg','validation_label']
 with gzip.open(orderf,'wt',encoding='utf-8-sig',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
  for (seed,day,area),rows in sorted(groups.items()):
   modes=[simulate_m0(rows,day,od,traffic),simulate_m1(rows,day,xy,od,traffic),simulate_m2(rows,day,xy,od,traffic)]
   for mode,outcomes in zip(('M0','M1','M2'),modes):
    assert len(outcomes)==len(rows),(seed,day,area,mode,len(outcomes),len(rows))
    ids=[x['order_id'] for x in outcomes];assert len(set(ids))==len(rows)
    ref={x['replicate_order_id'] for x in rows};assert set(ids)==ref
    writer.writerows(sorted(outcomes,key=lambda x:x['order_id']))
    n=len(outcomes);done=[x for x in outcomes if x['door_to_door_min']!=''];times=sorted(x['door_to_door_min'] for x in done)
    quant=lambda p:times[round((len(times)-1)*p)] if times else None
    counters=collections.Counter(x['status'].split('_')[0] for x in outcomes)
    aggregate.append({'seed':seed,'date':day,'area':area,'mode':mode,'orders':n,'completed_n':len(done),'ground_unavailable_n':n-len(done),
     'completion_rate_pct':round(100*len(done)/n,3) if n else 0,'p50_complete_min':quant(.5),'p90_complete_min':quant(.9),'p95_complete_min':quant(.95),
     'mean_completed_min':round(sum(times)/len(times),4) if times else None,
     'drone_delivered_n':sum(x['status'].startswith(('DRONE_HUB','DRONE_TRUCK')) for x in outcomes),
     'ground_delivered_n':sum(x['status'].startswith(('GROUND','TRUCK_PARALLEL')) and x['door_to_door_min']!='' for x in outcomes),
     'drone_sorties_n':sum(x['flight_sortie_flag'] for x in outcomes),
     'return_proxy_assumed_n':sum(x['used_unverified_reverse_proxy'] for x in outcomes),
     'no_legal_uav_approval':True,'scenario_only':True})
    tot[(area,mode)]+=n
    if seed==20261027 and day==DAYS[0]:sample.extend(outcomes[:8])
 assert len({(r['seed'],r['date'],r['area'],r['mode']) for r in aggregate})==len(aggregate)
 fields=list(aggregate[0])
 output_csv(out/'stage4_seed_day_mode_summary.csv',aggregate,fields)
 output_csv(out/'stage4_debug_examples.csv',sample,columns)
 # complete paired daily aggregates, not formal inferential estimates
 summary=[]
 for a in 'AB':
  for m in ('M0','M1','M2'):
   ss=[r for r in aggregate if r['area']==a and r['mode']==m]
   n=sum(x['orders'] for x in ss);d=sum(x['completed_n'] for x in ss)
   summary.append({'area':a,'mode':m,'orders':n,'completed_n':d,'completed_pct':round(100*d/n,4),
    'unavailable_n':n-d,'drone_delivered_n':sum(x['drone_delivered_n'] for x in ss),
    'drone_sorties_n':sum(x['drone_sorties_n'] for x in ss),'return_proxy_assumed_n':sum(x['return_proxy_assumed_n'] for x in ss),
    'mean_daily_median_of_completed_min':round(sum(x['p50_complete_min'] for x in ss if x['p50_complete_min'] is not None)/sum(x['p50_complete_min'] is not None for x in ss),4)})
 output_csv(out/'stage4_area_mode_summary.csv',summary,list(summary[0]))
 qa={'scenario_version':'stage4_v0.2_HYPOTHETICAL_ONLY','days':DAYS,'group_count':len(groups),'seed_count':len(set(x[0] for x in groups)),
  'orders_sampled':sum(len(x) for x in groups.values()),'total_mode_records':sum(tot.values()),
  'area_mode_counts':{a+'_'+m:tot[(a,m)] for a in 'AB' for m in ('M0','M1','M2')},
  'parameters':P,'sites_label':'HYPOTHETICAL_SEARCH_ANCHORS_UNAPPROVED',
  'major_limitations':['M0 is now origin-stationed fleet dispatch, NOT directly comparable to previous bare link-time M0.',
  'Fleet resources, air performance, launch, charging and weather thresholds are scenario assumptions, NOT measured or approved.',
  'FCD-derived proxy lacks external road calibration. Source/destination are reference centroids, not parcel addresses.',
  'M2 rendezvous works on same-origin two-order pairs only; requires directed OSM legs to launch and second delivery.',
  'Route missing -> unserved/ground unavailable, not zero travel time; reverse-leg missing -> explicit symmetric proxy flagged.',
  'No full cost/CO2e estimates until defensible parameter set is registered.',
  'Air legality, obstacles, altitude and operational authorization NOT checked; all UAV sorties conditional hypothetical.',
  'Flight launch screened with hourly ERA5 rain/gust and a fixed daylight time window; weather during in-flight minutes remains unmodelled.']}
 (out/'stage4_qa_manifest.json').write_text(json.dumps(qa,indent=2,ensure_ascii=False),encoding='utf-8')
 print(json.dumps({'QA':qa,'summary':summary},ensure_ascii=False,indent=2))
 return summary

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--bundle',default='/mnt/data/CIQ_GPT校验所需三归档与关键数据_20261027.zip');ap.add_argument('--output',default='/mnt/data/ciq_stage4_model');args=ap.parse_args();main(args.bundle,args.output)
