"""Extend Stage3 workbook without rewriting its original 9 sheets.
Uses artifact_tool (not openpyxl). All UAV-related sheets are labelled HYPOTHETICAL.
"""
import csv,json
from pathlib import Path
from artifact_tool import Blob,SpreadsheetFile
BASE=Path('/mnt/data/ciq_stage3_foundation/CIQ_RQ1_M0_stage3_20261027.xlsx')
ROOT=Path('/mnt/data/ciq_stage4_model')
TARGET=ROOT/'CIQ_RQ1_M0_B区与M1M2情景_20261027.xlsx'
w=SpreadsheetFile.import_xlsx(Blob.load(str(BASE)))
def read(n):
 with open(ROOT/n,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
area=read('stage4_area_mode_summary.csv');paired=read('stage4_paired_area_summary.csv');
seed=read('stage4_seed_day_mode_summary.csv');seedpaired=read('stage4_seed_day_paired_comparison.csv')
rq1=read('../ciq_stage3_foundation/rq1_30seed_descriptive.csv');m0=read('../ciq_stage3_foundation/m0_30seed_descriptive.csv');
site=read('../ciq_stage3_foundation/rq1_site_descriptive.csv');qa=json.loads((ROOT/'stage4_qa_manifest.json').read_text());params=qa['parameters']
BLUE='#17324E';LIGHT='#E9F2F6';WHITE='#FFFFFF';GRAY='#505F6D';WARN='#FFF3DE'

def make(name,title,head,records,widths=None):
 s=w.worksheets.add(name)
 colnum=len(head)
 s.merge_cells(f'A1:{col(colnum)}1')
 s.get_range('A1').values=[[title]]
 s.get_range(f'A1:{col(colnum)}1').format={'fill':BLUE,'font':{'bold':True,'color':WHITE,'size':14},'row_height':30,'vertical_alignment':'center'}
 s.get_range_by_indexes(2,0,1,colnum).values=[head]
 s.get_range_by_indexes(2,0,1,colnum).format={'fill':LIGHT,'font':{'bold':True,'color':BLUE},'row_height':27,'wrap_text':True}
 if records:
  s.get_range_by_indexes(3,0,len(records),colnum).values=records
  s.get_range_by_indexes(3,0,len(records),colnum).format.row_height=21
 s.freeze_panes.freeze_rows(3)
 for i,width in enumerate(widths or [17]*colnum):
  s.get_range(f'{col(i+1)}:{col(i+1)}').format.column_width=width
 return s

def col(n):
 s=''
 while n:
  n,r=divmod(n-1,26);s=chr(65+r)+s
 return s

def num(v):
 if v is None or v=='':return None
 return float(v)

def lookup(rows,a,cls):return next(r for r in rows if r['area']==a and r['demand_class']==cls)

# B zone was included in Stage 3: zero direct flight is a geometrical definition, not missing participation.
rec=[]
for a in ('A','B'):
 for cls in ('D1','D2'):
  r=lookup(rq1,a,cls);r0=lookup(m0,a,cls)
  rec.append([a,cls,num(r['mean_direct_km_mean']),num(r['direct_le3km_pct_mean']),num(r['direct_le4km_pct_mean']),
   num(r['candidate_both_le4km_pct_mean']),num(r0['proxy_coverage_pct_mean']),
   'Direct<=4 km is not a hub-to-customer or truck-rendezvous sortie'])
s=make('B_区域澄清','B 区已参与 Stage3：直接点对覆盖与转运覆盖是两种不同指标',
 ['Area','Class','平均直线 km','直飞3km %','直飞4km %','两端各落入某候选圈4km %','M0模型代理可用 %','注意事项'],rec,[11,11,18,16,16,28,23,55])
s.get_range('A10:H10').values=[['解释','B区两个订单类别的直飞4km都是0%；不等于B区无人机物流总适用率为0。','','','','','','']]
s.merge_cells('B10:H10')
s.get_range('A10:H10').format={'fill':WARN,'font':{'color':BLUE}}

# Candidate coverage, with all B anchors retained
bc=[]
for r in site:
 if r['area']=='B':bc.append([r['candidate_site_id'],int(float(r['radius_km'])),num(r['pct_dest_catchment']),num(r['count_per_seed']),'Geographic search anchor; not approved pad'])
make('B_站点参考','B 区候选地点目的地几何覆盖（不是站点许可，也不是完整可配送率）',
 ['候选点','半径 km','目的地圈覆盖 %','每种子平均订单数','地点法律状态'],bc,[19,14,23,26,59])

rr=[]
for r in area:
 rr.append([r['area'],r['mode'],int(r['orders']),int(r['completed_n']),num(r['completed_pct']),int(r['unavailable_n']),int(r['drone_delivered_n']),int(r['drone_sorties_n']),int(r['return_proxy_assumed_n']),num(r['mean_daily_median_of_completed_min'])])
s=make('M012_情景汇总','Stage4 M0/M1/M2：30种子 × 每月15日；条件性模型，不是正式RQ2',
 ['Area','Mode','订单数','完成数','完成率 %','未完成数','无人机送达','无人机航次','反向路由代理假设数','分日P50平均 min'],rr,[11,11,14,14,16,16,19,18,24,23])
# derived completion delta formula, compared against same-area M0 row
s.get_range('K3').values=[['相对M0完成率变化(百分点)']]
s.get_range('K3').format={'fill':LIGHT,'font':{'bold':True,'color':BLUE}}
s.get_range('K4:K9').formulas=[['=E4-E4'],['=E5-E4'],['=E6-E4'],['=E7-E7'],['=E8-E7'],['=E9-E7']]
s.get_range('K:K').format.column_width=27
s.get_range('A11').values=[['限制']];s.merge_cells('B11:K11');s.get_range('B11').values=[['运营资源、气象阈值与性能为假设；当前没有获批起降地点、外部标定旅行时间或成本/CO2e正式结果。']]

pairs=[]
for r in paired:
 pairs.append([r['area'],r['mode'],int(r['reference_orders']),int(r['both_completed_n']),int(r['newly_completed_n']),int(r['newly_unserved_n']),int(r['paired_better_n']),int(r['paired_slower_n']),int(r['paired_equal_n']),int(r['air_sorties_n']),num(r['paired_mean_of_group_means_min'])])
make('配对差异','相同订单ID的配对比较：完成率变化不可等同于总体节时',
 ['Area','Mode','基础订单数','双模式均完成','新增完成','新增未完成','共同完成且变快','共同完成且变慢','共同完成且不变','无人机航次','各日均值差 min'],pairs,[10,12,18,19,15,18,20,20,19,17,20])

ss=[]
for r in seed:
 ss.append([int(r['seed']),r['date'],r['area'],r['mode'],int(r['orders']),int(r['completed_n']),num(r['completion_rate_pct']),num(r['p50_complete_min']),num(r['p90_complete_min']),num(r['p95_complete_min']),int(r['drone_sorties_n'])])
make('300组分日','种子 × 月度抽样日 × 区域 × 模式：300组完整明细',
 ['Seed','Date','Area','Mode','Orders','Completed','Completed %','P50 min','P90 min','P95 min','Air sorties'],ss,[15,18,12,12,15,17,18,18,18,18,18])

assumptions=[]
for k,v in params.items():
 assumptions.append([k,str(v),'SCENARIO_ASSUMED','Not aircraft certification / not measured'])
assumptions.extend([
 ['site_permission','NOT_VERIFIED','UNKNOWN','All seven launch candidates are search areas, not approved pads'],
 ['road_time','OSM/FCD model proxy','UNCALIBRATED','Not observed door-to-door shipment time'],
 ['CIQ_wait','NONE','NOT_APPLICABLE','ODs are MY-side and do not cross border'],
 ['emissions','NOT_CALCULATED','NOT_EVALUABLE','No justified life-cycle boundary / cost allocation'],
 ['costs','NOT_CALCULATED','NOT_EVALUABLE','No price, OPEX or CAPEX amortization evidence'],
 ['B_region','INCLUDED','DATA_INCLUDED','B drone sorties require hub or launch-based multi-leg flight']])
make('运行参数_假设','Stage4 运行参数登记表：没有验证即不称为正式实测参数',
 ['Parameter','Value','Evidence class','Explanation'],assumptions,[40,27,24,73])

qrows=[[k,str(v) if not isinstance(v,(dict,list)) else json.dumps(v,ensure_ascii=False)[:130]] for k,v in json.loads((ROOT/'stage4_pairing_qa.json').read_text()).items()]
qrows.extend([['Flight permission','NOT VERIFIED'],['Operational conclusion','CONDITIONAL SCENARIO ONLY'],['Input count','29842 across 30 seeds and five specified dates'],['Source workbook','CIQ_RQ1_M0_stage3_20261027.xlsx (original 9 sheets preserved)']])
make('Stage4_QA','Stage4 配对和程序结构质量检测', ['Check','Result'],qrows,[35,105])

# Lightweight validation without affecting original sheets
check=w.inspect({'kind':'table','range':'M012_情景汇总!A3:K9','include':'values,formulas','table_max_rows':7,'table_max_cols':11})
print('CHECK',check.ndjson[:2400])
SpreadsheetFile.export_xlsx(w).save(str(TARGET))
print('SAVED',TARGET,TARGET.stat().st_size)
