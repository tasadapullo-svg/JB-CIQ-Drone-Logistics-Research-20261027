import csv,gzip,collections,json,math,statistics
from pathlib import Path
P=Path('/mnt/data/ciq_stage4_model')
rows={};modes=collections.defaultdict(lambda:collections.defaultdict(dict));
with gzip.open(P/'stage4_paired_orders.csv.gz','rt',encoding='utf-8-sig',newline='') as f:
 for x in csv.DictReader(f):
  k=(x['seed'],x['date'],x['area']);modes[k][x['mode']][x['order_id']]=x
violations=[];paired=[];testcount=0
for (seed,day,area),md in modes.items():
 refs=set(md['M0'])
 for m in ('M1','M2'):
  if set(md[m])!=refs:violations.append(('KEY_SET',seed,day,area,m))
 for mode,rs in md.items():
  for x in rs.values():
   testcount+=1
   if x['door_to_door_min'] and float(x['door_to_door_min'])<0:violations.append(('NEG_TIME',x['order_id'],mode))
   if x['status'].startswith('DRONE_') and (not x['hub_or_launch_site'] or x['flight_sortie_flag']!='1'):
    violations.append(('FLIGHT_WITHOUT_HUB_SORTIE',x['order_id'],mode))
   if mode=='M2' and x['paired_order_id']:
    y=rs.get(x['paired_order_id'])
    if not y or y['paired_order_id']!=x['order_id']:violations.append(('PAIR_NOT_RECIPROCAL',x['order_id']))
 for m in ('M1','M2'):
  alt=md[m];base=md['M0'];both=[];new=lost=0;air=0
  for oid,br in base.items():
   ar=alt[oid];old=br['door_to_door_min'];n=ar['door_to_door_min']
   if old and n:both.append(float(n)-float(old))
   elif not old and n:new+=1
   elif old and not n:lost+=1
   air+=ar['flight_sortie_flag']=='1'
  paired.append({'seed':seed,'date':day,'area':area,'mode':m,'matched_orders_n':len(refs),'both_completed_n':len(both),'newly_completed_n':new,
   'newly_unserved_n':lost,'air_sorties_n':air,
   'mean_paired_completion_difference_min':round(statistics.mean(both),4) if both else '',
   'median_paired_completion_difference_min':round(statistics.median(both),4) if both else '',
   'positive_time_saved_n':sum(x<0 for x in both),'slower_than_M0_n':sum(x>0 for x in both),
   'same_as_M0_n':sum(x==0 for x in both)})
assert not violations, violations[:10]
with open(P/'stage4_seed_day_paired_comparison.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(paired[0]));w.writeheader();w.writerows(paired)
agg=[]
for a in 'AB':
 for m in ('M1','M2'):
  ss=[r for r in paired if r['area']==a and r['mode']==m]
  agg.append({'area':a,'mode':m,'reference_orders':sum(r['matched_orders_n'] for r in ss),
  'both_completed_n':sum(r['both_completed_n'] for r in ss),
  'newly_completed_n':sum(r['newly_completed_n'] for r in ss),
  'newly_unserved_n':sum(r['newly_unserved_n'] for r in ss),
  'paired_better_n':sum(r['positive_time_saved_n'] for r in ss),
  'paired_slower_n':sum(r['slower_than_M0_n'] for r in ss),
  'paired_equal_n':sum(r['same_as_M0_n'] for r in ss),
  'air_sorties_n':sum(r['air_sorties_n'] for r in ss),
  'paired_mean_of_group_means_min':round(statistics.mean(float(r['mean_paired_completion_difference_min']) for r in ss if r['mean_paired_completion_difference_min']!=''),4)})
with open(P/'stage4_paired_area_summary.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(agg[0]));w.writeheader();w.writerows(agg)
qa={'sample_orders':sum(len(m['M0']) for m in modes.values()),'results_total':testcount,
 'all_modes_same_orders_each_seed_day_area':True,'valid_nonnegative_door_to_door_time':True,'M2_reciprocal_pair_assertions_passed':True,
 'no_drone_record_without_sortie_site':True,'n_group_runs':len(modes),'errors':violations,
 'note':'This is a structurally valid conditional operations scenario, NOT official RQ2 evidence; source OD road time proxy is uncalibrated.'}
(P/'stage4_pairing_qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
print(json.dumps({'paired_area':agg,'qa':qa},ensure_ascii=False,indent=2))
