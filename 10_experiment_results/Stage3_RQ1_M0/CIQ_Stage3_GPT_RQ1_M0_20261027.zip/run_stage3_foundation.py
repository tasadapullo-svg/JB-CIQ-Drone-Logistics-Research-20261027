#!/usr/bin/env python3
"""CIQ Stage 3 descriptive spatial and ground-proxy calculations.
Input: unmodified 2026-10-27 GPT three-archive bundle.
This script NEVER fabricates air operations, permissions, handling time, cost, or CO2e.
"""
import argparse, io, zipfile, gzip, hashlib, json, os, math, datetime
from pathlib import Path
import numpy as np
import pandas as pd

def sha256(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def haversine_km(lat1,lon1,lat2,lon2):
 r=6371.0088
 p1,p2=np.radians(lat1),np.radians(lat2)
 dp=p2-p1; dl=np.radians(lon2-lon1)
 z=np.sin(dp/2)**2+np.cos(p1)*np.cos(p2)*np.sin(dl/2)**2
 return 2*r*np.arcsin(np.sqrt(np.clip(z,0,1)))

def read_outer(outer,name):return pd.read_csv(io.BytesIO(outer.read(name)))
def outcsv(frame,out):frame.to_csv(out,index=False,encoding='utf-8-sig',float_format='%.6f')

def main(in_path,out_path):
 out=Path(out_path);out.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(in_path) as outer:
  files=outer.namelist()
  def get(suffix):
   matches=[n for n in files if n.endswith(suffix)]
   if len(matches)!=1:raise ValueError('Expected one '+suffix+', got '+str(matches))
   return matches[0]
  sites=read_outer(outer,get('19_site_reference_anchors_NOT_LAUNCH_PADS.csv'))
  od=pd.concat([read_outer(outer,get('E02_A_OD_OSM_MODEL_NOT_OBSERVED.csv')),read_outer(outer,get('E02_B_OD_OSM_MODEL_NOT_OBSERVED.csv'))],ignore_index=True)
  joint=read_outer(outer,get('01_AB_24h_hourly_joint.csv'))
  weather=read_outer(outer,get('E03_ERA5_JB_TWO_CIQ_WEATHER_HOURLY.csv'))
  nested_name=get('JB_CIQ_E05_V5.6_30次重复订单_全天交通天气稳健性_完整归档.zip')
  nested=zipfile.ZipFile(io.BytesIO(outer.read(nested_name)))
  rep_files=sorted([n for n in nested.namelist() if n.endswith('_orders.csv.gz')])
  if len(rep_files)!=30:raise AssertionError('Expected 30 seed order files')

  valid_nodes=sites.drop_duplicates('site_id').set_index('site_id')
  od['route_key']=od.origin_id+'|'+od.destination_id
  route_distance=od.set_index('route_key')['route_length_km'].to_dict()
  candidates=sites[sites.functional_roles.str.contains('source_hub_search|truck_uav_transfer_search',na=False)].copy()
  # Candidate set represents reference search areas, not legal launch sites.
  cand=[]
  for _,r in candidates.iterrows():
   cand.append((r.site_id, r.area, float(r.latitude), float(r.longitude)))

  all_rq1=[];all_m0=[];monthly=[];sites_cov=[];seed_integrity=[]
  order_parts=[]; n_all=0; n_mismatch3=0;n_mismatch4=0
  for ix,rep_name in enumerate(rep_files,1):
   o=pd.read_csv(gzip.GzipFile(fileobj=io.BytesIO(nested.read(rep_name))))
   seed=int(o.replicate_seed.iloc[0]);n=len(o)
   if n!=30600 or o.replicate_seed.nunique()!=1 or o.replicate_order_id.nunique()!=n:raise AssertionError(f'Bad seed {seed}')
   n_all+=n
   orig=o.origin_site_id.map(valid_nodes.latitude).to_numpy(float)
   orig_lon=o.origin_site_id.map(valid_nodes.longitude).to_numpy(float)
   dest=o.destination_site_id.map(valid_nodes.latitude).to_numpy(float)
   dest_lon=o.destination_site_id.map(valid_nodes.longitude).to_numpy(float)
   if not (np.isfinite(orig).all() and np.isfinite(dest).all()):raise AssertionError('Site coordinate not found')
   direct=haversine_km(orig,orig_lon,dest,dest_lon)
   direct3=direct<=3.0;direct4=direct<=4.0
   n_mismatch3 += int(np.count_nonzero(direct3!=(o.direct_geometric_le3km.to_numpy()==1)))
   n_mismatch4 += int(np.count_nonzero(direct4!=(o.direct_geometric_le4km.to_numpy()==1)))

   # Origin/destination within catchment of at least one hypothesized anchor in the SAME area.
   src_min=np.full(n,np.inf);dst_min=np.full(n,np.inf)
   origin_to_candidate={};dest_to_candidate={}
   for site_id,area,la,lo in cand:
    relevant=o.area.to_numpy()==area
    odist=np.where(relevant,haversine_km(orig,orig_lon,la,lo),np.inf)
    ddist=np.where(relevant,haversine_km(dest,dest_lon,la,lo),np.inf)
    src_min=np.minimum(src_min,odist);dst_min=np.minimum(dst_min,ddist)
    dest_to_candidate[site_id]=ddist
   dayscreen=(o.night_19to05_SCREEN_ONLY.to_numpy()!=1)
   # The following weather cutoffs are descriptive exposure screens, NOT certified flight limits.
   dry=o.era5_rain_mm_h.to_numpy(float)<0.1
   gust_proxy=o.era5_gust10_ms.to_numpy(float)<10.0
   weather_screen=dry&gust_proxy
   fcd_ok=o.fcd_coverage_ge70pct.to_numpy()==1
   route_key=o.origin_site_id+'|'+o.destination_site_id
   road_km=route_key.map(route_distance).to_numpy(float)
   route_ok=np.isfinite(road_km)
   road_minutes=o.ground_hour_MODEL_PROXY_min_NOT_VALIDATED.to_numpy(float)
   proxy_ok=np.isfinite(road_minutes)&route_ok&fcd_ok
   status=np.select([~route_ok,~fcd_ok,~np.isfinite(road_minutes)],['OSM_ROUTE_UNAVAILABLE','FCD_COVERAGE_LT70','PROXY_OTHER_MISSING'],default='MODEL_PROXY_AVAILABLE')
   timestamp=pd.to_datetime(o.release_time_local,errors='raise')
   part=pd.DataFrame({
    'seed':seed,'order_id':o.replicate_order_id,'area':o.area,'demand_class':o.demand_class,
    'dataset_split':o.dataset_split,'release_time_local':o.release_time_local,
    'month':timestamp.dt.month,'hour':timestamp.dt.hour,
    'origin_site_id':o.origin_site_id,'destination_site_id':o.destination_site_id,
    'parcel_kg':o.parcel_kg,
    'direct_km_haversine':direct.round(5),
    'direct_le3km':direct3,'direct_le4km':direct4,
    'candidate_origin_nearest_km':src_min.round(5),'candidate_destination_nearest_km':dst_min.round(5),
    'candidate_both_le3km':(src_min<=3)&(dst_min<=3),
    'candidate_both_le4km':(src_min<=4)&(dst_min<=4),
    'dry_lt0p1mmh_EXPOSURE_ONLY':dry,'gust_lt10ms_EXPOSURE_ONLY':gust_proxy,
    'weather_screen_ILLUSTRATIVE_ONLY':weather_screen,'day_06to18_ANALYTICAL_ONLY':dayscreen,
    'geo3_weather_EXPOSURE_ONLY':direct3&weather_screen,'geo4_weather_EXPOSURE_ONLY':direct4&weather_screen,
    'road_route_exists':route_ok,'traffic_coverage_ge70':fcd_ok,
    'm0_proxy_time_min':np.where(proxy_ok,road_minutes,np.nan),
    'm0_osm_route_km':np.where(proxy_ok,road_km,np.nan),
    'm0_availability_status':status,
    'm0_result_label':'ROAD_TIME_MODEL_PROXY_NOT_VALIDATED',
    'uav_authorization_status':'NOT_VERIFIED_NO_AUTHORIZED_RELEASE'
   })
   order_parts.append(part)
   seed_integrity.append({'seed':seed,'n_orders':n,'unique_order_ids':o.replicate_order_id.nunique(),'number_areas':o.area.nunique(),'number_months':timestamp.dt.month.nunique(), 'valid_road_proxy_n':int(proxy_ok.sum())})
   # Statistics within each seed, area and demand class; include ALL as aggregation.
   for keys,sub in list(part.groupby(['area','demand_class'],sort=True))+[(('ALL','ALL'),part)]:
    ar,cls=keys; r={'seed':seed,'area':ar,'demand_class':cls,'n_orders':len(sub)}
    for flag in ['direct_le3km','direct_le4km','candidate_both_le3km','candidate_both_le4km','geo3_weather_EXPOSURE_ONLY','geo4_weather_EXPOSURE_ONLY','weather_screen_ILLUSTRATIVE_ONLY','day_06to18_ANALYTICAL_ONLY']:
     r[flag+'_pct']=100*sub[flag].mean()
    r['mean_direct_km']=sub.direct_km_haversine.mean()
    all_rq1.append(r)
    m0=sub[sub.m0_availability_status=='MODEL_PROXY_AVAILABLE']
    m={'seed':seed,'area':ar,'demand_class':cls,'n_orders':len(sub), 'n_with_proxy':len(m0),'proxy_coverage_pct':100*len(m0)/len(sub),
      'missing_route_n':int((sub.m0_availability_status=='OSM_ROUTE_UNAVAILABLE').sum()),
      'missing_traffic_n':int((sub.m0_availability_status=='FCD_COVERAGE_LT70').sum()),
      'missing_other_n':int((sub.m0_availability_status=='PROXY_OTHER_MISSING').sum()),
      'road_proxy_time_p50_min':m0.m0_proxy_time_min.quantile(.5),
      'road_proxy_time_p90_min':m0.m0_proxy_time_min.quantile(.9),
      'road_proxy_time_p95_min':m0.m0_proxy_time_min.quantile(.95),
      'road_proxy_mean_min':m0.m0_proxy_time_min.mean(),
      'road_proxy_mean_km':m0.m0_osm_route_km.mean(),
      'result_class':'ROAD_ONLY_PROXY_NOT_DOOR_TO_DOOR'}
    all_m0.append(m)
   for (area,month,split),sub in part.groupby(['area','month','dataset_split']):
    monthly.append({'seed':seed,'area':area,'month':month,'split':split,'n_orders':len(sub),'direct3_pct':100*sub.direct_le3km.mean(), 'direct4_pct':100*sub.direct_le4km.mean(),'geo3_weather_screen_pct':100*sub.geo3_weather_EXPOSURE_ONLY.mean(),'geo4_weather_screen_pct':100*sub.geo4_weather_EXPOSURE_ONLY.mean(),'road_proxy_pct':100*sub.m0_proxy_time_min.notna().mean()})
   for sid,area,la,lo in cand:
    sub=part[part.area==area]
    dd=dest_to_candidate[sid][o.area.to_numpy()==area]
    for radius in [3,4]:
     sites_cov.append({'seed':seed,'candidate_site_id':sid,'area':area,'radius_km':radius,'n_orders_area':len(sub),'candidate_dest_catchment_n':int((dd<=radius).sum()),'candidate_dest_catchment_pct':100*float((dd<=radius).mean()), 'site_status':'SEARCH_ANCHOR_NOT_APPROVED_PAD'})

  all_orders=pd.concat(order_parts,ignore_index=True)
  assert len(all_orders)==918000
  assert all_orders.order_id.nunique()==918000
  assert (all_orders.groupby('seed').size()==30600).all()
  outcsv(pd.DataFrame(seed_integrity),out/'input_seed_audit.csv')
  outcsv(pd.DataFrame(all_rq1),out/'rq1_seed_summary.csv')
  outcsv(pd.DataFrame(all_m0),out/'m0_seed_summary.csv')
  outcsv(pd.DataFrame(monthly),out/'monthly_coverage_summary.csv')
  outcsv(pd.DataFrame(sites_cov),out/'rq1_candidate_site_catchment.csv')
  all_orders.to_csv(out/'rq1_m0_order_level.csv.gz',index=False,compression='gzip',float_format='%.5f')
  # aggregate for user-readable high confidence results; no causal CI.
  def metric_summary(df, metrics):
   grouped=df.groupby(['area','demand_class'],as_index=False)[metrics].agg(['mean',lambda v: np.quantile(v,.025),lambda v:np.quantile(v,.975)])
   grouped.columns=['_'.join(c).strip('_') for c in grouped.columns.to_flat_index()]
   grouped.columns=[c.replace('_<lambda_0>','_seed_p025').replace('_<lambda_1>','_seed_p975') for c in grouped.columns]
   return grouped.reset_index(drop=True)
  rqseed=pd.DataFrame(all_rq1);m0seed=pd.DataFrame(all_m0)
  rqagg=metric_summary(rqseed,['direct_le3km_pct','direct_le4km_pct','candidate_both_le3km_pct','candidate_both_le4km_pct','geo3_weather_EXPOSURE_ONLY_pct','geo4_weather_EXPOSURE_ONLY_pct','weather_screen_ILLUSTRATIVE_ONLY_pct','mean_direct_km'])
  m0agg=metric_summary(m0seed,['proxy_coverage_pct','road_proxy_time_p50_min','road_proxy_time_p90_min','road_proxy_time_p95_min','road_proxy_mean_min','road_proxy_mean_km'])
  outcsv(rqagg,out/'rq1_30seed_descriptive.csv')
  outcsv(m0agg,out/'m0_30seed_descriptive.csv')
  # One summary by candidate site, with descriptive means.
  sc=pd.DataFrame(sites_cov).groupby(['candidate_site_id','area','radius_km'],as_index=False).agg(n_area_per_seed=('n_orders_area','mean'),pct_dest_catchment=('candidate_dest_catchment_pct','mean'),count_per_seed=('candidate_dest_catchment_n','mean'))
  outcsv(sc,out/'rq1_site_descriptive.csv')
  outcome={
   'data_source':'2026-10-27 supplied CIQ GPT bundle', 'input_bundle_sha256':sha256(in_path),
   'n_seeds':30,'orders_total':int(n_all),'unique_order_ids':int(all_orders.order_id.nunique()),
   'direct3_flag_disagreements':n_mismatch3,'direct4_flag_disagreements':n_mismatch4,
   'site_search_candidates':[x[0] for x in cand],
   'm0_available_n':int(all_orders.m0_proxy_time_min.notna().sum()),
   'm0_missing_route_n':int((all_orders.m0_availability_status=='OSM_ROUTE_UNAVAILABLE').sum()),
   'm0_missing_traffic_n':int((all_orders.m0_availability_status=='FCD_COVERAGE_LT70').sum()),
   'm0_missing_other_n':int((all_orders.m0_availability_status=='PROXY_OTHER_MISSING').sum()),
   'notes':['All OD are MY-side inland and do not cross CIQ','Drone authorization not verified; no legal flight conclusion',
    'Direct 3/4 km are one-way great-circle screens only, not aircraft range or legal route',
    'Candidate sites are geographic search anchors with no site-access or flight permission',
    'Weather rain <0.1 mm/h & gust <10 m/s are illustrative exposure thresholds only',
    'M0 is OSM static travel model divided by regional FCD ratio, not validated road time or door-to-door',
    '30 seed intervals describe repeat-sampling variation, not formal causal CI',
    'M1/M2 time/cost/emissions deliberately not computed without validated operations/parameters']}
  (out/'experiment_manifest.json').write_text(json.dumps(outcome,indent=2,ensure_ascii=False),encoding='utf-8')
  return outcome

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
 print(json.dumps(main(a.input,a.output),ensure_ascii=False,indent=2))
