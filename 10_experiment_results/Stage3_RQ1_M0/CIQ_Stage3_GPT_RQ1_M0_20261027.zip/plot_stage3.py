import pandas as pd,numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import argparse
ap=argparse.ArgumentParser()
ap.add_argument('--output-dir',default='/mnt/data/ciq_stage3_foundation')
args=ap.parse_args()
p=Path(args.output_dir)
r=pd.read_csv(p/'rq1_30seed_descriptive.csv').query('area != "ALL"').copy()
r['group']=r.area+' / '+r.demand_class
x=np.arange(len(r));w=.32
fig,ax=plt.subplots(figsize=(9.2,4.7))
ax.bar(x-w/2,r.direct_le3km_pct_mean,w,label='Direct distance <= 3 km')
ax.bar(x+w/2,r.direct_le4km_pct_mean,w,label='Direct distance <= 4 km')
ax.set_xticks(x,r['group']);ax.set_ylim(0,110);ax.set_ylabel('Geometric share of synthetic orders (%)')
ax.set_title('RQ1: Direct-distance screening by area and demand class')
ax.legend(loc='upper right');ax.grid(axis='y',alpha=.2)
fig.text(.01,.01,'Search-area references only; not approved routes, pads or aircraft range. 30 stratified resampling seeds.',fontsize=8)
fig.tight_layout(rect=(0,.05,1,1));fig.savefig(p/'figure_RQ1_direct_3_4km.png',dpi=200);plt.close(fig)

m=pd.read_csv(p/'m0_30seed_descriptive.csv').query('area != "ALL"').copy()
m['group']=m.area+' / '+m.demand_class
x=np.arange(len(m))
fig,ax=plt.subplots(figsize=(9.2,4.7));ax.bar(x,m.proxy_coverage_pct_mean)
ax.set_xticks(x,m['group']);ax.set_ylim(0,100);ax.set_ylabel('Available model-proxy records (%)');ax.set_title('M0: Road-time proxy availability (not validated door-to-door time)')
for xi,yi in zip(x,m.proxy_coverage_pct_mean):ax.text(xi,yi+1,f'{yi:.1f}%',ha='center',fontsize=9)
ax.grid(axis='y',alpha=.2);fig.text(.01,.01,'Excluded records are explicitly classified as OSM no route or FCD <70% coverage.',fontsize=8)
fig.tight_layout(rect=(0,.05,1,1));fig.savefig(p/'figure_M0_model_proxy_availability.png',dpi=200);plt.close(fig)
print('Figures made')
