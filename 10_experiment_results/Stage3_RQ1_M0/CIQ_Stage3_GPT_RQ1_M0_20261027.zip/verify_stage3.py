from pathlib import Path
import hashlib,json,io,zipfile,gzip
import pandas as pd
import numpy as np
p=Path('/mnt/data/ciq_stage3_foundation')
archive='/mnt/data/CIQ_GPT校验所需三归档与关键数据_20261027.zip'
with zipfile.ZipFile(archive) as z:
 m=pd.read_csv(io.BytesIO(z.read('FILE_SHA256_MANIFEST.csv')))
 integrity=[]
 for r in m.itertuples():
  data=z.read(r.archive_path)
  integrity.append({'name':r.archive_path,'size_matches':len(data)==r.bytes,'sha256_matches':hashlib.sha256(data).hexdigest()==r.sha256})
 assert all(x['size_matches'] and x['sha256_matches'] for x in integrity)
 # Independent hourly input sample check from source orders not overwritten by Stage 3 output.
 v5=zipfile.ZipFile(io.BytesIO(z.read([x for x in z.namelist() if x.endswith('V5.6_30次重复订单_全天交通天气稳健性_完整归档.zip')][0])))
 first=pd.read_csv(gzip.GzipFile(fileobj=io.BytesIO(v5.read([x for x in v5.namelist() if x.endswith('_orders.csv.gz')][0]))))
 hourly=pd.read_csv(gzip.GzipFile(fileobj=io.BytesIO(z.read([x for x in z.namelist() if x.endswith('03_hourly_91_reference_OD_MODEL_PROXY_NOT_REAL.csv.gz')][0]))))
 source_sample=first.sample(2000,random_state=23).copy()
 source_sample['timestamp_local_hour']=source_sample.release_time_local.str[:13]
 merged=source_sample.merge(hourly[['area','timestamp_local_hour','origin_id','destination_id','model_scaled_time_min_NOT_VALIDATED']],left_on=['area','timestamp_local_hour','origin_site_id','destination_site_id'],right_on=['area','timestamp_local_hour','origin_id','destination_id'],how='left',validate='many_to_one')
 observed=merged.ground_hour_MODEL_PROXY_min_NOT_VALIDATED
 refer=merged.model_scaled_time_min_NOT_VALIDATED
 paired=observed.notna()&refer.notna()
 assert np.allclose(observed[paired],refer[paired],atol=1e-4)
 assert (observed.notna()==refer.notna()).all()
 summary=json.loads((p/'experiment_manifest.json').read_text())
 counts=pd.read_csv(p/'m0_seed_summary.csv').query('area=="ALL" and demand_class=="ALL"')
 assert int(counts.n_orders.sum())==918000
 assert int(counts.n_with_proxy.sum())==summary['m0_available_n']
 assert int(counts.missing_route_n.sum())==summary['m0_missing_route_n']
 assert int(counts.missing_traffic_n.sum())==summary['m0_missing_traffic_n']
 assert int(counts.missing_other_n.sum())==summary['m0_missing_other_n']
 qa={'bundle_integrity_pass':True,'bundle_sha_matches_n':len(integrity), 'bundle_size_matches_n':len(integrity),
 'seed_count':int(len(counts)),'sum_order_count':int(counts.n_orders.sum()),
 'sample_hourly_reference_n':len(merged),'sample_available_reference_n':int(paired.sum()),'sample_match_tolerance_min':1e-4,
 'missing_status_exhaustive':summary['orders_total']==summary['m0_available_n']+summary['m0_missing_route_n']+summary['m0_missing_traffic_n']+summary['m0_missing_other_n'],
 'geodesic_matches_archive_flags':summary['direct3_flag_disagreements']==0 and summary['direct4_flag_disagreements']==0,
 'files_checked':integrity}
 (p/'stage3_qa_report.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in qa.items() if k!='files_checked'},ensure_ascii=False,indent=2))
