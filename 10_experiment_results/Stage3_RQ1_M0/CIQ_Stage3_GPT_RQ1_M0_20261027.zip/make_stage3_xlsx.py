from pathlib import Path
import pandas as pd
from artifact_tool import Workbook, SpreadsheetFile
import argparse
ap=argparse.ArgumentParser()
ap.add_argument('--output-dir',default='/mnt/data/ciq_stage3_foundation')
args=ap.parse_args()
p=Path(args.output_dir)
wb=Workbook.create()

def add_sheet(name,df,widths=None):
 sh=wb.worksheets.add(name)
 # avoid NaN invalid cell values
 data=[[None if pd.isna(v) else (v.item() if hasattr(v,'item') else v) for v in row] for row in df.itertuples(index=False,name=None)]
 rows=[list(df.columns)]+data
 sh.get_range_by_indexes(0,0,len(rows),len(rows[0])).values=rows
 header=sh.get_range_by_indexes(0,0,1,len(rows[0]))
 header.format={'fill':'#15324F','font':{'bold':True,'color':'#FFFFFF'},'row_height':32,'wrap_text':True}
 sh.freeze_panes.freeze_rows(1)
 for c in range(len(rows[0])):
  width=(widths or {}).get(c,22)
  sh.get_range_by_indexes(0,c,len(rows),1).format.column_width=width
 return sh

manifest={'orders_total':918000,'proxy_available':581446,'route_missing':262132,'fcd_missing':74422}
summary=wb.worksheets.add('Overview')
summary.get_range('A1:E1').values=[['CIQ Stage 3 | RQ1 spatial screens & M0 road proxy','','','','']]
summary.get_range('A1:E1').format={'fill':'#15324F','font':{'bold':True,'color':'#FFFFFF','size':16},'row_height':33}
summary.get_range('A3:C3').values=[['Input and coverage','Count','Share of orders']]
summary.get_range('A3:C3').format={'fill':'#DDE7F0','font':{'bold':True}}
summary.get_range('A4:B8').values=[['Synthetic resample records',918000],['M0 road proxy available',581446],['No OSM route',262132],['FCD coverage below 70%',74422],['Other missing',0]]
summary.get_range('C4:C8').formulas=[['=B4/B4'],['=B5/$B$4'],['=B6/$B$4'],['=B7/$B$4'],['=B8/$B$4']]
summary.get_range('C4:C8').set_number_format('0.00%')
summary.get_range('A10:C12').values=[['Key distinction','Assessment','Interpretation'],['RQ1','GEOMETRIC ONLY','Site references are unapproved search zones; weather thresholds are descriptive'],['M0','MODEL PROXY ONLY','OSM / FCD ratio, not a validated door-to-door delivery time']]
summary.get_range('A10:C10').format={'fill':'#DDE7F0','font':{'bold':True}}
summary.get_range('A14:C17').values=[['M1 / M2','NOT COMPUTED','No approved pads, aircraft-specific performance or synchronized operations'],['Scope','MALAYSIA-SIDE','Existing OD do not cross a CIQ checkpoint'],['Statistics','30 resampling seeds','2.5–97.5 percentile bands are descriptive; not causal CIs'],['Version','2026-10-27','Reproduce with run_stage3_foundation.py and source bundle']]
for col,w in [('A',29),('B',28),('C',83),('D',14),('E',14)]:summary.get_range(f'{col}1:{col}20').format.column_width=w
summary.freeze_panes.freeze_rows(3)

r=pd.read_csv(p/'rq1_30seed_descriptive.csv')
main=r[['area','demand_class','direct_le3km_pct_mean','direct_le4km_pct_mean','geo3_weather_EXPOSURE_ONLY_pct_mean','geo4_weather_EXPOSURE_ONLY_pct_mean','candidate_both_le3km_pct_mean','candidate_both_le4km_pct_mean','mean_direct_km_mean']].copy()
main.columns=['Area','Demand class','Direct <=3km (%)','Direct <=4km (%)','3km + weather exposure screen (%)','4km + weather exposure screen (%)','Both endpoints near candidate 3km (%)','Both endpoints near candidate 4km (%)','Mean direct distance (km)']
add_sheet('RQ1_Main',main,{0:15,1:17,2:22,3:22,4:33,5:33,6:40,7:40,8:26})
add_sheet('RQ1_Seed_Bands',r)
m=pd.read_csv(p/'m0_30seed_descriptive.csv')
mg=m[['area','demand_class','proxy_coverage_pct_mean','road_proxy_mean_min_mean','road_proxy_time_p50_min_mean','road_proxy_time_p90_min_mean','road_proxy_time_p95_min_mean','road_proxy_mean_km_mean']].copy()
mg.columns=['Area','Demand class','M0 proxy coverage (%)','Mean road-time proxy (min)','P50 proxy (min)','P90 proxy (min)','P95 proxy (min)','Mean OSM route (km)']
add_sheet('M0_Main',mg,{0:15,1:20,2:30,3:32,4:23,5:23,6:23,7:28})
add_sheet('M0_Seed_Bands',m)
add_sheet('Candidate_Sites',pd.read_csv(p/'rq1_site_descriptive.csv'),{0:24,1:14,2:18,3:23,4:30,5:25})
add_sheet('By_Month',pd.read_csv(p/'monthly_coverage_summary.csv'))
add_sheet('Seed_Audit',pd.read_csv(p/'input_seed_audit.csv'))
# Clearly state assumptions/method; these are strings, not inferred data.
notes=pd.DataFrame([
 ['Order design','30x30,600 stratified resamples of synthetic frozen baseline; not measured independent demand'],
 ['Spatial distance','Haversine distance for original and destination reference points; 3/4 km one-way straight-line only'],
 ['Station candidates','7 search anchor points selected by functional_roles=source_hub_search OR truck_uav_transfer_search; not approved pads'],
 ['Weather screen','rain<0.1 mm/h AND gust<10 m/s, descriptive exposure screen, NOT model-specific flight limits'],
 ['Time screen','06:00–18:59 is analytical daylight proxy, NOT actual sunrise/sunset or night permission'],
 ['M0 road time','Read prior 24h OSM reference / regional FCD ratio proxy; include only route exists & FCD coverage >= 0.7'],
 ['M0 timing boundary','Modelled road movement only; NO loading, delivery service, queues, congestion calibration, or CIQ waiting'],
 ['CIQ restriction','All current OD are local MY-side. NO CIQ delay is applied'],
 ['Missing routes','262,132 order-mode road proxies missing owing to unvalidated OSM route'],
 ['FCD coverage','74,422 order-mode road proxies missing owing to low FCD coverage'],
 ['Seed intervals','2.5th–97.5th percentile across seed-level metrics, not inferential confidence interval'],
 ['Model 1/2','Not evaluated without valid logistics network, station operations, aircraft & synchronized truck route definitions'],
 ['Source','User-supplied archive CIQ_GPT校验所需三归档与关键数据_20261027.zip']
],columns=['Aspect','Method and limitation'])
add_sheet('Methods_Limits',notes,{0:29,1:100})
SpreadsheetFile.export_xlsx(wb).save(str(p/'CIQ_RQ1_M0_stage3_20261027.xlsx'))
print('XLSX created', (p/'CIQ_RQ1_M0_stage3_20261027.xlsx').stat().st_size)
