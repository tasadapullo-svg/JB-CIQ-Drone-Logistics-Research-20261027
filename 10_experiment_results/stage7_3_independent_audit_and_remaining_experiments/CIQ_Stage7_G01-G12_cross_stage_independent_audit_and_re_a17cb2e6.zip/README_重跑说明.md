# CIQ Stage7 G01–G12 只读审计证据包

## 文件
- reports/Stage7_G01_G12_独立审计正式报告.md：结论、优先级、剩余实验安排
- outputs/*.csv、summary.json：存档连续性、分母、排放对照、B区到站后小时、先导实验及12关口状态
- audit_chain.py：从4个冻结ZIP读取并核验CRC/哈希/样本/成本情景数据的标准库脚本
- check_launch_hours.py：独立配对B区批次到站时间与无人机订单的运行时窗审计

## 重跑
将以下4个历史工程ZIP按其原文件名放在 `/mnt/data`，然后运行：
```
python audit_chain.py
python check_launch_hours.py
```
前一个脚本默认将结果写入 `/mnt/data/CIQ_CROSS_AUDIT_20261028/outputs`，后一个也依赖 `/mnt/data/CIQ_CROSS_AUDIT_20261028/source` 已解压的Stage6/7.2源数据。审计压缩包自身不重复嵌入超过100MB的历史上游完整原件；原件 SHA-256见 `outputs/01_archive_hashes.csv`。修改路径可直接编辑脚本开头常量。

本审计为只读静态/归档数据核查，非新运行级仿真。
