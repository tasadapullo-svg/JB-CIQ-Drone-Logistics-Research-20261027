import csv,zipfile,io,gzip,collections
from pathlib import Path
R=Path('/mnt/data/CIQ_CROSS_AUDIT_20261028')
s6=None
s72=None
M=collections.defaultdict(dict)
up=Path('/mnt/data/CIQ_Stage7_2_完整主实验复现交付包_20261027.zip')
with zipfile.ZipFile(up) as z:
 with zipfile.ZipFile(io.BytesIO(z.read('Stage6_original.zip'))) as zb:
  baserows=list(csv.DictReader(io.StringIO(zb.read('Stage6/stage6_linehaul_batches_B.csv').decode('utf-8-sig'))))
 newrows=list(csv.DictReader(io.StringIO(z.read('outputs/stage7_2_new_batch_B.csv').decode('utf-8-sig'))))
for label,rs in [('B_M1_H2_W35',baserows),('new',newrows)]:
 for r in rs:
   conf=r['configuration_id'] if label=='new' else label
   M[conf][(r['seed'],r['date'],r['batch_id'])]=r
out=[]
by=collections.defaultdict(lambda:collections.Counter())
with zipfile.ZipFile(up) as z:
 with zipfile.ZipFile(io.BytesIO(z.read('Stage6_original.zip'))) as a:
  raw1=a.read('Stage6/stage6_order_level.csv.gz')
 raw2=z.read('outputs/stage7_2_order_level_new.csv.gz')
 for label,b in [('base',raw1),('new',raw2)]:
  for r in csv.DictReader(io.StringIO(gzip.decompress(b).decode('utf-8-sig'))):
   if r['area']!='B' or r['status']!='DRONE_B_TWO_TIER_BATCH':continue
   cfg='B_M1_H2_W35' if label=='base' else r['configuration_id']
   batch=M[cfg][(r['seed'],r['date'],r['linehaul_batch_id'])]
   arr=float(batch['arrival_min']); completion=float(r['completion_min'])
   d=by[cfg];d['total_drone']+=1
   if arr>=1140:d['batch_arrival_after_19']+=1
   if completion>=1140:d['delivered_after_19']+=1
   if arr>=1140 and completion>=1140:d['both']+=1
   if arr>=1140 and len(out)<20:out.append({'config':cfg,'seed':r['seed'],'date':r['date'],'order_id':r['order_id'],'release_time':r['release_time'],'batch_arrival_min':arr,'completion_min':completion,'batch_id':r['linehaul_batch_id']})
with (R/'outputs'/'09_B_batch_arrival_after_operating_hours.csv').open('w',encoding='utf-8-sig',newline='') as f:
 keys=['configuration_id','drone_orders','batch_arrival_after19','delivery_after19','share_after19_pct']
 w=csv.DictWriter(f,keys);w.writeheader()
 for cfg in sorted(by):
  v=by[cfg];w.writerow({'configuration_id':cfg,'drone_orders':v['total_drone'],'batch_arrival_after19':v['batch_arrival_after_19'],'delivery_after19':v['delivered_after_19'],'share_after19_pct':round(v['batch_arrival_after_19']/v['total_drone']*100,2)})
with (R/'outputs'/'10_B_afterhours_examples.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,out[0]);w.writeheader();w.writerows(out)
for cfg in sorted(by):print(cfg, dict(by[cfg]))
