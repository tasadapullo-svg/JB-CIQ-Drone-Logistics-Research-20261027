#!/usr/bin/env python3
"""Read-only cross-stage evidence audit. No changes to original CIQ archives.
Runs with Python standard library and the frozen four source ZIPs. Audit scope: archive
continuity, sampling and formulas, service coverage and feasibility caveats.
This is not a replacement for a dynamic rerun or external calibration.
"""
from pathlib import Path
from collections import defaultdict,Counter
import io, zipfile, gzip, csv, json, hashlib
ROOT=Path('/mnt/data')
OUT=ROOT/'CIQ_CROSS_AUDIT_20261028'/'outputs'; OUT.mkdir(parents=True,exist_ok=True)
FILES={
 'Stage6':'CIQ_Stage6_最终完整工程_30种子_20261027.zip',
 'Stage7_2':'CIQ_Stage7_2_完整主实验复现交付包_20261027.zip',
 'Stage7_3_G03_08':'CIQ_Stage7_3_G03-G08_P0组合审计_完整过程与可复现证据_20261027.zip',
 'G06_08_fuel':'CIQ_Stage7_G06_G08_燃油基线服务成本碳排放_完整审计包_20261027.zip'
}
def sha(b):return hashlib.sha256(b).hexdigest()
def readrows(b,gz=False):
 if gz:b=gzip.decompress(b)
 return list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'))))
def num(v):return float(v) if v not in ('',None) else None
def csvout(fname,rows):
 rows=list(rows);cols=list(dict.fromkeys(k for r in rows for k in r))
 with (OUT/fname).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
# package checks
zr={k:zipfile.ZipFile(ROOT/v) for k,v in FILES.items()}
hashes={k:sha((ROOT/v).read_bytes()) for k,v in FILES.items()}
continuity=[
 ('Stage6 -> Stage7.2',hashes['Stage6'],sha(zr['Stage7_2'].read('Stage6_original.zip'))),
 ('Stage7.2 -> Stage7.3',hashes['Stage7_2'],sha(zr['Stage7_3_G03_08'].read('inputs/CIQ_Stage7_2_完整主实验复现交付包_20261027.zip'))),
 ('Stage7.2 -> G06-08 Fuel',hashes['Stage7_2'],sha(zr['G06_08_fuel'].read('CIQ_Stage7_G06_G08_20261027/Stage7_2_upstream_immutable.zip'))),
]
files=[{'archive':k,'file':v,'bytes':(ROOT/v).stat().st_size,'sha256':hashes[k],'zip_crc_ok':zr[k].testzip() is None} for k,v in FILES.items()]
csvout('01_archive_hashes.csv',files)
csvout('02_chain_continuity.csv',[{'link':name,'upstream_sha256':a,'embedded_sha256':b,'identical':a==b} for name,a,b in continuity])
assert all(a==b for _,a,b in continuity)
# both Stage7.2 and latest accounted outputs
z=zr['Stage7_2']
base=z.read('Stage6_original.zip');zb=zipfile.ZipFile(io.BytesIO(base))
s6=readrows(zb.read('Stage6/stage6_order_level.csv.gz'),True)
s72=readrows(z.read('outputs/stage7_2_order_level_new.csv.gz'),True)
daily=readrows(z.read('outputs/stage7_2_daily_config.csv'))
conf=readrows(z.read('outputs/stage7_2_pooled_front.csv'))
status=Counter(r['status'] for r in s6+s72)
byconf=defaultdict(list)
BASE_MAP={('A','M0'):'A_M0_REF',('A','M1'):'A_M1_H2',('A','M2'):'A_M2_REF',('B','M0'):'B_M0_REF',('B','M1'):'B_M1_H2_W35',('B','M2'):'B_M2_REF'}
for label,rows in [('Stage6',s6),('new',s72)]:
 for r in rows:
  cfg=r['configuration_id'] if label=='new' else BASE_MAP[(r['area'],r['mode'])]
  byconf[cfg].append(r)
assert len(byconf)==12 and len(daily)==1800 and len(s6)==89526 and len(s72)==89438
assert len({r['seed'] for r in daily})==30 and len({r['date'] for r in daily})==5
source_late=[];source_late_by_cfg=[]
for cfg,rr in sorted(byconf.items()):
 elig=sum(bool(r['door_to_door_min']) for r in rr)
 total=len(rr)
 sorties=sum(int(r['drone_sorties']) for r in rr)
 late=[r for r in rr if int(r['drone_sorties'])>0 and r['completion_min'] and float(r['completion_min'])>1140]
 launch_hyp=[]
 for r in late[:3]: launch_hyp.append({'cfg':cfg,'seed':r['seed'],'date':r['date'],'completion_min':r['completion_min'],'release_time':r['release_time'],'status':r['status']})
 source_late.extend(launch_hyp)
 source_late_by_cfg.append({'configuration_id':cfg,'total_records':total,'evaluable':elig,'coverage_pct':round(100*elig/total,4),'uav_delivery_rows':sorties,'uav_delivery_after_19h':len(late),'after_19h_share_of_uav_pct':round(100*len(late)/sorties,2) if sorties else None,'per_order_missing_route_records':total-elig})
csvout('03_cohort_and_potential_after_hours.csv',source_late_by_cfg)
csvout('04_after_hours_order_examples.csv',source_late)
csvout('05_mode_status_distribution.csv',[{'status':k,'count':v} for k,v in sorted(status.items())])
# new fuel results consistency, factor extracts
zf=zr['G06_08_fuel'];pre='CIQ_Stage7_G06_G08_20261027/'
pool=readrows(zf.read(pre+'outputs/scenario_pooled.csv'))
seed=readrows(zf.read(pre+'outputs/scenario_seed.csv'))
qa=json.loads(zf.read(pre+'outputs/qa.json'))
ind=json.loads(zf.read(pre+'outputs/independent_QA.json'))
assert len(pool)==240 and len(seed)==7200 and qa['status']=='PASS_FIXED_DISPATCH_CONDITIONAL'
assert ind['status']=='PASS_INDEPENDENT_ACCOUNTING_QA'
find={(r['scenario'],r['configuration_id']):r for r in pool}
comparisons=[]
for s in ['CAR16__DIESEL8','CAR16__DIESEL10','CAR16__DIESEL12','MIX40_PAYLOAD__DIESEL10','MIX50_PAYLOAD__DIESEL10']:
 for area in ['A','B']:
  base_id=area+'_M0_REF';bg=find[(s,base_id)]
  for cid in (['A_M1_H2','A_M2_REF'] if area=='A' else ['B_M1_H2_W35','B_M2_REF']):
   r=find[(s,cid)]
   comparisons.append({'scenario':s,'area':area,'config':cid,'comparison':base_id,
    'time_diff_min':round(num(r['mean_time_min'])-num(bg['mean_time_min']),6),
    'cost_diff_MYR_input':round(num(r['cost_per_input_MYR'])-num(bg['cost_per_input_MYR']),6),
    'co2_diff_kg_input':round(num(r['co2_per_input_kg'])-num(bg['co2_per_input_kg']),6),
    'all_three_objectives_better':all(num(r[k])<num(bg[k]) for k in ['mean_time_min','cost_per_input_MYR','co2_per_input_kg']),
    'status':'fixed_dispatch_accounting_only'})
csvout('06_fuel_vs_ground_core_comparisons.csv',comparisons)
# restore all audit gate decisions with clear distinction historical vs full closing
gates=[
('G01','Stage6 archive/replay','Historical complete','No new work; immutable inputs'),
('G02','Strict Pareto at original baseline','Historical complete; fuel front must be interpreted separately','Historical front not final fuel front'),
('G03','30 paired seed bootstrap','Historical complete; conditional','Weather/date not independent additional draws'),
('G04','epsilon nondominance','Historical complete; threshold exploratory','Must rerate scenarios after G11'),
('G05','day/time/weather stratification','Historical complete; fixed sample','Cannot claim 5 months representative'),
('G06','service SLA / coverage denominator','Partial','No external SLA; 38%-55% orders unassessable'),
('G07','fuel costs and vehicle-specific TCO','Partial','Fixed old van nonfuel costs; motorbike / truck not calibrated'),
('G08','fuel emissions and JB fleet composition','Partial','Unknown delivery fleet shares / loaded city fuel / truck consumption'),
('G09','power/battery/weather dynamic interactions','Partial pilot','B M1 OFAT done; no paired full interactions across A/B M1/M2'),
('G10','demand/motorbike capacity and vehicle speed','Partial pilot','B M1 payload 1kg done; no vehicle-type dispatch, speed or demand distribution rerun'),
('G11','joint uncertainty robust Pareto','Not completed','Needs G09/G10 responses and cost/carbon uncertainty'),
('G12','SCI candidate classification and freeze','Not completed','Needs robust Pareto and scoped evidence boundary')]
csvout('07_G01_G12_reaudited_status.csv',[{'gate':g,'topic':t,'status':s,'unresolved':u} for g,t,s,u in gates])
# Some dynamic interventions were in stage7.2: check actual prior runs
sens=readrows(z.read('outputs/stage7_2_sensitivity_vs_baseline.csv'))
csvout('08_existing_G09_G10_pilot_evidence.csv',sens)
# write summary
summary={'read_only':True,'all_zip_crcs_pass':all(zr[k].testzip() is None for k in FILES),'upstream_embedded_hashes_match':True,'stage6_records':len(s6),'new_stage7_2_records':len(s72),'total_mode_order_records':len(s6)+len(s72),'configurations':len(byconf),'config_seed_day_cells':len(daily),'seeds':30,'fixed_dates':5,'fuel_scenario_configuration_rows':len(pool),'fuel_seed_scenarios':len(seed),'gates_historically_complete':5,'gates_partial':5,'gates_uncompleted':2,'gates_not_fully_closed':7,'stage7_2_B_OFAT_variants':sorted({r['configuration_id'] for r in sens}),'fuel_QA_status':qa['status'],'fuel_independent_QA':ind['status'],'warning':'no new dynamic simulation in this read-only audit'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(summary,indent=2,ensure_ascii=False))
for r in source_late_by_cfg:print('COVERAGE',r)
