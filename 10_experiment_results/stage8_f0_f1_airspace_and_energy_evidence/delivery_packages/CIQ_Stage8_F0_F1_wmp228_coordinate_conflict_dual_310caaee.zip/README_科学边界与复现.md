# F0-F1 三轮深度复核 | 2026-10-28

**实质结果：** 官方 WMP228 经纬中心冲突可复算，A 区原参考站/航段的敏感性和近岸界面已分情景审计；为 A 区输出 41 个 **未验证候选搜索网格**；DJI 官方数据与旧版 Wingcopter 198 双 814 Wh 参数建立版本化记录。

**未完成：** 2026-10-28 当日适用 WMP228 权威坐标、精确官方海岸线、多部门空域与起降批准、实地站点核验、当前 Wingcopter Cargo 实测能耗和 DJI 轻载任务能耗。两款机型都没有可以直接用于当前 LC-M1 绝对碳排放排名的完整实测性能曲线。不存在合法获批起降场地的证明。

## 复现
```bash
python code/run_boundary_and_energy.py
python code/independent_qa.py
python code/draw_map.py
```
使用 `inputs/` 两个 Stage 8 前期冻结 CSV（原 Stage6 数据的派生证据）；完整历史工程可从上一阶段 ZIP 取回。`code/build_workbook.py` 可依赖 `artifact_tool` 创建 Excel。

输出 `outputs/*` 包含 GeoJSON、76 航段、19 站点、41 探索网格、机型能耗版本、QA。`report/*` 包含详细解释与来源。独立 QA `PASS` 仅指代码与位置计算结构，不是监管验证。不要误将 `GSHHS` 代理海岸线作为航空法律界线。
