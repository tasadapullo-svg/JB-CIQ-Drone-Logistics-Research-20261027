#!/usr/bin/env python3
from pathlib import Path
import pandas as pd,json,math
from pyproj import Geod
p=Path(__file__).resolve().parents[1]/'outputs'
a=pd.read_csv(p/'F1_19_sites_dual_AIP_coordinate_audit.csv')
b=pd.read_csv(p/'F1_76_legs_dual_AIP_coordinate_audit.csv')
e=pd.read_csv(p/'F0_two_model_versioned_energy_evidence.csv')
g=Geod(ellps='WGS84')
lat=1+28/60+45/3600;c1=103+44/60+33/3600;c2=103+43/60+34/3600
checks=[]
for r in a.itertuples(index=False):
 for tag,c in [('CAAM_2025_EAIP_E1034433',c1),('CAAM_LEGACY_CAAS_2026_E1034334',c2)]:
  distance=g.inv(c,lat,r.lon,r.lat)[2]
  result=distance <= 3704
  recorded=bool(getattr(r,tag+'_in_circular_envelope'))
  # GSHHS projected buffer and geodesic circle may differ only near boundary; conservative tolerance
  if abs(distance-3704)>25:checks.append(result==recorded)
checks.extend([len(a)==19,len(b)==76,len(e)==5,
              (a.groupby('area').size().to_dict()=={'A':9,'B':10}),
              (b.groupby('area').size().to_dict()=={'A':28,'B':48}),
              (e[e.model=='WINGCOPTER198_CARGO_CURRENT'].nominal_pack_kwh.isna().all()),
              abs(e.loc[e.model=='WINGCOPTER198_LEGACY','nominal_pack_kwh'].iloc[0]-1.628)<1e-12,
              (a.disputed_center_exposure==a.CAAM_2025_EAIP_E1034433_in_circular_envelope.ne(a.CAAM_LEGACY_CAAS_2026_E1034334_in_circular_envelope).astype(int)).all()])
out={'independent_qa':'PASS' if all(checks) else 'FAIL', 'checks':int(len(checks)),'failed':int(len(checks)-sum(checks)), 'note':'Independent geodesic cross-check of point distance, structural counts, and model version isolation. Coastline is approximation; this QA cannot establish legal geometry.'}
(p/'independent_QA.json').write_text(json.dumps(out,indent=2))
print(out)
if not all(checks):raise SystemExit(1)
