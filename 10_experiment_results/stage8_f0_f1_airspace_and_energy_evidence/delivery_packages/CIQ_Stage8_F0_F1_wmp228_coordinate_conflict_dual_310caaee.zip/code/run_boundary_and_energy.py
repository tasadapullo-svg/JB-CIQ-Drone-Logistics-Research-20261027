#!/usr/bin/env python3
"""Reproducible research-only geospatial *screening*. No authorized flight-route claim."""
from pathlib import Path
import math,json,csv,hashlib
import pandas as pd
from shapely.geometry import Point,Polygon,LineString,mapping
from shapely.ops import transform, unary_union
from pyproj import Transformer,Geod
from mpl_toolkits.basemap import Basemap

ROOT=Path(__file__).resolve().parents[1]
I=ROOT/'inputs';O=ROOT/'outputs';O.mkdir(exist_ok=True)
OLD=ROOT
CENTERS={
    'CAAM_2025_EAIP_E1034433':{'lat':1+28/60+45/3600,'lon':103+44/60+33/3600,'url':'https://aip.caam.gov.my/aip/eAIP/2025-12-02/html/eAIP/WM-ENR-5.1-en-MS.html'},
    'CAAM_LEGACY_CAAS_2026_E1034334':{'lat':1+28/60+45/3600,'lon':103+43/60+34/3600,'url':'https://aim-sg.caas.gov.sg/aim-content/uploads/aip/22-JAN-2026/AIP-2/2026-01-22-000000/html/eAIP/SG-ENR-5.1-en-GB.html'},
}
RADIUS=3704 # metres
fwd=Transformer.from_crs('EPSG:4326','EPSG:32648',always_xy=True).transform
inv=Transformer.from_crs('EPSG:32648','EPSG:4326',always_xy=True).transform
geod=Geod(ellps='WGS84')
# coast GSHHS INTERMEDIATE raster-equivalent polygon proxy, not official shoreline
mb=Basemap(llcrnrlon=103.55,llcrnrlat=1.29,urcrnrlon=103.95,urcrnrlat=1.65,resolution='i',projection='cyl')
polys=[Polygon(p.get_coords()).buffer(0) for p in mb.landpolygons]
# Mainland Malaysia polygon determined by inland JB test coordinates, avoid Singapore polygon
malaysia=next(p for p in polys if p.contains(Point(103.78,1.54)))
malaysia_m=transform(fwd,malaysia)
circles={n:transform(fwd,Point(r['lon'],r['lat'])).buffer(RADIUS,resolution=128) for n,r in CENTERS.items()}
clipped={n:c.intersection(malaysia_m) for n,c in circles.items()}
# discrepant positions and clips need both; adopted risk union is a policy scenario, not official law
union=unary_union(list(circles.values()))
union_clip=unary_union(list(clipped.values()))
oldsite=pd.read_csv(OLD/'inputs/19_site_reference_anchors_NOT_LAUNCH_PADS.csv')
oldleg=pd.read_csv(OLD/'inputs/F1_hub_destination_geometric_leg_screen.csv')
site_lookup={r.site_id:r for r in oldsite.itertuples(index=False)}
rows=[]
for r in oldsite.itertuples(index=False):
 p=transform(fwd,Point(r.longitude,r.latitude));
 out=dict(site_id=r.site_id,area=r.area,place_name=r.place_name,lat=r.latitude,lon=r.longitude,
          mainland_GSHHS_i_proxy=int(p.within(malaysia_m)),
          land_margin_GSHHS_i_m=round(p.distance(malaysia_m.boundary),0),
          approval='NOT_VERIFIED',shoreline_source='Basemap_GSHHS_intermediate_APPROX_ONLY')
 for n,c in circles.items():
  out[n+'_dist_to_center_km']=round(p.distance(c.centroid)/1000,4)
  out[n+'_in_circular_envelope']=int(p.intersects(c))
  out[n+'_in_GSHHS_land_clip']=int(p.intersects(clipped[n]))
 out['in_either_circle']=int(p.intersects(union))
 out['in_both_circles']=int(all(p.intersects(c) for c in circles.values()))
 out['disputed_center_exposure']=int(len({p.intersects(c) for c in circles.values()})>1)
 out['risk_policy']='IN_EITHER_CIRCULAR_ENVELOPE' if p.intersects(union) else 'OUTSIDE_BOTH_CIRCLES_OTHER_CHECKS_PENDING'
 rows.append(out)
site_df=pd.DataFrame(rows);site_df.to_csv(O/'F1_19_sites_dual_AIP_coordinate_audit.csv',index=False)
legrows=[]
for r in oldleg.itertuples(index=False):
 a=site_lookup[r.hub];b=site_lookup[r.destination]
 line=transform(fwd,LineString([(a.longitude,a.latitude),(b.longitude,b.latitude)]))
 out={'area':r.area,'hub':r.hub,'destination':r.destination,'straight_leg_km':r.straight_leg_km,
      'GSHHS_mainland_fraction_approx':round(line.intersection(malaysia_m).length/max(1,line.length),5),
      'DJI70_original_range_pass':r.DJI_within_70pct_vendor_distance_sensitivity,
      'Wing92_original_upper_range_pass':r.Wing_within_vendor_92km_upper_envelope}
 for n,c in circles.items():
  out[n+'_crosses_circle']=int(line.intersects(c))
  out[n+'_crosses_land_clip']=int(line.intersects(clipped[n]))
 out['crosses_either_circle']=int(line.intersects(union))
 out['crosses_both_circles']=int(all(line.intersects(c) for c in circles.values()))
 out['disputed_center_crossing']=int(len({line.intersects(c) for c in circles.values()})>1)
 out['excluded_by_union_conservative']=int(line.intersects(union))
 out['flight_authorized']='NO_EVIDENCE'
 legrows.append(out)
leg_df=pd.DataFrame(legrows);leg_df.to_csv(O/'F1_76_legs_dual_AIP_coordinate_audit.csv',index=False)

# Research-only 1km cell-centroid search for potential A alternative *search zones*, not hubs.
# Inputs frozen, no new order or routing generation; search window around original A area with 5km buffer.
ref=oldsite[oldsite.area=='A']
xys=[fwd(r.longitude,r.latitude) for r in ref.itertuples(index=False)]
import numpy as np
XY=np.array(xys)
minx,miny=XY.min(axis=0)-5000;maxx,maxy=XY.max(axis=0)+5000
search=[]
for x in np.arange(minx,maxx+1,1000):
 for y in np.arange(miny,maxy+1,1000):
  p=Point(float(x),float(y)); ll=inv(x,y)
  if not p.within(malaysia_m):continue
  if p.distance(malaysia_m.boundary)<600:continue # shoreline margin for intermediate geometry proxy
  if p.distance(union)<1000:continue # robust outside BOTH circles by 1km research margin
  dist=np.linalg.norm(XY-np.array([x,y]),axis=1)/1000
  search.append(dict(cell_id='',lat=round(ll[1],6),lon=round(ll[0],6),
                     nearest_original_A_anchor_km=round(float(dist.min()),3),
                     mean_original_A_anchor_km=round(float(dist.mean()),3),
                     min_dist_from_either_WMP228_circle_km=round(float(p.distance(union)/1000),3),
                     min_dist_from_GSHHS_coastline_km=round(float(p.distance(malaysia_m.boundary)/1000),3),
                     evidence='UNVERIFIED_1KM_SEARCH_CELL_NOT_LAUNCH_PAD',
                     airspace_check='ALL_OTHER_AIRSPACE_NOT_CLEARED',land_permission='NOT_VERIFIED',
                     road_access='NOT_CHECKED_FOR_NEW_CELL',landuse='NOT_SURVEYED'))
search.sort(key=lambda r:(r['mean_original_A_anchor_km'],r['nearest_original_A_anchor_km']))
for j,r in enumerate(search):r['cell_id']=f'A_RESEARCH_CELL_{j+1:03}'
search_df=pd.DataFrame(search);search_df.to_csv(O/'F1_A_alternative_1km_search_cells_NOT_SITES.csv',index=False)

# Wing early 2021 variant; do not merge with current 2026 Cargo datasheet, reserve 20% per old spec sheet secondary evidence
energy=[
 dict(model='DJI_FLYCART30_DUAL',variant='2024/25 dual-battery DJI 30kg delivery, official',nominal_pack_kwh=3.9688,
      test_payload_kg=0,range_test_km=28,reported_reserve_fraction=None,nominal_pack_over_test_range_kwh_per_km=3.9688/28,
      evidence='OFFICIAL_BATTERY_AND_TEST_RANGE__NO_MEASURED_WH',source='https://www.dji.com/uk/flycart-30/specs'),
 dict(model='DJI_FLYCART30_DUAL',variant='2024/25 dual-battery DJI 30kg delivery, official',nominal_pack_kwh=3.9688,
      test_payload_kg=30,range_test_km=16,reported_reserve_fraction=None,nominal_pack_over_test_range_kwh_per_km=3.9688/16,
      evidence='OFFICIAL_BATTERY_AND_TEST_RANGE__NO_MEASURED_WH',source='https://www.dji.com/uk/flycart-30/specs'),
 dict(model='WINGCOPTER198_LEGACY',variant='2021 version 04 via 2023 journal and Japanese ministry summary, NOT CURRENT CARGO',
      nominal_pack_kwh=1.628,test_payload_kg=5,range_test_km=75,reported_reserve_fraction=0.20,
      nominal_pack_over_test_range_kwh_per_km=1.628/75,
      evidence='SECONDARY_SOURCES_CITE_2021_SPEC__NO_MEASURED_WH',source='https://www.mdpi.com/2071-1050/15/2/1137'),
 dict(model='WINGCOPTER198_LEGACY',variant='2021 version 04 secondary range table, NOT CURRENT CARGO',
      nominal_pack_kwh=1.628,test_payload_kg=0,range_test_km=110,reported_reserve_fraction=0.20,
      nominal_pack_over_test_range_kwh_per_km=1.628/110,
      evidence='ARCHIVED_SPEC_SECONDARY_UNVERIFIED_AS_CURRENT',source='https://wingcopter.com/wp-content/uploads/2022/06/Specsheet-Wingcopter-198.pdf'),
 dict(model='WINGCOPTER198_CARGO_CURRENT',variant='current website up to 92 km, unknown test payload; NOT SAME AS 2021 version',
      nominal_pack_kwh=None,test_payload_kg=None,range_test_km=92,reported_reserve_fraction=None,
      nominal_pack_over_test_range_kwh_per_km=None,
      evidence='OFFICIAL_CURRENT_RANGE_ONLY__CURRENT_BATTERY_UNKNOWN',source='https://wsd.wingcopter.com/w198-cargo')]
edf=pd.DataFrame(energy)
edf['nominal_usable_budget_if_reported_kwh']=edf.apply(lambda r: r.nominal_pack_kwh*(1-r.reported_reserve_fraction) if pd.notna(r.reported_reserve_fraction) and pd.notna(r.nominal_pack_kwh) else float('nan'),axis=1)
edf['nominal_usable_over_test_range_kwh_per_km']=edf.apply(lambda r: r.nominal_usable_budget_if_reported_kwh/r.range_test_km if pd.notna(r.nominal_usable_budget_if_reported_kwh) else float('nan'),axis=1)
edf['NOT_actual_mission_kwh']=True
edf.to_csv(O/'F0_two_model_versioned_energy_evidence.csv',index=False)

# QA source cross-check and gate list
summ={
 'baseline_sites':len(site_df),'baseline_legs':len(leg_df),
 'official_coordinate_disagreement_m':round(geod.inv(CENTERS[list(CENTERS)[0]]['lon'],CENTERS[list(CENTERS)[0]]['lat'],CENTERS[list(CENTERS)[1]]['lon'],CENTERS[list(CENTERS)[1]]['lat'])[2],1),
 'sites_by_area_and_circle':{},'legs_by_area_and_circle':{},
 'A_1km_alternative_search_cells_total':len(search),'A_1km_high_priority_cells_sample_top10':10 if len(search)>=10 else len(search),
 'land_source':'bundled Basemap GSHHS intermediate-resolution (approx 0.5-2 km coastline positional variation; NOT official cadastral coastline)',
 'regulatory_status':'CONFLICTING_OFFICIAL_CENTER_LONGITUDES_AND_2026-10-28_LIVE_AIP_NOT_VERIFIED',
 'operational_permission':'NONE_ESTABLISHED','energy_calibrated_models':0,'energy_models_with_some_secondary_or_official_spec':2,
 'methods':'WGS84 -> UTM48N for distance geometry; 2NM circular envelop and GSHHS Malaysia mainland clipping; 1km exploratory mainland grid'}
for area in ['A','B']:
 s=site_df[site_df.area==area];l=leg_df[leg_df.area==area]
 summ['sites_by_area_and_circle'][area]={n:dict(circle=int(s[n+'_in_circular_envelope'].sum()),land_clip=int(s[n+'_in_GSHHS_land_clip'].sum())) for n in CENTERS}
 summ['sites_by_area_and_circle'][area].update(disputed=int(s.disputed_center_exposure.sum()),either=int(s.in_either_circle.sum()),both=int(s.in_both_circles.sum()))
 summ['legs_by_area_and_circle'][area]={n:dict(circle=int(l[n+'_crosses_circle'].sum()),land_clip=int(l[n+'_crosses_land_clip'].sum())) for n in CENTERS}
 summ['legs_by_area_and_circle'][area].update(disputed=int(l.disputed_center_crossing.sum()),either=int(l.crosses_either_circle.sum()),both=int(l.crosses_both_circles.sum()))
assert len(site_df)==19 and len(leg_df)==76 and all(site_df.disputed_center_exposure.isin([0,1]))
assert not any(edf.loc[edf.model=='WINGCOPTER198_CARGO_CURRENT','nominal_pack_kwh'].notna())
assert sum(site_df.area=='A')==9 and sum(leg_df.area=='A')==28
(O/'F0F1_boundary_energy_reaudit_QA.json').write_text(json.dumps(summ,indent=2,ensure_ascii=False),encoding='utf8')
# geojson envelope, land-clipped, search cells
features=[]
for name,geom in circles.items():
 features.append({'type':'Feature','properties':{'name':name,'kind':'FULL_CIRCLE_SENSITIVITY_NOT_OFFICIAL_BOUNDARY'},'geometry':mapping(transform(inv,geom))})
for name,geom in clipped.items():
 if not geom.is_empty:features.append({'type':'Feature','properties':{'name':name,'kind':'GSHHS_i_LAND_CLIPPED_APPROX_NOT_OFFICIAL_BOUNDARY'},'geometry':mapping(transform(inv,geom))})
for r in search[:20]:
 features.append({'type':'Feature','properties':{'id':r['cell_id'],'kind':'UNVERIFIED_GRID_CELL_NOT_SITE','mean_ref_dist_km':r['mean_original_A_anchor_km']},'geometry':mapping(Point(r['lon'],r['lat']))})
for r in oldsite.itertuples(index=False):
 features.append({'type':'Feature','properties':{'site':r.site_id,'name':r.place_name,'area':r.area,'kind':'ORIGINAL_REFERENCE_NOT_SITE'},'geometry':mapping(Point(r.longitude,r.latitude))})
(O/'F1_A_discrepant_WMP228_and_candidate_research_cells.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False),encoding='utf8')
print(json.dumps(summ,ensure_ascii=False,indent=2))
