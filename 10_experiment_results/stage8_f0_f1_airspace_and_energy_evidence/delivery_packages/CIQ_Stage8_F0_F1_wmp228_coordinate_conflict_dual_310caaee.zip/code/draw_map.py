from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from shapely.geometry import Point
from mpl_toolkits.basemap import Basemap
from pyproj import Transformer
from shapely.ops import transform
ROOT=Path(__file__).resolve().parents[1]
site=pd.read_csv(ROOT/'outputs/F1_19_sites_dual_AIP_coordinate_audit.csv')
search=pd.read_csv(ROOT/'outputs/F1_A_alternative_1km_search_cells_NOT_SITES.csv')
fig,ax=plt.subplots(figsize=(9,7))
m=Basemap(llcrnrlon=103.67,llcrnrlat=1.425,urcrnrlon=103.83,urcrnrlat=1.575,resolution='i',projection='cyl',ax=ax)
m.drawcoastlines(linewidth=.8);m.fillcontinents(alpha=.08)
trans=Transformer.from_crs('EPSG:32648','EPSG:4326',always_xy=True).transform
for lon,txt in [(103+44/60+33/3600,'CAAM eAIP 2025: 103 44 33 E'),(103+43/60+34/3600,'CAAS 2026 / older CAAM: 103 43 34 E')]:
 lat=1+28/60+45/3600
 x,y=Transformer.from_crs('EPSG:4326','EPSG:32648',always_xy=True).transform(lon,lat)
 poly=transform(trans,Point(x,y).buffer(3704,resolution=160)); X,Y=poly.exterior.coords.xy
 ax.plot(X,Y,label=txt,linewidth=1.8)
 ax.plot(lon,lat,marker='x',markersize=7)
A=site[site.area=='A'];B=site[site.area=='B']
ax.scatter(A.lon,A.lat,marker='o',s=34,label='A original reference anchors (NOT pads)')
ax.scatter(B.lon,B.lat,marker='^',s=35,label='B original reference anchors (NOT pads)')
if len(search):ax.scatter(search.lon[:10],search.lat[:10],marker='s',s=32,facecolors='none',edgecolors='C4',label='10 highest ranked 1-km search cells (NOT sites)')
for row in A.itertuples(index=False):ax.annotate(row.site_id,(row.lon,row.lat),xytext=(3,2),textcoords='offset points',fontsize=8)
ax.set_xlabel('Longitude (WGS84)');ax.set_ylabel('Latitude (WGS84)')
ax.set_title('WMP228 OFFICIAL SOURCE COORDINATE CONFLICT - screening scenarios\n2-NM circular envelopes; coastal clip NOT shown; not a legal airspace chart',fontsize=11)
ax.legend(fontsize=7,loc='upper left',framealpha=.9)
ax.grid(alpha=.16)
fig.tight_layout()
fig.savefig(ROOT/'figures/F1_WMP228_two_conflicting_official_centers_and_search_cells.png',dpi=175)
plt.close(fig)
