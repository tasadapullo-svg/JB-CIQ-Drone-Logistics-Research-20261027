from pathlib import Path
from artifact_tool import Workbook,SpreadsheetFile
import pandas as pd
R=Path(__file__).resolve().parents[1]
W=Workbook.create()
def data_sheet(name,path,cols=None,width=20):
    df=pd.read_csv(R/'outputs'/path).replace({float('nan'):None})
    if cols is not None:df=df[cols]
    sh=W.worksheets.add(name)
    matrix=[df.columns.tolist()]+[[None if pd.isna(v) else (int(v) if isinstance(v,bool) else v) for v in row] for row in df.itertuples(index=False,name=None)]
    if matrix:sh.get_range_by_indexes(0,0,len(matrix),len(matrix[0])).values=matrix
    sh.get_range_by_indexes(0,0,1,len(df.columns)).format={'fill':'#18324D','font':{'bold':True,'color':'#FFFFFF'},'row_height':30,'wrap_text':True}
    sh.get_range_by_indexes(0,0,len(matrix),len(df.columns)).format.column_width=width
    sh.get_range_by_indexes(0,0,1,len(df.columns)).format.row_height=40
    sh.freeze_panes.freeze_rows(1)
    return sh
s=W.worksheets.add('Summary')
s.get_range('A1:D1').values=[['F0 / F1 Stage 8: Evidence Recheck (28 Oct 2026)',None,None,None]]
s.get_range('A1:D1').format={'fill':'#18324D','font':{'bold':True,'color':'#FFFFFF'},'row_height':32}
rows=[
 ['Item','Causeway A','Second Link B','Interpretation'],
 ['Original reference anchors',9,10,'NOT verified launch pads'],
 ['Original reference links',28,48,'NOT authorized routes'],
 ['CAAM 2025: circular exposure points',9,0,'Coordinate 103°44′33″E'],
 ['CAAS 2026/older CAAM: circular exposure points',2,0,'Coordinate 103°43′34″E'],
 ['Point-level disagreements',7,0,'Cannot freeze legality'],
 ['CAAM 2025: affected straight legs',28,0,'Only 2NM circle'],
 ['CAAS 2026/older CAAM: affected straight legs',13,0,'Only 2NM circle'],
 ['Leg-level disagreements',15,0,'Needs definitive AIP/NOTAM'],
 ['GSHHS i approximate coastline clipped, CAAM 2025',6,0,'NOT official coast polygon'],
 ['GSHHS i approximate coastline clipped, CAAS 2026',1,0,'NOT official coast polygon'],
 ['Additional 1-km exploratory search-cell centroids',41,None,'NOT sites; ground access/airspace unknown'],
 ['Energy-calibrated model count',0,None,'No measured mission-specific Wh'],
 ['Current Wingcopter 198 Cargo pack Wh',None,None,'Unknown; 1,628 Wh is historical 198 version'],
 ['Full F0 / F1 closure','NO','NO','F2–F4 deployment results blocked']]
s.get_range_by_indexes(2,0,len(rows),4).values=rows
s.get_range('A3:D3').format={'fill':'#D8E4ED','font':{'bold':True,'color':'#18324D'}}
s.get_range('A1:A18').format.column_width=50
s.get_range('B1:C18').format.column_width=18
s.get_range('D1:D18').format.column_width=58
s.get_range('A3:D18').format.wrap_text=True
s.freeze_panes.freeze_rows(3)
site_cols=['site_id','area','place_name','lat','lon','CAAM_2025_EAIP_E1034433_in_circular_envelope','CAAM_LEGACY_CAAS_2026_E1034334_in_circular_envelope','disputed_center_exposure','CAAM_2025_EAIP_E1034433_in_GSHHS_land_clip','CAAM_LEGACY_CAAS_2026_E1034334_in_GSHHS_land_clip','risk_policy']
data_sheet('19 site boundary audit','F1_19_sites_dual_AIP_coordinate_audit.csv',site_cols,width=22)
leg_cols=['area','hub','destination','straight_leg_km','DJI70_original_range_pass','Wing92_original_upper_range_pass','CAAM_2025_EAIP_E1034433_crosses_circle','CAAM_LEGACY_CAAS_2026_E1034334_crosses_circle','disputed_center_crossing','CAAM_2025_EAIP_E1034433_crosses_land_clip','CAAM_LEGACY_CAAS_2026_E1034334_crosses_land_clip']
data_sheet('76 leg sensitivity','F1_76_legs_dual_AIP_coordinate_audit.csv',leg_cols,width=22)
data_sheet('A search cells NOT sites','F1_A_alternative_1km_search_cells_NOT_SITES.csv',width=23)
en=data_sheet('Two model energy sources','F0_two_model_versioned_energy_evidence.csv',width=30)
# Additional model-ground thresholds with traceable formula; each kilometer of ground distance truly replaced.
sh=W.worksheets.add('Carbon thresholds')
sh.get_range('A1:E1').values=[['Ground vehicle','Fuel L per 100km','Petrol CO2e kg per L','Grid kg CO2e per kWh','Electricity threshold Wh per 1 km ground avoided']]
sh.get_range('A1:E1').format={'fill':'#18324D','font':{'bold':True,'color':'#FFFFFF'},'row_height':40,'wrap_text':True}
sh.get_range('A2:D4').values=[['125cc hypothetical scooter',2.0,2.06916,0.74],['1.6L hypothetical petrol car',6.6,2.06916,0.74],['1.8L hypothetical petrol car',6.3,2.06916,0.74]]
for i in range(2,5):sh.get_range(f'E{i}').formulas=[[f'=B{i}/100*C{i}/D{i}*1000']]
sh.get_range('A6:E7').values=[['Interpretation','This is MAX drone electricity budget before added ground, van, charging, facilities and idle energy.',None,None,None],['Not a deployability proof','Actual distance saved, vehicle occupancy, route changes and full system effects must be measured.',None,None,None]]
sh.get_range('A1:A7').format.column_width=30
sh.get_range('B1:D7').format.column_width=23
sh.get_range('E1:E7').format.column_width=37
sh.get_range('A1:E7').format.wrap_text=True
sh.get_range('E2:E4').set_number_format('0.00')
print(W.inspect({'kind':'table','range':'Carbon thresholds!A1:E4','include':'values,formulas','table_max_rows':6,'table_max_cols':6}).ndjson[:1500])
SpreadsheetFile.export_xlsx(W).save(str(R/'F0_F1_空域坐标冲突_机型能耗证据_空间搜索.xlsx'))
print('saved',R/'F0_F1_空域坐标冲突_机型能耗证据_空间搜索.xlsx')
