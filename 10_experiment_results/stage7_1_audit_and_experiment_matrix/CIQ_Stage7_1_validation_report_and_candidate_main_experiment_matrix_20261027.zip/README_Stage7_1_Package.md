# CIQ Stage 7.1 Deliverables

Status: Stage6 baseline frozen; Stage7.2 candidate matrix PROVISIONAL pending validation.

- CIQ_Stage7_1_审计与实验矩阵_20261027.xlsx — six sheets: Overview, Matrix, Parameters, Metric_Dictionary, Sensitivity_Evidence, QA_Evidence.
- stage7_1_validation_report.md — independent static and ledger audit; key risks.
- stage7_1_frozen_protocol.md — preregistered Stage7.2 evaluation rules, preserved limitations.
- stage7_1_experiment_matrix.csv — 12 controlled candidate configurations, 6 archived baselines + 6 unrun configurations.
- stage7_1_model_inventory.csv — mode-specific workflow and implementation functions.
- stage7_1_parameter_registry.csv — 47 Stage6 implemented parameter facts.
- stage7_1_metric_dictionary.csv — formulas and evaluation scope.
- stage7_1_existing_sensitivity_evidence.csv — previously run B/one-day sensitivity.
- stage7_1_status_counts.csv — status distributions.
- stage7_1_independent_QA.json — counters, hashes, line-accounting verification.
- stage7_1_sample_replay.json — 4 sampled groups, 1188 rows, zero differences.

No files in the uploaded Stage6 ZIP were modified. All summaries are based on the actual uploaded Stage6 code and archived data.
