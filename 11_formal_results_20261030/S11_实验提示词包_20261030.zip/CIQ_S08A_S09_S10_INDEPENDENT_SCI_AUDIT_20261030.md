# CIQ V5 S08A–S09–S10 独立科研审计报告

审计日期：2026-10-30。状态：COMPUTATION_REVIEWED / SCI_CONDITIONAL / FINAL_CARBON_CLAIM_HOLD。

## 0. 范围与核验层级

输入：用户上传的 S08A、S09、S10 和 FINAL_HANDOFF 四个 ZIP，附带的最终状态矩阵、测试日志；交叉参照本项目已上传 S07/S08 的代码及文件。

已独立执行：四 ZIP 的 SHA-256、ZIP CRC 和内部 SHA manifest；读取并核验 S10 的 413,100 条模式订单 CSV、22,950 条模式场景 CSV、S10 配对统计 CSV、S09 拒绝原因/敏感性 CSV、S08A 审计 JSON；查看 S08A/S09/S10 的 Python 实现代码和测试脚本；按订单服务路径、月份、场景和原 M0 匹配订单重新统计。

限制：当前独立环境缺少 PyArrow/Parquet 引擎，未重新逐行解码 S09 全部 165,240 条 Parquet、S10 644,903 条道路物理路段 Parquet、55,246 次飞行 Parquet；它们的结构计数与物理核算来自源码及 QA，不能说完成了二次独立逐行审计。未在新环境重跑完整仿真（需要完整历史工作区和 Python 依赖）。

## 1. 可确认已完成事项

- 四 ZIP SHA256 与用户登记完全一致，CRC 正常，manifest 比对异常 0。S08A/S09/S10/联合包清单文件 12/16/27/18。
- S08A 独立账本输出：82,620 订单、4,590 场景、179,010 物理行程段、13,770 行程、165,240 取送事件；报告的唯一键、负距离、时间、回仓、燃油、TTW CO2 与成本残差通过。原始 S08 未覆盖。
- S09 生成两机型各 82,620 行任务技术候选；条件性可调度 DJI 23,161、Wing 16,233；场地许可、航路审批、任务级机型能耗仍 HOLD。
- S10：22,950 模式场景，413,100 订单；CSV 的主键、准时标签、时长非负以及模式汇总再次确认一致。
- 30 随机种子重复汇总不得称为一次五个月运营实际排放：M0 平均每五个月 19.433 t，M1-DJI 17.906 t，M1-WING 18.202 t，M2-DJI 13.197 t，M2-WING 13.548 t（均为汽油TTW+电网GHG的非对称情景指标）。

## 2. 独立检查发现的关键科学缺口

### P0-1. 调度后天气未重算（必须修改）

- S09 `run_s09_mission_simulation.py` 大约 106–175 行，在 `release_utc` 的整点取得始发天气，用该时间构造预计目的地天气。
- S10 `run_s10_five_mode.py` 的 M1 `start=max(release,station_available)`，M2 `ready=max(vehicle_at_origin,release)+5 min`，实际起飞时间可以晚于 release 数小时。
- S10 直接复用 S09 的 `conditional_schedule_eligible`，未按实际 `start/ready`、完整去返航时刻重查风雨；也未因真实起飞时变为禁飞而重调度/回退。
- 重要的是 S09 同样尚未充分核验返航起降时刻的天气：S09 用释放小时始发 + 预计到达小时目的地筛查，不能等同于四个实际时空节点均通过。

**修正**：在 S10 事件调度器中按预计发射时间、实际目的地到达时间、返航发射/到达时间重新查询 10m 风/阵风/降雨；检查离散小时跨界和天气缺失；不合格则等待/地面回退/任务逾期，并输出完整可复算时空天气账本。同步记录原始 release-screen 与 actual-launch-screen 的差异率。

### P0-2. 天气空间放宽决定大部分 UAV 执行（必须做严格情景）

- S09 源码 `conditional_eligible=technical_ok & weather_relaxed_ok & ...`，未排除 `grid_gt10km_warning`。
- DJI：条件性执行 23,161；S09 `FEASIBLE_CONDITIONAL` 严格空间且其他筛查合格 2,631。差额 20,530，即 88.64% 的现有可调度候选带 >10 km 空间警示。
- Wing：条件性执行 16,233；严格空间候选 1,766。差额 14,467，即 89.12%。
- `reason_code=WEATHER_SPATIAL_HOLD` 同时可能被 `conditional_schedule_eligible=True`，需改写为多轴独立状态（TECHNICAL / WEATHER_SPATIAL / OPERATIONAL / LEGAL），避免审计误读。

**修正**：强制发布 STRICT_EXCLUDE_GT10KM、RELAXED_PROXY、ALTERNATIVE_WEATHER_SOURCE 三套成对五模式结果；S10 必须实际重调度并核算对应地面回退，而非仅变更 S09 计数。比较 30 种子、153 天、A/B/C 分区的效果。如果严格情景关键结论失效，论文必须改成空间条件敏感性结论。

### P0-3. M0、M1、M2 调度算法不同，无法将全部改善归于无人机（必须补控制组）

- M0：三策略多起点启发式；M1 fallback：单一 BATCH_PICKUPS；M2：逐订单、最早完成车辆选择的直接配送。求解预算和车辆工作组织不匹配。
- 独立匹配订单检查：M2-DJI 纯地面 59,459 单的准时率 96.46%；相同订单在 M0 为 90.44%，差 6.02 个百分点。这反映架构/调度影响，与无人机增量混杂。
- 原 M0 三车，M1 最多 11 固定站单机队列 + 三车，M2 三车各配一机；不可用无资源公平约束的均值论证技术最优。

**修正**：至少加入 M2_NO_UAV（完全相同 M2 车辆调度代码、数据和时间/资源，只禁止飞行），M1_NO_UAV（相同 fallback 调度），以及统一求解预算/双向公平算法敏感性。以增量 (M2_DJI–M2_NO_UAV) 与架构差异 (M2_NO_UAV–M0) 分离效应；同时重复 3车/3机 对等资源比较及至少1/2/3机敏感性。

### P0-4. M2 缺少显式连续任务电池 SOC 和补能等待（必须修改）

- S10 M1 固定站模拟 `charger_kw` 并将充电时间加到下一次发射可用时刻。
- M2 在完成本次任务后直接把车辆 `time=finish`，下一次可再次发射；没有每车无人机 SOC、备用电池数量、车载充电可行性、充电时间或换电时间约束。
- 全部 `grid_input_kwh` 计入排放，并不意味着在实际调度时间线上可用；因此 23,161 / 16,233 次飞行可能高估。

**修正**：每机每车独立 SOC、起飞前电量、任务耗电、最低 reserve、电池更换/车载充电/回站充电机制；明确充电来源和功率，约束车辆—无人机同步、操作员并发资源；无可用电量则等待/地面回退，重算成本、行程、准时率及排放。

### P1-1. 飞行任务能耗与风雨模型没有标定

DJI 的 3.9688 kWh 名义双电池、28/16km 测试航程，和 12 m/s 耐风来自厂商公开规格，但目前 kWh/km 用最大名义试验航程反推，未反映任务载荷、爬升、悬停、风、绕障、热、降雨和电池老化。Wing 的 0.10/0.08 kWh/km 是研究情景，并非认证测量，92km 是“up to”边界；Wing 目前只执行距离上界筛选，没有基于已标定电池容量的 SOC 能量约束。须补不同载荷×风速×距离×充电效率×reserve 的联合不确定性模拟，以及整条 S10 链路重跑；仅 S09 energy_sum 的敏感性 CSV 不足。

### P1-2. 人工与运营成本口径不一致

M1 将无人机任务时长按 15 MYR/h 记入 `uav_operator_hours`；M2 将该字段固定为 0，默认无人机由车组运营。但驾驶员能否合法/同时承担监控和调度责任、司机在等待时人工是否持续计费、监管要求几位操作员，均无证据。M1 单站 7.2/2kW 与 M2 充电设施未建立同等资源/成本边界。部分 OPEX 不含机体、备电池、固定站、保养、地租、保险、监管与折旧。必须统一底层科目，计算盈亏平衡额和合理区间；在无证据时不能声称“全成本最优”。

### P1-3. 30小时窗口和最大工时不可作为实证班次

S08A 报告表明 13,753/13,770 车次超过 8 小时，13,687 超过 12 小时，3,522 超过 24 小时，463 超过 30 小时；原 M0 平均车活跃 22.65 小时。S10 M2 未见同口径的 1800分钟调度入口限制。需要对全部模式做 8/12/24/30h 车辆运营窗口 + 司机换班/补班敏感性，订单未完成也必须保留于分母，不能通过无限延期伪造100%完成率。若使用24h运营+换班，需用独立司机调班成本。

### P1-4. 2026 历史空间与监管来源缺口

2026 研究期 OSM 路网当前快照而非历史，FCD 无方向观察，21/68 节点道路接入候选 >100m；全部站点真实出入口、权属、障碍、禁飞及起降许可待证。WMP228 参考圆不是经历史有效日期验证的官方法定禁飞边界，零相交只证明此代理几何下相交为0。应以 CAAM 对 2026-05 至 2026-09 实际有效 eAIP/AMDT 与其他适用公告作证据分层 GIS 复核；合规无法取得则在论文中明确“假设候选，不代表批准航路”。不得修改历史实验节点坐标迎合结果。

### P1-5. 统计检验未覆盖结构性不确定性

S10 10,000 bootstrap 和 20,000 sign flip 按 30 种子聚类，Holm 4 对照比较，得极小模型内 p 值。这不是独立实地样本，不证明物理实施减排；同一日期跨种子共用历史天气，且时间自相关尚未通过周/月区块检验。需按日期/周区块、种子、季节、区域、气象严苛度以及联合参数不确定性报告效应区间、失效比例和 Pareto 可行域，并区分参数置信/不确定性区间。

### P1-6. 地面配送速率与排放口径

S10 使用 hourly departure cache，M0 则按真实出发分钟推进边时间。必须比较 exact dynamic start vs hourly cache 的小规模全路由复验，并明确替代近似的速度/时长/准时率影响。汽油排放为 TTW CO2，电力为电网生成端 GHG 因子 kgCO2e，非对称系统边界；仅可标注 `PETROL_TTW_CO2_PLUS_GRID_GENERATION_GHG_PROXY` 或另建对称 WTW/使用阶段 GHG 边界，不能称完整 WTW/LCA。马来半岛 2024 官方临时 GEF 0.740 是可追溯资料，但跨至 2026 属代理假设。

### P1-7. CIQ 研究主线外推边界

`S09_GIS_AIRSPACE_AUDIT.json` 报告全部 82,620 个任务 `MY_INLAND_SCENARIO_CIQ_WAIT_NOT_APPLICABLE`，这是一项 JB 口岸周边/CIQ 邻近本地物流网络条件性研究，不是已计入通关时间的跨境物流优化。后续标题、方法与 Fig.1/3 必须明确此范围；若要宣称 CIQ 拥堵溢出或跨境收益，须另增真实通关/排队和有法律许可的跨境任务，并作为扩展研究，不能靠现有订单推断。

### P2. 代码/测试覆盖不足

- S09 QA `S09_BOUNDARY_TESTS.json` 的若干测试只是常量表达式（例如 `pass=True`），未调用任务资格函数，不构成真正的单元测试。需要可注入天气、SOC、路径与许可场景的实际函数级 pytest；测试晚起飞天气变坏、跨小时返航、负风向、不可用电池、站点排队、司机换班、成本守恒、可用气象网格距离、两模式统一 ID。
- FINAL 的4项快速测试仅验证输出存在及摘要规则，不等同 30 种子全量复跑；提供环境 lock、input hash、Docker/requirements、fresh workspace 重放和 1~2 个场景逐事件独立求解器核验。
- SCI 图表需展示完整分布而不只汇总：模式准时率/能源/成本配对分布、分区、5个月时序、天气严格–放宽敏感性、资源等值与算法公平性、能源成本帕累托前沿。

## 3. 可报告的稳定初步计算结论

- M2-DJI 在 4,588/4,590 模式场景的当前能源代理小于 M0；M2-WING 在 4,585/4,590 更低。五个月每月汇总方向亦相同。这描述原模型内部的计算稳定性，并未消除 P0 与 P1 缺口。
- M1-DJI：9,504 无人机任务；M1-WING：6,348；M2-DJI：23,161；M2-WING：16,233。M2 的地面-only订单也在调度中明显改善，因此不能把总准时率提升全归因于 UAV。
- 按30种子五个月平均，M2-DJI 相对 M0 的 `partial OPEX` 差额为 MYR 32,348.89；这是新增全部 UAV/站点/人工/保险/折旧成本的模型情景盈亏临界预算，**不是已证明的利润或真实投资回报**。M2-WING 对应 MYR 30,931.58。气象严格、调度公平、SOC 约束修订后必须重新计算。

## 4. 下一轮执行顺序和硬门槛

| 节点 | 必交付输出 | 门槛 |
| --- | --- | --- |
| G11-0 输入与代码冻结 | S07–S10 SHA registry, version graph, no overwrite test | PASS 才动工 |
| G11-1 实际起飞天气 | launch-time weather ledger, strict vs relaxed rerun, full mission dynamic checks | PASS/CONDITIONAL；结果改变须透明报告 |
| G11-2 充电资源 | vehicle-borne SOC/charging/swap, station queue, operator constraints | 物理守恒、零超售 |
| G11-3 公平对照 | M2_NO_UAV/M1_NO_UAV, equal budget, equal vehicles/UAV resources | 增量 UAV 效应可单独测量 |
| G11-4 全链路敏感性 | Wing energy/aircraft/reserve/wind/weather/hours/grid/fuel/cost, per-zone, per-month | 每场景真实重算；不准只线性重标总表 |
| G11-5 可比排放和成本 | well-defined scopes, scenario capital/maintenance/operator break-even | 均标注假设与证据级别 |
| G11-6 统计与再现性 | paired block/hierarchical uncertainty, reproducibility bundle, executable tests | SCI_CONDITIONAL 修订发布 |
| G11-7 GIS & factual constraints | historical applicable airspace / local no-go / node entrance / data source provenance | 如无法独立验证，现实可部署主张继续 HOLD |

## 5. SCI 文字边界（在补充前）

允许：`Under frozen synthetic-demand and historical weather/traffic proxy assumptions, the current M2 simulation produced lower modeled operating-energy emissions and improved on-time performance than the chosen M0 benchmark.`

不允许：`The drones achieved validated real-world significant carbon reductions or complete cost optimality in Johor Bahru's CIQ operations.`

## 6. 核验的外部原始资料

- DJI 官方参数：https://www.dji.com/flycart-30/specs
- Wingcopter W198 Cargo 官方参数：https://wsd.wingcopter.com/w198-cargo
- 马来西亚能源委员会 2022–2024 临时 GEF：https://myenergystats.st.gov.my/documents/d/guest/grid-emission-factor-gef-in-malaysia-2022-2024-provisional-
- CAAM 官方 eAIP ENR 5.1 历史实例：https://aip.caam.gov.my/aip/eAIP/2025-12-02/html/eAIP/WM-ENR-5.1-en-MS.html

审核边界：本报告不是实飞标定/民航许可/运营企业核算报告。
