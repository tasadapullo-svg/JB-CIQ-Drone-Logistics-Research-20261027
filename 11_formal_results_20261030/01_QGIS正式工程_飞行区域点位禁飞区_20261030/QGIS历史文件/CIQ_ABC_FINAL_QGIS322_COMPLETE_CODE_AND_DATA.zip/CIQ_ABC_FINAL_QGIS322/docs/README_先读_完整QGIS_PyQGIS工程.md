# CIQ A / C / B — QGIS 3.22.4 最终整合代码包（空间审核版）

**发布日期：2026-10-29。性质：科研空间设计与几何审计，不是法定飞行许可、航路图或实际可执行无人机物流调度方案。**

## 1. 文件结构

```text
CIQ_ABC_FINAL_QGIS322/
├── data/
│   ├── CIQ_ABC_FINAL_EDITABLE.gpkg          # 所有持久化 GIS 图层，EPSG:4326
│   ├── ALL_68_STUDY_NODES_LONG_LAT.csv     # 68 个研究参考点的经纬度与角色
│   ├── V7_ALL_62_NODE_EVIDENCE.csv
│   ├── V7_ALL_111_EDGE_AUDIT.csv
│   ├── V7_PRIORITY_12_SITE_GATES.csv
│   ├── V8_PORT_6_NODE_EVIDENCE.csv
│   └── V8_PORT_10_EDGE_AUDIT.csv
├── code/
│   ├── 01_BUILD_COMPLETE_QGIS322.py         # 在 QGIS 3.22.4 Python 控制台运行
│   ├── 02_AUDIT_INPUTS_PLAIN_PYTHON.py      # 普通 Python 中可运行的纯数据验收
│   ├── 03_OFFLINE_VECTOR_PREVIEW.py         # 可选：静态几何 QA 制图，需 geopandas/matplotlib
│   └── RUN_ONE_LINE_IN_QGIS_CONSOLE.txt
├── figures/                                # 先行绘制的离线几何 QA 图片
├── qa/                                     # 计数、完整性、独立距离核验报告
└── exports/                                # QGIS 一键脚本执行后导出的布局 PNG
```

**`.qgz` 生成方式**：解压后，在装有 QGIS 3.22.4 的计算机上执行主脚本，自动生成 `CIQ_ABC_FINAL_REVIEW.qgz`。本交付环境没有 QGIS 3.22 的运行库，所以没有伪造尚未实际运行生成的 `.qgz` 文件。

## 2. 一键运行（QGIS Python 控制台，不是 Android QPython）

1. **完整解压** ZIP 至例如 `D:\CIQ_ABC_FINAL_QGIS322`，不要单独移动 `.gpkg` 或 `.py`。
2. 启动 **QGIS Desktop 3.22.4**，先保存手头其他项目。**主脚本将清空当前 QGIS 工程的已载入图层**，但不会修改交付包中的冻结 B 区原始数据。
3. 在 QGIS 菜单 `插件 → Python 控制台` 输入：

```python
p = r"D:\CIQ_ABC_FINAL_QGIS322\code\01_BUILD_COMPLETE_QGIS322.py"
exec(compile(open(p, encoding="utf-8").read(), p, "exec"), {"__file__": p})
```

4. 脚本载入全部图层、设置分类样式与标签、创建三套 QGIS 布局：总览、A/C/B 局部、CIQ–Stulang 放大；再尝试导出 `exports/01...png` 等。**打印布局和 OSM 在线瓦片需要在本机检查**。保存后的 `CIQ_ABC_FINAL_REVIEW.qgz` 可再次打开。
5. 可选：在普通 Python 环境运行 `python code/02_AUDIT_INPUTS_PLAIN_PYTHON.py`，仅需标准库，不会修改节点或线路。

如要查看所有节点编号，在 QGIS 图层树中启用 `06 OPTIONAL ALL NODE LABELS`，否则地图默认只显示重点候选点，避免文字重叠。`05 UAV REACH` 默认关闭：可自行启用 DJI 与 Wingcopter 的独立情景圈，但不能称为准许飞行的空域。

## 3. 现阶段的准确数据含义

| 研究对象 | 数据量 | 定义 |
|---|---:|---|
| A/C/B V7 保留参考节点 | 62 | A=23、C=29、B=10；B 原始坐标保持不变；A11 不恢复 |
| V8 近 CIQ 港区补充点 | 6 | 1 个停车场候选地块搜索点，5 个地面/需求参考点 |
| 额外 CIQ 关口点 `G_CIQ` | 1 | 仅代表地面通关口岸，不计入 UAV 站点 |
| V7 原几何连接 | 111 | UAV 研究候选几何线，并非航空批准航路 |
| V8 新候选 UAV 连接 | 5 | A_P01 连到 A03/A04/A07/A_C01/A_N01；所有端点仍需验证 |
| V8 地面交接线 | 5 | **直线示意**，非实际 OSM 道路最短路径 |
| V7 港区额外地面示意 | 4 | 单独保留，默认关闭，避免重复展示 |
| 模型航程圆 | 8 | 4 个优先调查位置 × DJI 5.6 km / Wing 32.2 km 的往返几何情景 |

**距离模型**：DJI FlyCart 30 与 Wingcopter 198 Cargo 仅使用前期论文假设的 5.6 km / 32.2 km 单程几何半径，来自各自厂商参考最大航程 × 0.7 ÷ 2。不同机型最大航程测试载荷与工况不匹配，且此模型**不是**实际任务级有效航程或电耗模型。

逐段初筛：在 **116 条 UAV 候选直线**中，DJI 示例 99 条范围内、17 条超出；Wingcopter 示例 116 条范围内。这不是可执行任务覆盖率。

## 4. 禁飞区与 GIS 监管核查

- `WMP228_history_two_discs`：CAAM 2025 / CAAS 2026 **历史完整 2 NM 圆形参考情景**。不能把两圆画成两处独立法定禁飞区，也不能视为 2026-10-29 生效法定空域边界；需核验现行 CAAM AIRAC ENR5.1、海岸线条款、AIP 附加修订和相关 NOTAM。
- `Senai_5NM_aerodrome_ADVISORY`：仅用于进一步识别机场邻近风险，不构成法定飞行许可结论，默认关闭。
- `AC_study_corridors_APPROX` 与 `B_geometric_display_envelope`：仅是科研显示包络，不是来自用户手绘区的精确数字化边界或官方行政界。
- `UAV_4_SITE_SEARCH_REACH_2_MODELS`：模型距离示意圈；未排除障碍、人口暴露或进出航道，也未考虑交接、悬停和补能损耗。

**所有节点均缺少足够的起降资格证据，所有 UAV 路线均缺少正式航空批准。** 保留节点是为了空间规划与未来情景模拟，不等于建站合规。

## 5. 实地和监管验收缺口（不得在地图中隐去）

1. 具体工业/停车场 **地籍宗地边界**及合法场地权属、进入许可、业主同意和实际车辆出入口；其中 A01 Swift Tebrau II 有 PLO137/138 资料线索，但没有实测起降坪坐标。
2. 每条航线的真实 3D 净空、高压线路、树木、建筑物、人口密度、地面风险和应急着陆场调查。
3. 码头和王宫附近的安保及通行约束；`A_P01` 仅为 OSM 现有停车场参考位置；`T_STULANG` 继续作为地面交接终点。
4. 两款 UAV 在同等载荷、风雨、储备电量、悬停、起降与补能条件下的任务级 Wh/km 和可执行飞行时长。
5. CAAM / CAAS 适用空域、运营类别、SUP/BVLOS 等批准及跨境许可（如涉及新加坡）。
6. 使用完整 OSM 可路由道路网络、车辆门口节点和已经核验方向匹配的 FCD 时变速度，才可以替换地面直线为真实交通路径。

本包**不重新生成订单，不重跑配送时间、成本、净碳排放实验，也不改变冻结 B 区原数据**。你在 QGIS 完成选址审批和空间审核后，才能确定哪些节点进入下一版真实约束实验。

## 6. 数据来源可追溯

- 工程底座：V7 `ABC_V7_PRESERVE_ALL_REVIEW.gpkg` + V8 `ABC_V8_ALL_V7_UNCHANGED_PLUS_CIQ_PORT.gpkg`；本交付以 **V8 合并文件作为唯一拷贝来源**，另外新增 1 个地面 CIQ 参考点、1 个 B 研究区几何显示包络和 8 个模型航程圆。
- 所有原始节点来源 URL 和证据等级均保留在 GeoPackage 属性表和 `data/*EVIDENCE.csv`。其中未验证的地理参考坐标不构成场地测绘坐标。
- 项目公开资料仓库：https://github.com/tasadapullo-svg/JB-CIQ-Drone-Logistics-Research-20261027

