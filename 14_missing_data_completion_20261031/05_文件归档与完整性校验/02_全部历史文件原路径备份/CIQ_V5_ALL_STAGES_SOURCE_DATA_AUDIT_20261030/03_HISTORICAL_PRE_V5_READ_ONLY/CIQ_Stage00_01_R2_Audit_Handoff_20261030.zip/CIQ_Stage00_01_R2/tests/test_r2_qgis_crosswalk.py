# Fixtures are SYNTHETIC_TEST_ONLY. Never included in a research result.
import sqlite3, struct, tempfile, sys, csv
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from r2_qgis_crosswalk import run, gpkg_point

def gp_point(x,y):
    return b'GP'+bytes([0,1])+struct.pack('<I',4326)+b'\x01'+struct.pack('<I',1)+struct.pack('<dd',x,y)

def gp_line(points):
    coords=b''.join(struct.pack('<dd',x,y) for x,y in points)
    return b'GP'+bytes([0,1])+struct.pack('<I',4326)+b'\x01'+struct.pack('<I',2)+struct.pack('<I',len(points))+coords

def check():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td);work=p/'study';work.mkdir(); out=p/'evidence'
        gp=work/'network.gpkg'
        con=sqlite3.connect(gp)
        con.executescript('''CREATE TABLE gpkg_contents(table_name TEXT,data_type TEXT,identifier TEXT,description TEXT,last_change TEXT,min_x REAL,min_y REAL,max_x REAL,max_y REAL,srs_id INTEGER);
        CREATE TABLE gpkg_geometry_columns(table_name TEXT,column_name TEXT,geometry_type_name TEXT,srs_id INTEGER,z INTEGER,m INTEGER);
        CREATE TABLE nodes (fid INTEGER PRIMARY KEY,node_id TEXT,name TEXT,area TEXT,geom BLOB);
        CREATE TABLE edges (fid INTEGER PRIMARY KEY,link_id TEXT,from_id TEXT,to_id TEXT,area TEXT,geom BLOB);
        ''')
        con.executemany('INSERT INTO gpkg_contents(table_name,data_type,srs_id) VALUES (?, ?, ?)', [('nodes','features',4326),('edges','features',4326)])
        con.executemany('INSERT INTO gpkg_geometry_columns VALUES (?,?,?,4326,0,0)', [('nodes','geom','POINT'),('edges','geom','LINESTRING')])
        con.executemany('INSERT INTO nodes (node_id,name,area,geom) VALUES (?,?,?,?)',[
            ('A01','site A','A',gp_point(103.7,1.4)),('B01','site B','B',gp_point(103.6,1.3)),('C21','site C','C',gp_point(103.8,1.42))])
        con.execute('INSERT INTO edges (link_id,from_id,to_id,area,geom) VALUES (?,?,?,?,?)',('L1','A01','B01','A',gp_line([(103.7,1.4),(103.6,1.3)])))
        con.commit();con.close()
        q=work/'ciq.qgs';q.write_text('<qgis><projectCrs><spatialrefsys><authid>EPSG:4326</authid></spatialrefsys></projectCrs><projectlayers><maplayer><id>nl</id><layername>nodes</layername><provider>ogr</provider><datasource>./network.gpkg|layername=nodes</datasource></maplayer><maplayer><id>el</id><layername>edges</layername><provider>ogr</provider><datasource>./network.gpkg|layername=edges</datasource></maplayer></projectlayers></qgis>',encoding='utf-8')
        old=p/'old.csv';old.write_text('site_id,area,longitude,latitude\nA01,A,103.7,1.4\nB01,B,103.6,1.3\nZ99,A,103.4,1.1\n',encoding='utf-8')
        r=run(q,old,out)
        assert r['counts']['qgis_nodes_candidates']==3,r
        assert r['counts']['qgis_edges_candidates']==1,r
        assert r['counts']['crosswalk_rows']==3,r
        assert r['status']=='HOLD_NOT_APPROVED'
        with (out/'old_new_node_crosswalk_REVIEW_REQUIRED.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
        assert rows[0]['status']=='ID_MATCH_COORD_WITHIN_20M_REVIEW_STILL_REQUIRED',rows
        assert rows[-1]['status']=='OLD_NODE_NOT_IN_NEW_NETWORK',rows
        x,y=gpkg_point(gp_point(103.7,1.4));assert (x,y)==(103.7,1.4)
        print('PASS: Synthetic fixture (3 nodes, 1 edge, 3 crosswalk statuses). NO scientific data used.')
if __name__=='__main__':check()
