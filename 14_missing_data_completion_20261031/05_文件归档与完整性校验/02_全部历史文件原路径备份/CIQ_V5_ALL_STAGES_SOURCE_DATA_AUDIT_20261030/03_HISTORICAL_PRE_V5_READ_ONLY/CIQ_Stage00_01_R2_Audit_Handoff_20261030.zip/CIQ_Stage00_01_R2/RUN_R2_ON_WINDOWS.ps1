# CIQ Stage 00/01 R2, READ-ONLY. Edit 4 paths; run in Windows PowerShell.
$Repo = 'D:\CIQ\JB-CIQ-Drone-Logistics-Research-20261027'
$QGIS = 'D:\CIQ\Latest_QGIS_3zones\project.qgz' # Replace with ACTUAL selected project
$OldNodes = 'D:\CIQ\Legacy_Stage8_19_site_reference_anchors.csv' # Replace if located
$Out = 'D:\CIQ_AUDITS\Stage00_01_R2'
$Scripts = Split-Path -Parent $MyInvocation.MyCommand.Definition
New-Item -ItemType Directory -Force -Path $Out | Out-Null
# R1: full SHA256 file listing, GIS source/layer checks, historical HEAD and .parts references.
py -3 "$Scripts\stage00_01_local_auditor_R1.py" --repo "$Repo" --qgis "$QGIS" --out "$Out\full_inventory"
# R2: GPKG candidate node/edge extraction and old-new ID/coordinate comparison.
if (Test-Path -LiteralPath $OldNodes) {
  py -3 "$Scripts\r2_qgis_crosswalk.py" --qgis "$QGIS" --old-nodes "$OldNodes" --out "$Out\crosswalk"
} else {
  py -3 "$Scripts\r2_qgis_crosswalk.py" --qgis "$QGIS" --out "$Out\crosswalk"
}
# From historical repo root: verify 13 split assets against historical hashes.
py -3 "$Repo\tools\reassemble_large_files.py" --verify-only *>&1 | Out-File -LiteralPath "$Out\large_asset_verification.log" -Encoding utf8
# These scripts return a NONZERO exit code for HOLD by design. Never change it to PASS silently.
Write-Host "Review: $Out ; Stage02 numeric experiments remain BLOCKED until formal approval."
