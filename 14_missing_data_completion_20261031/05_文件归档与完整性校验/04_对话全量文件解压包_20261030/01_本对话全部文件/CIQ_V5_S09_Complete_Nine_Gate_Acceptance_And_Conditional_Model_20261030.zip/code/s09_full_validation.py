#!/usr/bin/env python3
"""V5 S09: auditable conditional aircraft-task energy envelopes, never observed output.

Inputs are immutable V5 node/order/edge CSVs. Real flight feasibility/CO2 remain HOLD.
All battery/power settings are illustrative stress assumptions, not manufacturer calibrated
mission measurements. Related-variant 198 hardware specifications are NOT Cargo verified.
"""
from __future__ import annotations
import argparse, csv, gzip, hashlib, json, math
from collections import Counter,defaultdict
from dataclasses import dataclass
from pathlib import Path

LOCK_SHA={
 'S07_V5_SYNTHETIC_TASKS_CONDITIONAL_DESIGN.csv':'8cc9c4d20b78cb80bff4fa9fd69750e0b7c172d6f48d07a7880b224bf5ddecca',
 'S06_V5_68_NODE_MASTER_AUTHORITATIVE.csv':'6d10ce88b5d7770fa1a776bffb5c386655d9ccab18064138c06ce11ea9d756a9',
 'S06_V5_116_UAV_GEOMETRY_ONLY.csv':'1589b41e1ce20406d186faaa14df4c1ba74d4ffa5020104260d517ff418cc2e4',
 'V5_FROZEN_SOURCE.zip':'0d19633630b6f12525ad9bd776bbf966ec1e8a46520bd8bc3d904013b02dce74'
}

# Do not label this as empirical calibration. Parameters deliberately explicit and revisable.
AIRCRAFT={
 'DJI_FLYCART_30_DUAL': {
  'capacity_kg':30.0,'battery_nominal_kwh':3.9688,
  'airspeed_mps':15.0,'battery_variant':'DJI dual DB2000 rated nominal (OEM spec)',
  'power_levels':{'LOW':(3.1,1.6,0.04),'CENTRAL':(3.7,2.2,0.08),'HIGH':(4.6,3.0,0.15)},
  'evidence':'DJI OEM nominal battery, 16km loaded/28km empty ideal reference; scenario power is NOT OEM'
 },
 'WINGCOPTER_198_CARGO_ASSUMED': {
  'capacity_kg':4.7,'battery_nominal_kwh':1.628,
  'airspeed_mps':28.0,
  'battery_variant':'UNVERIFIED CARGO configuration: 2*814Wh from Wingcopter 198 Delivery Variant April 2021 only',
  'power_levels':{'LOW':(1.1,0.7,0.02),'CENTRAL':(1.7,1.2,0.04),'HIGH':(2.4,1.8,0.09)},
  'evidence':'Related Wingcopter 198 Delivery Variant 2021 has 5kg OEM payload; Cargo 4.7kg retained conservatively from frozen assumptions; not same certified configuration'
 }
}
POWER_META={
 'LOW':{'usable_fraction':0.9,'reserve_fraction':0.2,'charge_efficiency':0.92,'ground_overhead_minutes':3.0},
 'CENTRAL':{'usable_fraction':0.9,'reserve_fraction':0.25,'charge_efficiency':0.9,'ground_overhead_minutes':4.0},
 'HIGH':{'usable_fraction':0.85,'reserve_fraction':0.3,'charge_efficiency':0.85,'ground_overhead_minutes':6.0},
}
WINDS={'HEADWIND_OUTBOUND_5MPS':-5.0,'CALM_PROXY':0.0,'TAILWIND_OUTBOUND_5MPS':5.0}


def sha256(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()


def rows(path):
 with open(path,newline='',encoding='utf-8-sig') as f: yield from csv.DictReader(f)


def conditional_roundtrip(oneway_km,payload_kg,aircraft,level='CENTRAL',wind_name='CALM_PROXY',distance_multiplier=1.0):
 """Direct-OD out-and-back *illustration* only, not authorized M1 flight nor M2 rendezvous.

 Reverse leg equals one-way geometry length solely as synthetic modeling assumption.
 Destination takeoff/landing requires actual pad verification; not a real flight plan.
 """
 cfg=AIRCRAFT[aircraft]; par=POWER_META[level]
 if not all(math.isfinite(v) for v in (oneway_km,payload_kg,distance_multiplier)) or oneway_km<=0 or payload_kg<0 or distance_multiplier<1:
  raise ValueError('nonfinite or invalid mission geometry/payload')
 if payload_kg>cfg['capacity_kg']:raise ValueError('payload exceeds fixed study maximum')
 if wind_name not in WINDS:raise ValueError('unknown stress wind case')
 wind=WINDS[wind_name]; v=cfg['airspeed_mps']
 if v-abs(wind)<=0:raise ValueError('nonpositive groundspeed')
 d=oneway_km*distance_multiplier
 loaded_kw,empty_kw,start_end_energy=cfg['power_levels'][level]
 # Outbound and return wind are opposite for constant global wind vector.
 loaded_h=(d*1000)/(v+wind)/3600
 empty_h=(d*1000)/(v-wind)/3600
 flight_min=(loaded_h+empty_h)*60
 battery_kwh=loaded_h*loaded_kw+empty_h*empty_kw+start_end_energy
 usable_kwh=cfg['battery_nominal_kwh']*par['usable_fraction']
 budget_kwh=usable_kwh*(1-par['reserve_fraction'])
 grid_kwh=battery_kwh/par['charge_efficiency']
 return {'loaded_minutes':loaded_h*60,'empty_minutes':empty_h*60,
         'flight_minutes_proxy':flight_min,'service_minutes_proxy':flight_min+par['ground_overhead_minutes'],
         'battery_kwh_scenario':battery_kwh,'grid_recharge_kwh_scenario':grid_kwh,
         'reserve_adjusted_budget_kwh_scenario':budget_kwh,
         'battery_budget_screen_only':'PASS_CONDITIONAL' if battery_kwh<=budget_kwh+1e-12 else 'FAIL_CONDITIONAL',
         'nominal_battery_kwh_reference':cfg['battery_nominal_kwh'],
         'loaded_power_kw_assumed':loaded_kw,'empty_power_kw_assumed':empty_kw,
         'launch_landing_kwh_assumed':start_end_energy,
         'scenario_power_source':'ARTIFICIAL_SENSITIVITY_NOT_MEASURED',
         'flight_authorization':'HOLD','measured_weather':'HOLD','model_specific_calibration':'HOLD'}


def check_locks(root):
 d={}
 for name,expected in LOCK_SHA.items():
  p=root/name
  if not p.is_file():raise RuntimeError(f'missing frozen input {name}')
  got=sha256(p);d[name]={'sha256':got,'matches_frozen':got==expected,'bytes':p.stat().st_size}
  if got!=expected:raise RuntimeError(f'frozen V5 source modified: {name}')
 return d


def run(root:Path,out:Path):
 out.mkdir(parents=True,exist_ok=True)
 original=check_locks(root)
 node_list=list(rows(root/'S06_V5_68_NODE_MASTER_AUTHORITATIVE.csv'))
 nodes={r['node_id']:r for r in node_list}; assert len(nodes)==68 and len(node_list)==68
 edge_list=list(rows(root/'S06_V5_116_UAV_GEOMETRY_ONLY.csv'))
 assert len(edge_list)==116
 e={(r['from_id'],r['to_id']):r for r in edge_list}
 assert len(e)==116
 for a,b in e:assert a in nodes and b in nodes
 tasks=list(rows(root/'S07_V5_SYNTHETIC_TASKS_CONDITIONAL_DESIGN.csv'))
 assert len(tasks)==82620 and len({t['task_id'] for t in tasks})==82620
 cases=Counter(); model_count=defaultdict(Counter); scenario_tasks=defaultdict(list); zone_tasks=Counter()
 task_fields=['task_id','date_local','scenario_seed','origin_node_id','destination_node_id','origin_zone','destination_zone','parcel_kg','aircraft_model','static_payload_status','directed_candidate_status','candidate_edge_id','candidate_oneway_km','time_and_weather_evidence','flight_airspace_evidence','battery_hardware_reference','calibration_state','central_battery_kwh_DESIGN_ONLY','central_grid_kwh_DESIGN_ONLY','central_flight_minutes_DESIGN_ONLY','central_budget_screen_DESIGN_ONLY','real_mission_energy_kwh','real_operational_CO2e_kg','M1_actual_mission_status','M2_actual_mission_status']
 sens_fields=['task_id','aircraft_model','power_level','wind_assumption','flight_leg_pattern','payload_kg','oneway_geodesic_km','battery_kwh_DESIGN_ONLY','grid_kwh_DESIGN_ONLY','flight_minutes_DESIGN_ONLY','reserve_adjusted_budget_kwh','conditional_battery_budget_screen','meteorology','return_route','legal_flight','scenario_only']
 status_path=out/'S09_82620_TASKS_X_2_AIRCRAFT_STATIC_AND_CONDITIONAL.csv.gz'
 sens_path=out/'S09_DIRECT_GEOMETRY_POWER_WIND_3X3_SENSITIVITY_DESIGN_ONLY.csv.gz'
 with gzip.open(status_path,'wt',newline='',encoding='utf-8') as fd, gzip.open(sens_path,'wt',newline='',encoding='utf-8') as fs:
  sd=csv.DictWriter(fd,fieldnames=task_fields); sd.writeheader()
  ss=csv.DictWriter(fs,fieldnames=sens_fields); ss.writeheader()
  stress_count=0
  for t in tasks:
   o,d=t['origin_node_id'],t['destination_node_id']
   if o not in nodes or d not in nodes:raise RuntimeError('unfrozen task node')
   if nodes[o]['zone']!=t['origin_zone'] or nodes[d]['zone']!=t['destination_zone']:raise RuntimeError('zone mismatch')
   z=t['origin_zone'];zone_tasks[z]+=1
   seed,date=t['scenario_seed'],t['date_local'];scenario_tasks[(seed,date)].append(t['task_id'])
   w=float(t['parcel_kg']);edge=e.get((o,d));rev=e.get((d,o))
   link='DIRECTED_CANDIDATE_NOT_AUTHORIZED' if edge else ('REVERSE_ONLY_NOT_AUTHORIZED' if rev else 'NO_DIRECT_CANDIDATE__FEEDER_OR_MULTILEG_REQUIRED')
   cases[link]+=1
   for model in AIRCRAFT:
    cfg=AIRCRAFT[model]; payload='WEIGHT_ONLY_PASS' if w<=cfg['capacity_kg'] else 'WEIGHT_ONLY_FAIL__GROUND_FALLBACK'
    model_count[model][payload]+=1
    row={'task_id':t['task_id'],'date_local':date,'scenario_seed':seed,'origin_node_id':o,'destination_node_id':d,'origin_zone':z,'destination_zone':t['destination_zone'],'parcel_kg':w,'aircraft_model':model,'static_payload_status':payload,'directed_candidate_status':link,'candidate_edge_id':edge['edge_id'] if edge else '', 'candidate_oneway_km':edge['one_way_geodesic_km'] if edge else '',
         'time_and_weather_evidence':'EVENT_TIME_WEATHER_NOT_AVAILABLE','flight_airspace_evidence':'UNAPPROVED_GEOMETRY','battery_hardware_reference':cfg['battery_variant'],'calibration_state':'NOT_AIRCRAFT_MISSION_POWER_CALIBRATED','central_battery_kwh_DESIGN_ONLY':'','central_grid_kwh_DESIGN_ONLY':'','central_flight_minutes_DESIGN_ONLY':'','central_budget_screen_DESIGN_ONLY':'','real_mission_energy_kwh':'','real_operational_CO2e_kg':'',
         'M1_actual_mission_status':'HOLD_NO_STATION_ROUTE_AND_WEATHER','M2_actual_mission_status':'HOLD_NO_REAL_VEHICLE_RENDEZVOUS_AND_WEATHER'}
    if edge and payload=='WEIGHT_ONLY_PASS':
     length=float(edge['one_way_geodesic_km']); assert length>0
     central=conditional_roundtrip(length,w,model)
     row['central_battery_kwh_DESIGN_ONLY']=round(central['battery_kwh_scenario'],8)
     row['central_grid_kwh_DESIGN_ONLY']=round(central['grid_recharge_kwh_scenario'],8)
     row['central_flight_minutes_DESIGN_ONLY']=round(central['flight_minutes_proxy'],5)
     row['central_budget_screen_DESIGN_ONLY']=central['battery_budget_screen_only']
     model_count[model]['DIRECT_AND_WEIGHT_DESIGN_SCENARIO']+=1
     model_count[model][central['battery_budget_screen_only']]+=1
     for level in ('LOW','CENTRAL','HIGH'):
      for wind_case in WINDS:
       x=conditional_roundtrip(length,w,model,level,wind_case)
       ss.writerow({'task_id':t['task_id'],'aircraft_model':model,'power_level':level,'wind_assumption':wind_case,'flight_leg_pattern':'OUTBOUND_LOADED_REVERSE_GEOMETRY_RETURN_EMPTY_NOT_AUTHORIZED','payload_kg':w,'oneway_geodesic_km':length,'battery_kwh_DESIGN_ONLY':round(x['battery_kwh_scenario'],8),'grid_kwh_DESIGN_ONLY':round(x['grid_recharge_kwh_scenario'],8),'flight_minutes_DESIGN_ONLY':round(x['flight_minutes_proxy'],5),'reserve_adjusted_budget_kwh':round(x['reserve_adjusted_budget_kwh_scenario'],8),'conditional_battery_budget_screen':x['battery_budget_screen_only'],'meteorology':'SYNTHETIC_WIND_NOT_2026_ERA5','return_route':'NOT_VERIFIED','legal_flight':'NOT_VERIFIED','scenario_only':'YES_NOT_ACHIEVED_SERVICE_OR_CO2'})
       stress_count+=1
    sd.writerow(row)
    model_count[model]['task_model_rows']+=1
 assert len(scenario_tasks)==4590
 assert all(len(v)==18 and len(v)==len(set(v)) for v in scenario_tasks.values())
 summary={'stage':'S09','final_status':'HOLD_UNTIL_REAL_WEATHER_MODEL_CALIBRATION_FLIGHT_ROLE_AND_EVENT_TIME','frozen_input_sha256':original,'V5_nodes':len(nodes),'V5_candidate_geometry_edges':len(e),'fixed_task_count':len(tasks),'design_scenarios':len(scenario_tasks),'per_zone_orders':dict(zone_tasks),
 'direct_geometry_status_counts':dict(cases),'per_aircraft_counts':{k:dict(v) for k,v in model_count.items()},'conditional_sensitivity_rows':stress_count,
 'actual_independent_weather_recomputed':False,'actual_oem_Cargo_energy_calibrated':False,'verified_sites':False,'real_flight_corridors':False,'actual_M1_M2_missions_computed':0,'real_operational_carbon_computed':False,
 'official_vs_assumed_warning':'Wingcopter 198 Delivery Variant 04-2021: 5kg and 2x814Wh, whereas frozen Cargo study assumption is 4.7kg. Using 1.628kWh as related-variant battery proxy ONLY; no claim of Cargo hardware equivalence.',
 'non_operational_claim':'All kWh/min outputs are synthetic stress scenario proxies for direct candidates, not completed flights or actual real-world energy.',
 'no_source_orders_dropped':True}
 (out/'S09_QA_SCIENTIFIC_RELEASE_GATE.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
 with (out/'S09_BY_AIRCRAFT_SUMMARY.csv').open('w',newline='',encoding='utf-8-sig') as f:
  x=csv.writer(f);x.writerow(['aircraft','task_count','weight_pass','weight_fail','direct_and_weight_design_only','central_budget_screen_pass_design_only','central_budget_screen_fail_design_only','actual_weather_verified','real_mission_kwh_verified','S09_final_release'])
  for model,v in model_count.items():x.writerow([model, v['task_model_rows'],v['WEIGHT_ONLY_PASS'],v['WEIGHT_ONLY_FAIL__GROUND_FALLBACK'],v['DIRECT_AND_WEIGHT_DESIGN_SCENARIO'],v['PASS_CONDITIONAL'],v['FAIL_CONDITIONAL'],'NO','NO','HOLD'])
 with (out/'S09_SCENARIO_RUN_KEYS_FROZEN.csv').open('w',newline='',encoding='utf-8-sig') as f:
  x=csv.writer(f);x.writerow(['scenario_seed','date_local','task_count','frozen_task_id_sha256','S09_event_time_ready','M1_M2_scheduling_status'])
  for (seed,date),ids in sorted(scenario_tasks.items()):x.writerow([seed,date,len(ids),hashlib.sha256('\n'.join(sorted(ids)).encode()).hexdigest(),'NO','S10_NOT_RUN'])
 return summary

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--outputs',type=Path,required=True)
 args=p.parse_args();print(json.dumps(run(args.inputs,args.outputs),indent=2,ensure_ascii=False))
