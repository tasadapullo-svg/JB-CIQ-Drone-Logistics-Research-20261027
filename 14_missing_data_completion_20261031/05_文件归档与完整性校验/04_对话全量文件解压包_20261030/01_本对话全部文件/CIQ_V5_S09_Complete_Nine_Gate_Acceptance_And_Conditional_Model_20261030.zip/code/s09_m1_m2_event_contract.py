"""S09 -> S10 mission adapter: never infer flight events from order release or geometry.

S09 remains conditional and must not return actual kWh without source validation.
The valid mission specification is meant to be populated by S10 after routing and scheduling.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Sequence
from weather_event_contract import WeatherHour,weather_for_event,along_track_wind_mps
import math

@dataclass(frozen=True)
class FlightLeg:
    start_node: str
    end_node: str
    length_km: float
    bearing_degrees: float
    payload_kg: float
    launch_utc: datetime
    landing_utc: datetime
    weather_grid_id: str
    route_evidence: str

@dataclass(frozen=True)
class S10MissionRequest:
    task_id: str
    aircraft_model: str
    mode: str
    legs:tuple[FlightLeg,...]
    battery_variant_verified:bool
    power_model_calibrated:bool
    takeoff_landing_site_verified:bool
    charging_factor_verified:bool
    flight_permission_verified:bool

REQUIRED_EVIDENCE={'EVENT_TIME_WEATHER','AUTHORIZED_AIR_CORRIDOR','CALIBRATED_BATTERY_AND_POWER','APPROVED_LANDING_AND_LAUNCH','VERIFIED_CHARGE_INPUT'}


def validate_real_mission(req:S10MissionRequest, weather:Sequence[WeatherHour])->dict:
    """Strict evidence-gated integration, does not manufacture a flight/energy result.

    Returns a status and weather-vector diagnostics only; actual kWh is reserved
    to the independently calibrated power implementation.
    """
    missing=set()
    if req.mode not in ('M1','M2'):raise ValueError('mode must be M1 or M2')
    if not req.task_id or not req.aircraft_model or not req.legs:raise ValueError('nonempty task/model/legs required')
    if not req.battery_variant_verified or not req.power_model_calibrated:missing.add('CALIBRATED_BATTERY_AND_POWER')
    if not req.takeoff_landing_site_verified:missing.add('APPROVED_LANDING_AND_LAUNCH')
    if not req.charging_factor_verified:missing.add('VERIFIED_CHARGE_INPUT')
    if not req.flight_permission_verified:missing.add('AUTHORIZED_AIR_CORRIDOR')
    vectors=[]; prev_end=None
    for i,leg in enumerate(req.legs):
        if leg.length_km<=0 or not math.isfinite(leg.length_km):raise ValueError('invalid flight length')
        if leg.payload_kg<0 or not math.isfinite(leg.payload_kg):raise ValueError('invalid payload')
        if not math.isfinite(leg.bearing_degrees):raise ValueError('invalid bearing')
        if leg.launch_utc.tzinfo is None or leg.landing_utc.tzinfo is None or leg.landing_utc<=leg.launch_utc:raise ValueError('invalid UTC interval')
        if prev_end is not None and leg.launch_utc<prev_end:raise ValueError('overlapping aircraft events')
        if prev_end is not None and req.legs[i-1].end_node!=leg.start_node:raise ValueError('teleportation across mission legs')
        prev_end=leg.landing_utc
        if leg.route_evidence!='ACCEPTED_FLIGHT_CORRIDOR':missing.add('AUTHORIZED_AIR_CORRIDOR')
        try:
            chunks=weather_for_event(leg.weather_grid_id,leg.launch_utc,leg.landing_utc,list(weather))
        except ValueError:
            missing.add('EVENT_TIME_WEATHER')
            continue
        seconds=sum(n for _,n in chunks)
        weighted=sum(along_track_wind_mps(w.wind_speed_mps,w.wind_from_deg,leg.bearing_degrees)*n for w,n in chunks)/seconds
        vectors.append({'leg_index':i,'weighted_along_wind_mps':weighted,'validated_weather_seconds':seconds})
    return {'task_id':req.task_id,'mode':req.mode,'evidence_status':'EVIDENCE_GATE_PASS_MODEL_NOT_RUN' if not missing else 'HOLD',
            'missing_evidence':sorted(missing),'weather_leg_diagnostics':vectors,'actual_energy_kwh':None,
            'actual_operational_CO2e_kg':None,'note':'This is an evidence preflight; it NEVER outputs operational energy or emissions.'}
