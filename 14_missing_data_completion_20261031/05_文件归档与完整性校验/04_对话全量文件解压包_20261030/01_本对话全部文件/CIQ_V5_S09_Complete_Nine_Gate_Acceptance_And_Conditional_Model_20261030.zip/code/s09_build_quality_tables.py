from pathlib import Path
import csv,gzip,statistics,json
from collections import defaultdict,Counter
R=Path(__file__).resolve().parents[1]
O=R/'outputs'
G=defaultdict(list);counts=Counter()
with gzip.open(O/'S09_DIRECT_GEOMETRY_POWER_WIND_3X3_SENSITIVITY_DESIGN_ONLY.csv.gz','rt',encoding='utf-8') as f:
 for x in csv.DictReader(f):
  k=(x['aircraft_model'],x['power_level'],x['wind_assumption']);G[k].append(float(x['battery_kwh_DESIGN_ONLY']))
  counts[(k,x['conditional_battery_budget_screen'])]+=1
with (O/'S09_3X3_SENSITIVITY_SUMMARY_DESIGN_ONLY.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['aircraft','power_assumption','wind_stress_assumption','task_rows','conditional_budget_pass','conditional_budget_fail','battery_kwh_min','battery_kwh_median','battery_kwh_max','evidence_limit'])
 for key,v in sorted(G.items()):
  w.writerow([*key,len(v),counts[(key,'PASS_CONDITIONAL')],counts[(key,'FAIL_CONDITIONAL')],round(min(v),6),round(statistics.median(v),6),round(max(v),6),'SCENARIO_ONLY_NO_REAL_2026_WIND_OR_OEM_MISSION_POWER'])

matrix=[
('S09-01','机型规格、版本及来源','PASS_DJI__HOLD_CARGO_VARIANT','DJI 官方双电池/30kg/试验航程；198 Delivery Variant 2021 文件记录5kg及2×814Wh，与研究中 Cargo 4.7kg 配置不等价'),
('S09-02','82,620 订单载重/空间筛查','PASS_STATIC','165,240 条任务×机型；11,060 DJI、7,377 Wingcopter 方向一致且载重通过的候选几何；不等于航线获批'),
('S09-03','2026年5–9月风雨事件核验','HOLD_REAL_WEATHER','五个月气象原始字节尚未独立数值验收；B/C粗网格空间代表性预警；事件时刻由S10调度给出'),
('S09-04','带载/空载/返程/起降能耗','PASS_SCENARIO_CODE__HOLD_CALIBRATION','165,933条功率×风况设计情景；两机型无已校准任务级功率曲线；没有真实kWh'),
('S09-05','充电/能源来源/运营CO2e','PASS_ACCOUNTING_TEST__HOLD_EF','电网和车载发动机供电严格分账；缺少实际充电效率/可核验2026电力因子/实际任务kWh'),
('S09-06','M1固定站点/M2动态会合接口','PASS_SCHEMA__HOLD_REAL_S10_EVENTS','事件 UTC、连续航段、天气窗口、合法路由与机型证据门控；未运行真实起降/会合排程'),
('S09-07','机型功率、5m/s逆顺风敏感性','PASS_ILLUSTRATIVE_ONLY','3种功率×3种合成风况；不得引用为历史运营表现或实际天气限制'),
('S09-08','执行复现、测试、异常审计','PASS_ENGINEERING_QA','冻结源SHA逐项匹配；37项自动测试通过；没有将缺失实证转为0或PASS'),
('S09-09','最终SCI可投稿能耗验收','HOLD__NOT_FINAL_PASS','S07原始风雨数值、Cargo配置匹配、两机型任务能耗标定、合法航路及S10实际任务时刻均未验收')]
with (O/'S09_9_WORKPACKAGES_FINAL_ACCEPTANCE_MATRIX.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['id','required_task','audit_status','scientific_evidence_and_blocker']);w.writerows(matrix)

spec={
 'research_scope':'V5 fixed 68 nodes,116 UAV candidate geometries,82620 designed tasks,4590 seed-day independent scenarios',
 'official_evidence':[
 {'manufacturer':'DJI','model':'FlyCart 30','version':'Dual DB2000','url':'https://www.dji.com/flycart-30/specs','verified_params':{'maximum_payload_kg_dual':30,'windless_test_loaded_max_distance_km':16,'windless_test_empty_max_distance_km':28,'battery_nominal_kWh_dual':3.9688,'wind_resistance_mps_test':12},'source_grade':'MANUFACTURER_WEB_TECHNICAL_SPECS','caution':'Not usable energy; windless ideal test range; not mission power curve'},
 {'manufacturer':'Wingcopter','model':'Wingcopter 198 Delivery Variant','version':'04-2021, related variant not Cargo','url':'https://www.sisirl.com/wp-content/uploads/2018/01/Specsheet_Wingcopter-198.pdf','verified_params':{'maximum_payload_kg_delivery_variant':5,'battery_two_units_nominal_kWh':1.628,'fixed_wing_default_cruise_mps':28,'windless_test_max_5kg_oneway_km':75},'source_grade':'BRANDED_SPEC_SHEET_REHOSTED','caution':'The frozen Cargo study uses 4.7kg, not verified equal to this variant; energy values used only as comparative design proxy'}],
 'frozen_study_capacity_kg':{'DJI_FLYCART_30_DUAL':30.0,'WINGCOPTER_198_CARGO_ASSUMED':4.7},
 'scenario_assumptions_not_observations':{
 'wind_from_output_direction_stress_mps':[-5,0,5],
 'power_levels_kW_loaded_empty_launch_landing_energy':{
  'DJI_FLYCART_30_DUAL':{'LOW':[3.1,1.6,0.04],'CENTRAL':[3.7,2.2,0.08],'HIGH':[4.6,3.0,0.15]},
  'WINGCOPTER_198_CARGO_ASSUMED':{'LOW':[1.1,0.7,0.02],'CENTRAL':[1.7,1.2,0.04],'HIGH':[2.4,1.8,0.09]}},
 'battery_usable_fraction':{'LOW':0.9,'CENTRAL':0.9,'HIGH':0.85},
 'reserve_fraction_of_usable':{'LOW':0.2,'CENTRAL':0.25,'HIGH':0.3},
 'charger_efficiency':{'LOW':0.92,'CENTRAL':0.90,'HIGH':0.85},
 'scope':'DESIGN_ONLY_POWER_AND_WIND_SENSITIVITY_NOT_REAL_FLIGHT_DATA'},
 'hard_gate':'Formal S09 final pass is impossible without S07 real weather, OEM Cargo configuration and energy calibration, site/airspace evidence and S10 mission event scheduling.',
 'claim_limit':'No real flight approval; no observed UAV energy; no verified time or CO2; do not cite scenario energy as field result.'}
(R/'inputs'/'S09_VERIFIED_SOURCES_AND_EXPLICIT_SCENARIO_ASSUMPTIONS.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
interface={
 'S09_to_S10_contract_version':'V5-S09.1',
 'mission_identifiers':['task_id','scenario_seed','date_local','mode','aircraft_model','mission_id'],
 'required_flight_event':{'start_node':'V5 node ID, actual S10 rendezvous position otherwise explicit longitude latitude','end_node':'V5 node ID or S10 rendezvous position','launch_utc':'timezone aware real mission event time; NEVER order release time by default','landing_utc':'timezone aware arrived time','flight_path':'authenticated line (not merely V5 geometric candidate)','path_length_km':'true planned path length','bearing_degrees':'for directional wind','payload_kg':'cargo inclusive of packaging equipment','weather_grid_id':'validated gridded or station point','route_evidence':'AUTHORIZED_AIR_CORRIDOR only for operational evidence'},
 'required_evidence_gates':['AUTHORIZED_AIR_CORRIDOR','APPROVED_LANDING_AND_LAUNCH','EVENT_TIME_WEATHER','CALIBRATED_BATTERY_AND_POWER','VERIFIED_CHARGE_INPUT','S10_VEHICLE_M2_RENDEZVOUS'],
 'accounting':{'battery_kWh':'sum climb cruise transition hover descent delivery return etc. calibrated phases','grid_kWh':'battery_kWh/charger_eta+auxiliary_kWh, only for GRID supply','vehicle_engine_power':'enter gasoline ledger once, not grid ledger','CO2e':'only with accepted electricity intensity and defined grid boundary','unserved_or_drone_ineligible':'retain shared denominator; do not drop from M1 or M2'},
 'release':'HOLD_UNTIL_S10_SUPPLIES_EVENT_AND_S07_WEATHER_VERIFIED'}
(O/'S09_M1_M2_FORMAL_MISSION_INTERFACE.json').write_text(json.dumps(interface,ensure_ascii=False,indent=2),encoding='utf-8')

print('written summary',len(G),'groups')
