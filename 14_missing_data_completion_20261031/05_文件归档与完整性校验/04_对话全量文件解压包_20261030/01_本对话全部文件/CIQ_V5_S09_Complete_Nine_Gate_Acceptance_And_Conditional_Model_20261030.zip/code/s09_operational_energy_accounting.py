"""Operational UAV electricity and CO2e ledger with explicit non-double-counting.

No real output is produced without independently established mission energy,
charge origin and the same regional electricity-emissions factor across modes.
Fuel burnt by M0/M1/M2 vehicles must be accounted in the ground ledger, separately.
"""
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class ChargeLedger:
    battery_replenished_kwh:float
    charger_efficiency:float
    charger_auxiliary_grid_kwh:float
    power_source:str  # GRID | VEHICLE_ENGINE
    validated_mission_energy:bool
    verified_energy_source:bool
    emission_factor_kgco2e_per_kwh:float|None


def energy_accounting(ledger:ChargeLedger)->dict:
    for v in (ledger.battery_replenished_kwh,ledger.charger_efficiency,ledger.charger_auxiliary_grid_kwh):
        if not math.isfinite(v):raise ValueError('nonfinite charge ledger')
    if ledger.battery_replenished_kwh<0 or ledger.charger_auxiliary_grid_kwh<0:raise ValueError('negative energy')
    if not 0<ledger.charger_efficiency<=1:raise ValueError('invalid charger efficiency')
    if ledger.power_source not in ('GRID','VEHICLE_ENGINE'):raise ValueError('unknown energy source')
    if ledger.emission_factor_kgco2e_per_kwh is not None:
        if not math.isfinite(ledger.emission_factor_kgco2e_per_kwh) or ledger.emission_factor_kgco2e_per_kwh<0:raise ValueError('invalid carbon factor')
    electricity_input=ledger.battery_replenished_kwh/ledger.charger_efficiency+ledger.charger_auxiliary_grid_kwh
    if ledger.power_source=='VEHICLE_ENGINE':
        return {'release':'HOLD_INTEGRATE_WITH_VEHICLE_FUEL_LEDGER','grid_input_kwh':0.0,'engine_supplied_kwh':electricity_input,'operational_grid_co2e_kg':None,
                'double_count_guard':'Do not multiply by grid factor; account energy conversion via additional vehicle fuel in S08/S10'}
    if not ledger.validated_mission_energy or not ledger.verified_energy_source or ledger.emission_factor_kgco2e_per_kwh is None:
        return {'release':'HOLD_UNVALIDATED_ENERGY_OR_EF','grid_input_kwh':electricity_input,'engine_supplied_kwh':0.0,'operational_grid_co2e_kg':None,'double_count_guard':'No kg CO2e released without model calibration and traceable grid EF'}
    return {'release':'CALCULATION_ONLY_REQUIRES_END_TO_END_QA','grid_input_kwh':electricity_input,'engine_supplied_kwh':0.0,
            'operational_grid_co2e_kg':electricity_input*ledger.emission_factor_kgco2e_per_kwh,
            'double_count_guard':'Station energy counted once; gasoline vehicle emissions only through ground ledger'}
