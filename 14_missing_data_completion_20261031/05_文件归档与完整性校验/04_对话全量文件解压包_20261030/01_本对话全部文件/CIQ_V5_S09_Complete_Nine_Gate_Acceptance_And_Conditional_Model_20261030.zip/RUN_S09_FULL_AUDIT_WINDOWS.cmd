@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PYTHON=py -3") else (set "PYTHON=python")
%PYTHON% code\s09_full_validation.py --inputs inputs --outputs outputs
if errorlevel 1 exit /b 1
%PYTHON% code\s09_build_quality_tables.py
if errorlevel 1 exit /b 1
%PYTHON% -m unittest discover -s tests -p "test_*.py" -v
if errorlevel 1 exit /b 1
echo S09 conditional engineering QA PASS, SCI FINAL RELEASE HOLD; see docs.
exit /b 0
