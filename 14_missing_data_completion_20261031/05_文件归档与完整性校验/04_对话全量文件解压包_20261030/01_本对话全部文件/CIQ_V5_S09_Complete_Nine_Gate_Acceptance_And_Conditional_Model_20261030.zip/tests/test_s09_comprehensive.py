from __future__ import annotations
import csv, gzip, json, sys, unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
from s09_full_validation import conditional_roundtrip,AIRCRAFT,WINDS,run,sha256,LOCK_SHA
from s09_m1_m2_event_contract import FlightLeg,S10MissionRequest,validate_real_mission
from weather_event_contract import WeatherHour, weather_for_event,along_track_wind_mps
from s09_operational_energy_accounting import ChargeLedger,energy_accounting

class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.out=ROOT/'outputs'
  cls.inputs=ROOT/'inputs'
  cls.meta=json.loads((cls.out/'S09_QA_SCIENTIFIC_RELEASE_GATE.json').read_text())
 def test_01_frozen_order_hash(self):self.assertEqual(sha256(self.inputs/'S07_V5_SYNTHETIC_TASKS_CONDITIONAL_DESIGN.csv'),LOCK_SHA['S07_V5_SYNTHETIC_TASKS_CONDITIONAL_DESIGN.csv'])
 def test_02_frozen_v5_geo_hash(self):self.assertEqual(sha256(self.inputs/'V5_FROZEN_SOURCE.zip'),LOCK_SHA['V5_FROZEN_SOURCE.zip'])
 def test_03_nodes_68(self):self.assertEqual(self.meta['V5_nodes'],68)
 def test_04_edges_116(self):self.assertEqual(self.meta['V5_candidate_geometry_edges'],116)
 def test_05_tasks_82620(self):self.assertEqual(self.meta['fixed_task_count'],82620)
 def test_06_scenarios_4590(self):self.assertEqual(self.meta['design_scenarios'],4590)
 def test_07_zone_balanced(self):self.assertEqual(self.meta['per_zone_orders'],{'A':27540,'B':27540,'C':27540})
 def test_08_direct_11060(self):self.assertEqual(self.meta['direct_geometry_status_counts']['DIRECTED_CANDIDATE_NOT_AUTHORIZED'],11060)
 def test_09_reverse_17417(self):self.assertEqual(self.meta['direct_geometry_status_counts']['REVERSE_ONLY_NOT_AUTHORIZED'],17417)
 def test_10_no_direct_54143(self):self.assertEqual(self.meta['direct_geometry_status_counts']['NO_DIRECT_CANDIDATE__FEEDER_OR_MULTILEG_REQUIRED'],54143)
 def test_11_dji_payload(self):self.assertEqual(self.meta['per_aircraft_counts']['DJI_FLYCART_30_DUAL']['WEIGHT_ONLY_PASS'],82620)
 def test_12_wing_payload(self):self.assertEqual(self.meta['per_aircraft_counts']['WINGCOPTER_198_CARGO_ASSUMED']['WEIGHT_ONLY_FAIL__GROUND_FALLBACK'],27540)
 def test_13_wing_direct_after_payload(self):self.assertEqual(self.meta['per_aircraft_counts']['WINGCOPTER_198_CARGO_ASSUMED']['DIRECT_AND_WEIGHT_DESIGN_SCENARIO'],7377)
 def test_14_stress_rows(self):self.assertEqual(self.meta['conditional_sensitivity_rows'],165933)
 def test_15_no_real_energy_emission(self):
  with gzip.open(self.out/'S09_82620_TASKS_X_2_AIRCRAFT_STATIC_AND_CONDITIONAL.csv.gz','rt',encoding='utf-8') as f:
   r=csv.DictReader(f);n=0
   for row in r:
    self.assertEqual(row['real_mission_energy_kwh'],'');self.assertEqual(row['real_operational_CO2e_kg'],'');n+=1
  self.assertEqual(n,165240)
 def test_16_energy_positive(self):self.assertGreater(conditional_roundtrip(2,1,'DJI_FLYCART_30_DUAL')['battery_kwh_scenario'],0)
 def test_17_payload_limit(self):
  with self.assertRaises(ValueError):conditional_roundtrip(2,5.0,'WINGCOPTER_198_CARGO_ASSUMED')
 def test_18_wind_symmetry_time(self):
  a=conditional_roundtrip(3,1,'DJI_FLYCART_30_DUAL',wind_name='HEADWIND_OUTBOUND_5MPS')
  b=conditional_roundtrip(3,1,'DJI_FLYCART_30_DUAL',wind_name='TAILWIND_OUTBOUND_5MPS')
  self.assertAlmostEqual(a['flight_minutes_proxy'],b['flight_minutes_proxy'])
 def test_19_headwind_energy_differs(self):
  a=conditional_roundtrip(3,1,'DJI_FLYCART_30_DUAL',wind_name='HEADWIND_OUTBOUND_5MPS')
  b=conditional_roundtrip(3,1,'DJI_FLYCART_30_DUAL',wind_name='TAILWIND_OUTBOUND_5MPS')
  self.assertNotAlmostEqual(a['battery_kwh_scenario'],b['battery_kwh_scenario'])
 def test_20_power_level_order(self):
  vals=[conditional_roundtrip(3,1,'DJI_FLYCART_30_DUAL',level=x)['battery_kwh_scenario'] for x in ('LOW','CENTRAL','HIGH')]
  self.assertLess(vals[0],vals[1]);self.assertLess(vals[1],vals[2])
 def test_21_longer_path_higher_energy(self):
  a=conditional_roundtrip(3,1,'DJI_FLYCART_30_DUAL')['battery_kwh_scenario'];b=conditional_roundtrip(6,1,'DJI_FLYCART_30_DUAL')['battery_kwh_scenario'];self.assertLess(a,b)
 def test_22_bad_distance(self):
  with self.assertRaises(ValueError):conditional_roundtrip(-1,1,'DJI_FLYCART_30_DUAL')
 def test_23_bad_wind(self):
  with self.assertRaises(ValueError):conditional_roundtrip(3,1,'DJI_FLYCART_30_DUAL',wind_name='REAL_WIND_FAKE')
 def test_24_scenario_is_not_calibrated(self):self.assertFalse(self.meta['actual_oem_Cargo_energy_calibrated'])
 def test_25_real_carbon_uncomputed(self):self.assertFalse(self.meta['real_operational_carbon_computed'])
 def weather_fixture(self):
  tz=timezone.utc;s=datetime(2026,5,1,0,0,tzinfo=tz)
  return [WeatherHour('WX',s,s+timedelta(hours=1),3,270,4,0,'VERIFIED_INPUT_SOURCE_AND_TIME'),WeatherHour('WX',s+timedelta(hours=1),s+timedelta(hours=2),5,90,6,0,'VERIFIED_INPUT_SOURCE_AND_TIME')]
 def req(self):
  s=datetime(2026,5,1,0,30,tzinfo=timezone.utc)
  leg=FlightLeg('A01','A02',2,90,1,s,s+timedelta(minutes=60),'WX','CONDITIONAL_GEOMETRY')
  return S10MissionRequest('t','DJI_FLYCART_30_DUAL','M1',(leg,),False,False,False,False,False)
 def test_26_weather_two_hour_coverage(self):
  w=self.weather_fixture();s=datetime(2026,5,1,0,30,tzinfo=timezone.utc)
  self.assertEqual(len(weather_for_event('WX',s,s+timedelta(hours=1),w)),2)
 def test_27_weather_hard_gap(self):
  w=self.weather_fixture()[:1];s=datetime(2026,5,1,0,30,tzinfo=timezone.utc)
  with self.assertRaises(ValueError):weather_for_event('WX',s,s+timedelta(hours=1),w)
 def test_28_missing_event_evidence(self):
  x=validate_real_mission(self.req(),self.weather_fixture());self.assertEqual(x['evidence_status'],'HOLD');self.assertIn('CALIBRATED_BATTERY_AND_POWER',x['missing_evidence']);self.assertIsNone(x['actual_energy_kwh'])
 def test_29_weather_direction_sign(self):
  self.assertGreater(along_track_wind_mps(5,270,90),0)
  self.assertLess(along_track_wind_mps(5,90,90),0)
 def test_30_no_flight_results_even_if_all_flags_yes(self):
  s=datetime(2026,5,1,0,30,tzinfo=timezone.utc)
  leg=FlightLeg('A01','A02',2,90,1,s,s+timedelta(minutes=60),'WX','ACCEPTED_FLIGHT_CORRIDOR')
  req=S10MissionRequest('t','DJI_FLYCART_30_DUAL','M2',(leg,),True,True,True,True,True)
  r=validate_real_mission(req,self.weather_fixture());self.assertEqual(r['evidence_status'],'EVIDENCE_GATE_PASS_MODEL_NOT_RUN');self.assertIsNone(r['actual_energy_kwh'])
 def test_31_no_teleportation(self):
  s=datetime(2026,5,1,0,0,tzinfo=timezone.utc)
  legs=(FlightLeg('A','B',2,30,1,s,s+timedelta(minutes=10),'WX','ACCEPTED_FLIGHT_CORRIDOR'),FlightLeg('C','D',2,30,0,s+timedelta(minutes=10),s+timedelta(minutes=20),'WX','ACCEPTED_FLIGHT_CORRIDOR'))
  req=S10MissionRequest('t','DJI','M2',legs,True,True,True,True,True)
  with self.assertRaises(ValueError):validate_real_mission(req,self.weather_fixture())
 def test_33_grid_no_real_ef_holds(self):
  r=energy_accounting(ChargeLedger(0.5,0.9,0.02,'GRID',False,False,None));self.assertIsNone(r['operational_grid_co2e_kg']);self.assertEqual(r['release'],'HOLD_UNVALIDATED_ENERGY_OR_EF')
 def test_34_engine_no_double_count(self):
  r=energy_accounting(ChargeLedger(0.5,0.9,0.02,'VEHICLE_ENGINE',True,True,0.8));self.assertEqual(r['grid_input_kwh'],0.0);self.assertIsNone(r['operational_grid_co2e_kg'])
 def test_35_fixture_carbon_math(self):
  r=energy_accounting(ChargeLedger(0.9,0.9,0.1,'GRID',True,True,0.5));self.assertAlmostEqual(r['operational_grid_co2e_kg'],0.55)
 def test_36_negative_energy_rejected(self):
  with self.assertRaises(ValueError):energy_accounting(ChargeLedger(-0.9,0.9,0,'GRID',True,True,0.5))
 def test_37_missing_data_cannot_final_pass(self):self.assertIn('HOLD',self.meta['final_status'])
 def test_32_no_dropped_tasks(self):self.assertTrue(self.meta['no_source_orders_dropped'])

if __name__=='__main__':unittest.main(verbosity=2)
