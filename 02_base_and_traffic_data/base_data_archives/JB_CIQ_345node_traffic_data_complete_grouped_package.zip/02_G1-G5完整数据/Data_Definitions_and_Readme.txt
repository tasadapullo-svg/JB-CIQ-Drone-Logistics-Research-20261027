JB traffic grouped by official Final_Road_Group_Freeze_v1_20260921 (5 months, 2026-05 to 2026-09).
All files preserve 345 formal nodes; RA01, RA02, RA03 excluded from 348 freeze master.
The original 5-group nomenclature and frozen classifications are unchanged.
Primary keys: node_key -> node_id (exact match); hour_start_time -> timestamp_local (UTC+08:00).
Observed hourly speed values are copied directly from observed_hourly_speed; missing stays blank. No QC, observed_flag, analysis_speed, imputation or source_type columns used to filter or fill.
Road labels marked RESEARCH_DEFINED_SEGMENT are analytic segment names, NOT official road names.
source_route_code R1/R2 within G1 identifies original Causeway/Second Link route families, NOT exclusive Malaysia-side or within-4km membership.
Speed was produced by TomTom FCD, normally in km/h; no unit conversion applied. Confirm original API unit option before publication.
Monthly mean speed is a record-weighted mean across available node-hours, not link travel time, traffic flow or trip delay.
Do not calculate CIQ queue times or total route travel times directly from node mean speeds.
September observed weekday column ignored; timestamp_local used as the canonical time key.
Column discrepancies between September and May-Aug do not prevent a minimal-data speed-series harmonization, but origin/representativeness remains a data provenance caveat.
Use file Group_Hourly_TimeSeries_5groups.csv to align future hourly environmental data.
Status: This is a grouping/harmonization output, not an UAV or emissions result.
