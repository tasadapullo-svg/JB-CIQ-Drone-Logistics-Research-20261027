import csv, json, math, pathlib, collections, textwrap, zipfile, shutil, os
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from matplotlib import font_manager
from docx import Document
from docx.shared import Inches,Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

D=pathlib.Path('/mnt/data/JB_CIQ_POC_V3_1'); V=pathlib.Path('/mnt/data/JB_CIQ_MultiNode_V3')
def read(name):
 with open(D/name,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
sites=read('01_Site_Evidence_Ledger.csv'); edges=read('02_Edge_Geometric_and_Regulatory_Audit.csv'); monthly=read('04_R1_R2_Monthly_Descriptive.csv'); readiness=read('05_RQ_Evidence_Readiness.csv')
loc={x['site_id']:x for x in sites}
# Project each area's coords into kilometers relative to area centre for geometrically interpretable plotting
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc') if pathlib.Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').exists() else None
plt.rcParams['font.family']='DejaVu Sans'
fig,axs=plt.subplots(1,2,figsize=(15.8,7.4),dpi=170)
for ax,area in zip(axs,['A','B']):
 nodes=[n for n in sites if n['area']==area]
 lat0=sum(float(n['latitude']) for n in nodes)/len(nodes);lon0=sum(float(n['longitude']) for n in nodes)/len(nodes)
 def xy(n):return ((float(n['longitude'])-lon0)*111.1*math.cos(math.radians(lat0)),(float(n['latitude'])-lat0)*111.1)
 for e in edges:
  if e['area']!=area or float(e['straight_line_km'])>4:continue
  p,q=xy(loc[e['from_site']]),xy(loc[e['to_site']])
  ax.plot([p[0],q[0]],[p[1],q[1]],color='#43927e' if float(e['straight_line_km'])<=3 else '#d49b40',ls='--',lw=1.0,alpha=.58,zorder=1)
 for n in nodes:
  x,y=xy(n)
  c='#9d6262' if n['candidate_class']=='CONTEXT_ONLY_NOT_UAV_SITE' else ('#b18331' if n['candidate_class']=='MODEL_CENTROID_NOT_PHYSICAL_SITE' else '#2c668d')
  marker='s' if n['candidate_class']=='CONTEXT_ONLY_NOT_UAV_SITE' else ('D' if n['candidate_class']=='MODEL_CENTROID_NOT_PHYSICAL_SITE' else 'o')
  ax.scatter([x],[y],s=65,c=[c],marker=marker,edgecolors='white',linewidths=0.9,zorder=3)
  ax.annotate(n['site_id'],(x,y),xytext=(4,5),textcoords='offset points',fontsize=8,color='#192c3b',weight='bold')
 ax.margins(x=.12,y=.18)
 ax.grid(True,alpha=.18,ls=':')
 ax.axhline(0,lw=.4,color='#adbcc8');ax.axvline(0,lw=.4,color='#adbcc8')
 ax.set_aspect('equal','box')
 ax.set_title('A — Causeway: urban shared-hub candidates' if area=='A' else 'B — Second Link: truck-feeder candidates',size=14,weight='bold')
 ax.set_xlabel('East–west offset from area centre (km)',fontsize=10)
 ax.set_ylabel('North–south offset from area centre (km)',fontsize=10)
 ax.text(.99,.02,'Illustrative geographic adjacency only\nNot an approved flight map',transform=ax.transAxes,ha='right',va='bottom',fontsize=9,color='#9d3a3a',bbox={'facecolor':'white','edgecolor':'#dadada','boxstyle':'round,pad=.35'})
fig.legend(handles=[mlines.Line2D([],[],color='#43927e',ls='--',lw=2,label='straight line <=3 km'),mlines.Line2D([],[],color='#d49b40',ls='--',lw=2,label='3–4 km only'),mlines.Line2D([],[],marker='o',markerfacecolor='#2c668d',markeredgecolor='white',color='none',label='Named place / area centroid'),mlines.Line2D([],[],marker='D',markerfacecolor='#b18331',color='none',label='Study-only hypothetical centre'),mlines.Line2D([],[],marker='s',markerfacecolor='#9d6262',color='none',label='CIQ reference (no drone pad)')],loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.5,.035),fontsize=10)
fig.subplots_adjust(top=.91,bottom=.26,left=.08,right=.98,wspace=.25)
fig.savefig(D/'11_POC_Geometric_Network_A_B.png',dpi=200,bbox_inches='tight',facecolor='white')
plt.close(fig)

# Evidence-centered report
f=Document();sec=f.sections[0];sec.top_margin=Cm(1.9);sec.bottom_margin=Cm(1.8);sec.left_margin=Cm(2.3);sec.right_margin=Cm(2.3)
styles=f.styles
styles['Normal'].font.name='Noto Sans CJK SC';styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');styles['Normal'].font.size=Pt(9.5)
styles['Normal'].paragraph_format.space_after=Pt(4)
for name,size in [('Title',21),('Heading 1',13),('Heading 2',11)]:
 styles[name].font.name='Noto Sans CJK SC';styles[name]._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');styles[name].font.size=Pt(size);styles[name].font.color.rgb=RGBColor(23,60,83)

def p(txt='',style=None):return f.add_paragraph(txt,style)
def h(txt,lev=1):f.add_heading(txt,level=lev)
def table(headers,rows,widths=None):
 t=f.add_table(rows=1,cols=len(headers));t.style='Light Shading Accent 1';t.autofit=True
 for i,v in enumerate(headers):t.rows[0].cells[i].text=str(v)
 for row in rows:
  cells=t.add_row().cells
  for i,v in enumerate(row): cells[i].text=str(v)
 for row in t.rows:
  for c in row.cells:
   c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   for pp in c.paragraphs:
    pp.paragraph_format.space_after=Pt(0)
    for rr in pp.runs:rr.font.size=Pt(8)
 return t

t=f.add_paragraph();t.style='Title';t.add_run('Johor Bahru 双CIQ低空物流网络\n证据门槛与概念验证审计 V3.1')
p('目标：Sustainability SCI论文的RQ1–RQ3；性质：概念验证、数据证据审查、实验边界冻结（不是正式运营、批准航线或最终实验结果）')
p('版本：2026-10-26  |  数据：2026年5—9月  |  区域：Causeway（A）与Second Link（B）马来西亚侧  |  研究需求：D1主任务、D2共享扩展')
h('0. 决策摘要')
p('通过：地理参考点可追溯、345 FCD道路注册表存在、G1的R1/R2分时段观测可描述、3/4km候选节点之间的测地线邻接可复核。未通过：合法起降地块、实时有效官方空域核验、三维可飞航线、订单OD、路段旅行时间、天气适飞率、成本及碳排放。')
table(['概念审查','本轮结果','可使用的表述'],[
 ('节点与网络','19参考点（15有地点或区域名+2假设中心+2CIQ参照），64节点对','仅地理初筛'),
 ('3/4km连线','≤3km 25对，3–4km 7对，>4km 32对','32组几何候选连接≠获准可飞航段'),
 ('法规运营','经完整证据验证的起降站/航路均为0','不能声称已有合法运行方案'),
 ('交通','G1 R1/R2各24/22节点，5个月小时级数据','描述性路段速度，不等于OD旅行时间'),
 ('经济/环保','缺订单、车辆/航空能耗与成本','目前不得声称投资回报或净减排')])
h('1. 三个研究问题与停止门槛')
table(['RQ','主结果终点','开始量化验证前的最低必要条件'],[
 ('RQ1 空间可行性','实际可服务订单比例、真实可用站点及航线','带地块边界/许可的真实站点；官方空域；障碍物；包裹OD及机型能耗'),
 ('RQ2 效率','同订单门到取件点总时间、准时率、被替代车辆km','真实/透明生成订单+有向道路网络+FCD边匹配+地面兜底规则'),
 ('RQ3 环保经济','同服务水平的kg CO₂e/单、RM/单、可飞任务率','同时间天气、车辆/飞机能耗、系统边界、成本与设施利用率')])
p('严格判定：某一RQ缺关键数据，报告“不能判定”，而不是补造数值、换点位或增加反复试验。对负效益和不可飞的结论同样保留。')
h('2. 数据链及版本差异')
p('① 原始5个月PROVISIONAL FCD CSV → ②冻结的345节点注册表与G1–G5分类 → ③G1按R1/R2分开 → ④5个月当地小时速度描述 → ⑤19条地理参照的GIS空间关联 → ⑥需求/准入证据门槛（目前未通过）。')
p('源论文 Manuscript.pdf（2026-09-24版本）使用2026-04-20—08-31正式时间窗，345个软件定义FCD查询节点、12个IMERG雨量网格和4个Open-Meteo参照点。此次新研究改为5—9月，9月CSV字段与5—8月不同。统一分析只保留ID、当地时间、原始速度及正式分组；速度字段数值单位尚需与API请求参数核对。源论文的降雨响应结论不能替代本研究5—9月无人机适飞数据。')
h('3. 地理候选网络概念图')
f.add_picture(str(D/'11_POC_Geometric_Network_A_B.png'),width=Cm(16.0))
p('图注：使用原V3地理位置及WGS84距离门槛生成的几何连线。图上没有任何法定空域、地块边界或三维避障证明；B01/B02为虚拟研究搜索中心。')
h('4. 每个地点为何进入候选表，以及为什么还不是“站点”')
p('全部19条记录的经纬度、坐标来源、场景功能、原站点证据、3/4km圈内FCD点数与未来经济机制均列在01_Site_Evidence_Ledger.csv与Excel的01_Sites。下表摘录主要对象；经纬度仅定位设施或片区，不能用作停机坪最终坐标。')
keys=['A01','A02','A03','A06','A05','B01','B02','B03','B06','B08']
table(['ID / 地点','坐标（纬, 经）','为何纳入/经济渠道'],[(entry['site_id']+' '+entry['place_name'],f"{float(entry['latitude']):.5f}, {float(entry['longitude']):.5f}",entry['potential_economic_mechanism'][:105]) for entry in [next(x for x in sites if x['site_id']==k) for k in keys]])
p('硬约束：有地标不代表已获地块使用权；商场顶楼、CIQ、港区和高速路肩一律不能在没有许可和现场条件验证时默认为无人机起降点。A01/A02/A03等商业节点可先按发货/需求锚点调查；住宅点按智能柜接收区调查；PTP首先是D1地面货源参照。')
h('5. 交通数据可以直接支撑什么')
table(['路线/月份','有效节点小时','非空比例','平均原始速度*'],[(m['route_family']+' '+m['month'],f"{int(m['nonempty_speed_count']):,}",f"{float(m['nonempty_fraction'])*100:.2f}%",m['mean_raw_speed']) for m in monthly])
p('* 原始速度单位未在本次审计中复核。R1/R2包含正式口岸路线族的节点，部分点可能在国界另一侧；不得将整个路线族均值当作马来西亚侧口岸排队时间或某条完整配送路线的旅行速度。不同月份的原始数据生成机制需另行确认，特别是9月100%速度非空与原始QC含义不能等同。')
h('6. 起降站准入程序（严格先后顺序）')
table(['关口','要求','不过关怎么处理'],[
 ('G1 监管','现行CAAM运营批准/ SUP适用性；有效AIP、NOTAM及相关机构要求','运营网络中不开放；保留几何参考'),
 ('G2 地块','确切地籍或屋顶边界、许可、停车/地面处理、公众风险','不建设，不以中心点替代'),
 ('G3 需求','D1与D2分开的订单OD、重量、时间窗、接收方式及实证/模拟标签','不得计算“实际订单覆盖”'),
 ('G4 物理','载重、能耗、安全余量、三维建筑与地形、单段3/4km约束','航段关闭、地面兜底'),
 ('G5 交通/天气','有向道路长度+FCD匹配、同期风雨雷暴、故障回退','不得计算可靠的时效对比'),
 ('G6 环保经济','固定/可变站点成本、车辆燃料或电耗、UAV电耗、电力因子','不得计算净CO₂e/ROI')])
p('官方风险：CAAM将载物、BVLOS及研发类特殊运营纳入Special UAS Project相关审批框架。历史AIP网页显示WMP228 Bukit Serene永久禁飞区，但存在公开坐标资料差异；必须使用实际评估时有效的航空资料、航图及NOTAM复核，不得根据未经确认的圆形缓冲区自行认定可飞。')
h('7. D1/D2的经济价值如何验证')
p('对每个实际获准地点i，收入或成本优势必须以同一OD的纯地面基准衡量。经济盈亏平衡需要独立实证输入，而不能把FCD数量当作日订单数。')
p('D_BE,i = (CAPEX_i / (365 × 年限_i) + 每日固定运营费_i) / 每完成订单增量净节省_i；若每订单净节省≤0，则无正的有限盈亏平衡量。应考虑运营许可、土地租赁、智能柜、人员装卸、设备维护、天气地面兜底、平台调度、保险、电池更换和客户取件步行时间。')
p('工作簿09_Economic_Input对所有19条位置提供空白参数与计算公式：没有输入证据时不会输出任何RM收益。CIQ背景位置与虚拟搜索中心不应直接填写为已建设站点。')
h('8. 有限实验设计及停止规则')
p('主机型Matternet M2参数基准，结构性配置固定为：2区域×2模式×2半径×2订单结构=16；补充机型M3和FlyCart 30仅在4km+D1+D2中各测试2区域×2模式=8。实际交通和天气按冻结的5—9月同日同小时回放，不为“好看结果”临时追加月份或情景。')
p('将配置、OD生成规则、训练/验证/测试划分、目标函数、结果指标、随机种子、停飞规则在最终测试前冻结。未通过硬性证据关口的配置列为不可执行或仅理论，不默默剔除。审计通过且预设结果输出完成即停止；缺数据不是多跑实验的理由。')
h('9. 面向Sustainability的正式写作准备情况')
table(['部分','可开始的内容','不能现在写成完成结果的内容'],[
 ('Introduction','现实痛点、RQ1-RQ3及受规制的JB场景（需文献核验）','断言首次提出/已证明高减排'),
 ('Study Area & Data','已证实的345节点/G1–G5、5个月数据、候选地标及来源','将POI指为有许可的起降站'),
 ('Methods','3/4km初筛、准入门槛、相同OD比较、冻结实验框架','完整地空算法已经验证的表述'),
 ('Results','可引用几何候选节点对及G1观测描述性统计','任务节时、真实覆盖、CO₂e与ROI'),
 ('Discussion/Conclusion','研究限制和拟检验的管理启示','未经实测和敏感性实验支持的政策结论')])
h('10. 下一步有限交付目标')
p('优先级1（必须）一次性取得：两个区域的候选实际地块多边形与使用许可记录、现行权威空域资料；明确剔除不能在法律与安全要求下使用的点。优先级2（必须）：获取或事先冻结D1/D2代表性OD需求及完整道路拓扑。优先级3（必须）：同步5—9月天气与飞行阈值、三机型能耗及车辆成本/排放参数。仅这些证据到位后进入完整16+8实验，不再不断新增无关地点和情景。')
h('11. 溯源与使用范围')
p('研究输入：用户提供的2026年5—9月FCD CSV、正式345节点分组表、Manuscript.pdf，以及此前V3的19点坐标/64对距离记录。输出中的文件09_Source_Integrity_Manifest.csv列SHA256哈希，方便审稿时校验版本。商业TomTom数据的公开共享需遵循数据许可；本包仅包含重新计算的描述统计及源文件哈希，不包含原始商用FCD数据的再分发。')
p('官方及参考网址：\nhttps://www.caam.gov.my/public/unmanned-aircraft-system-uas/\nhttps://aip.caam.gov.my/aip/eAIP/2025-12-02/html/eAIP/WM-ENR-5.1-en-MS.html\nhttps://github.com/tasadapullo-svg/virtua-sensorsl-traffic-sensing-jb-20260924')
# page number footer
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run('JB-CIQ POC V3.1 | 2026-10-26 | 审计资料·非运营许可');r.font.size=Pt(8);r.font.color.rgb=RGBColor(90,105,118)
path=D/'JB_CIQ_概念验证_站点证据与实验冻结报告_V3.1.docx';f.save(path)
print('REPORT',path,path.stat().st_size)
