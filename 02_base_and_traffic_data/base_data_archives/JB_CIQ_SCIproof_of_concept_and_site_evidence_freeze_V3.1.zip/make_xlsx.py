import csv, json
from pathlib import Path
from artifact_tool import Workbook,SpreadsheetFile
D=Path('/mnt/data/JB_CIQ_POC_V3_1')
w=Workbook.create()
filemaps=[
 ('01_Sites','01_Site_Evidence_Ledger.csv', None),
 ('02_Geometric_Edges','02_Edge_Geometric_and_Regulatory_Audit.csv', None),
 ('03_Monthly_R1R2','04_R1_R2_Monthly_Descriptive.csv', None),
 ('04_Hourly_R1R2','03_R1_R2_Month_Hour_Descriptive.csv', None),
 ('05_RQ_Readiness','05_RQ_Evidence_Readiness.csv', None),
 ('06_Experiment_Freeze','07_Experimental_Freeze.csv', None),
 ('07_Regulatory_Gates','08_Stage_Gates.csv', None),
 ('08_OD_Requirements','06_OD_Required_Definition.csv', None),
 ('10_Source_Hashes','09_Source_Integrity_Manifest.csv', None)]

def read(path):
 with open(D/path,encoding='utf-8-sig',newline='') as f:
  rows=list(csv.reader(f))
 for row in rows[1:]:
  for k,v in enumerate(row):
   if v and v.replace('.','',1).replace('-','',1).isdigit() and not (v[0]=='0' and len(v)>1 and v[1].isdigit()):
    try: row[k]=float(v) if '.' in v else int(v)
    except:pass
 return rows

for sheetname,filename,_ in filemaps:
 s=w.worksheets.add(sheetname)
 rows=read(filename)
 # chunk bulk write
 for start in range(0,len(rows),100):s.get_range_by_indexes(start,0,min(100,len(rows)-start),len(rows[0])).values=rows[start:start+100]
 s.get_range_by_indexes(0,0,1,len(rows[0])).format={'fill':'#123047','font':{'bold':True,'color':'#FFFFFF'},'row_height':32,'wrap_text':True,'vertical_alignment':'center'}
 s.freeze_panes.freeze_rows(1)
 s.get_range_by_indexes(0,0,len(rows),1).format.column_width=17
 for col in range(1,len(rows[0])):
  colname=rows[0][col].lower()
  wid=14 if ('count' in colname or 'month' in colname or colname in ('area','group_id','hour_local')) else 25
  if any(word in colname for word in ('rationale','mechanism','limitation','evidence','source','place_name','name','frozen','change_policy','availability','required','deliverable','requirements')):wid=39
  s.get_range_by_indexes(0,col,len(rows),1).format.column_width=wid
 s.get_range_by_indexes(1,0,max(1,len(rows)-1),len(rows[0])).format.row_height=21

# High-level dashboard with no speculative economic claims
s=w.worksheets.add('00_POC_Dashboard')
items=[['JB CIQ SCI Proof-of-Concept / Frozen Evidence v3.1',''],['As-of date','2026-10-26'],['Title','Evidence-gated multi-node UAV logistics, Johor Malaysia'],['Experimental status','GEOMETRIC + FCD TRAFFIC DESCRIPTIVE ONLY'],['A: Causeway','Dense retail/residential candidate anchors; no approved pads'],['B: Second Link','Sparse local candidate links; truck-feeder expected, unverified'],['Location records',19],['Named real POI / area anchors',15],['Study-only transfer centroids',2],['CIQ references (not launch sites)',2],['<=3 km geometric candidate edges',25],['3-4 km geometric candidate edges',7],['>4 km site pairs',32],['CAAM/site-authorized pads confirmed',0],['Confirmed flight paths',0],['Observed D1/D2 orders available',0],['Completed study gateways',0],['Core configurations frozen',16],['Supplementary aircraft configurations frozen',8],['Caution','FCD speed point != route travel time, FCD nodes != customers'],['Research role','A/B geography, D1 main task, D2 shared-demand extension'],['Official CAAM page','https://www.caam.gov.my/public/unmanned-aircraft-system-uas/'],['Source audit','10_Source_Hashes sheet + full CSV manifest in ZIP']]
s.get_range_by_indexes(0,0,len(items),2).values=items
s.get_range('A1:B1').format={'fill':'#123047','font':{'bold':True,'color':'#FFFFFF'},'row_height':36}
s.get_range('A1:A23').format.column_width=40
s.get_range('B1:B23').format.column_width=75
s.get_range('A2:A23').format.font.bold=True
s.get_range('A2:B23').format.row_height=23
s.freeze_panes.freeze_rows(1)

# Economics input sheet: zero presumed costs/demand; formula only when independently entered
s=w.worksheets.add('09_Economic_Input')
headers=['site_id','place_name','capex_RM','amortisation_years','daily_fixed_cost_RM','incremental_net_saving_per_DeliveredOrder_RM','completed_orders_per_day','break_even_completed_orders_per_day','net_incremental_cashflow_RM_day','evidence_status']
rows=[headers]
sites=read('01_Site_Evidence_Ledger.csv')
h=dict(zip(sites[0],range(len(sites[0]))))
for r in sites[1:]:
 rows.append([r[h['site_id']],r[h['place_name']],None,None,None,None,None,None,None,'REQUIRES_INDEPENDENT_DEMAND_COST_EVIDENCE'])
s.get_range_by_indexes(0,0,len(rows),len(headers)).values=rows
s.get_range('A1:J1').format={'fill':'#123047','font':{'bold':True,'color':'#FFFFFF'},'row_height':38,'wrap_text':True}
for c,wd in enumerate([12,36,18,21,22,34,23,31,32,40]):s.get_range_by_indexes(0,c,len(rows),1).format.column_width=wd
s.freeze_panes.freeze_rows(1)
for i in range(2,len(rows)+1):
 s.get_range(f'H{i}').formulas=[[f'=IF(OR(C{i}="",D{i}="",E{i}="",F{i}=""),"",IF(OR(D{i}<=0,F{i}<=0),"INVALID",(C{i}/(365*D{i})+E{i})/F{i}))']]
 s.get_range(f'I{i}').formulas=[[f'=IF(OR(C{i}="",D{i}="",E{i}="",F{i}="",G{i}=""),"",IF(D{i}<=0,"INVALID",G{i}*F{i}-C{i}/(365*D{i})-E{i}))']]
s.get_range('C2:G20').format.fill='#FFF9E9'
s.get_range('H2:I20').format.number_format='0.00'

# Site-specific stage gate chain
s=w.worksheets.add('11_Entry_Protocol')
steps=[['Stage','Start criterion','Output artifact','Fail state'],['G0 Baseline','345 FCD registry+timestamps+G groups reconcile','Frozen data audit+checksums','Reject corrupted data / unresolved units'],['G1 Site evidence','Specific parcel for each POI, permission and aviation requirements','Parcel-site suitability registry','UNKNOWN => no operative UAV site'],['G2 Network candidate','Real order anchor and 3/4km+building+airspace pass','Feasible 3D edge graph','No flight operation if any edge gate fails'],['G3 OD & traffic','Directed road links, timed FCD, D1/D2 OD','Comparable ground/hybrid OD cases','Only hypothetical scenario results'],['G4 Weather','Timestamp/location-matched observed rain, gust and thunderstorms','Weather flight/no-flight matrix','Fallback to ground or mark unserved'],['G5 Carbon/economics','Vehicle-km, aircraft kWh, energy price, grid factors, CAPEX/OPEX','Net CO2e & RM per completed order','Do not claim reduction/ROI'],['G6 Final Test','Pre-registered 16+8 scenarios and uncertainty analysis','Frozen main-result tables','Stop unless provenance/bug correction']]
s.get_range_by_indexes(0,0,len(steps),4).values=steps
s.get_range('A1:D1').format={'fill':'#123047','font':{'bold':True,'color':'#FFFFFF'},'row_height':32}
for col,width in enumerate([23,72,54,48]):s.get_range_by_indexes(0,col,len(steps),1).format.column_width=width
s.get_range('A1:D8').format.row_height=33
s.freeze_panes.freeze_rows(1)

out=D/'JB_CIQ_POC_V3.1_Evidence_Workbook.xlsx'
SpreadsheetFile.export_xlsx(w).save(str(out))
print('CREATED',out,'size',out.stat().st_size)
try:
 print('DASH',w.inspect({'kind':'table','range':'00_POC_Dashboard!A1:B15','include':'values,formulas','table_max_rows':15,'table_max_cols':3}).ndjson[:1800])
 print('ERR',w.inspect({'kind':'match','search_term':'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A','options':{'use_regex':True,'max_results':10}}).ndjson[:500])
except Exception as e:print('CHECK WARN',type(e).__name__,str(e)[:400])
