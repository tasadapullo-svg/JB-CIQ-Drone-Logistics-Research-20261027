import csv, json, math, hashlib, os, statistics, collections, datetime, pathlib
P=pathlib.Path('/mnt/data'); D=P/'JB_CIQ_POC_V3_1'; V=P/'JB_CIQ_MultiNode_V3'

def records(file):
 with open(file,'r',encoding='utf-8-sig',newline='') as f:
  yield from csv.DictReader(f)

def outcsv(path, rows, columns):
 with open(path,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,columns,extrasaction='ignore'); w.writeheader(); w.writerows(rows)

def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for x in iter(lambda:f.read(4<<20),b''):h.update(x)
 return h.hexdigest()

sites=list(records(V/'01_真实POI及候选区域清单.csv'))
edges=list(records(V/'04_全部候选节点两两距离_航段初筛.csv'))
fcd=list(records(P/'JB_FCD_G1-G5_2026_05-09'/'Node_Registry_345_Grouped.csv'))
summary=list(records(V/'03_3km4km交通支撑范围摘要.csv'))
site_lookup={x['site_id']:x for x in sites};summ_lookup={x['site_id']:x for x in summary}
for x in edges:
 assert x['from_site'] in site_lookup and x['to_site'] in site_lookup

def status(site):
 if site['place_type']=='CIQ_reference':return 'CONTEXT_ONLY_NOT_UAV_SITE'
 if site['place_type']=='study_centroid':return 'MODEL_CENTROID_NOT_PHYSICAL_SITE'
 return 'REAL_POI_OR_AREA_UNVERIFIED_PAD'

# Reasoning confined to observable place categories and documented geographical references
rationales={
 'A00':('Cross-border interface for D1 ground freight, never a UAV launch point','No UAV business case as a launch facility; provides freight-chain reference'),
 'A01':('Named shopping mall and likely retail aggregation search zone; geographic anchor, not verified rooftop','Potential aggregated retail dispatch; orders/day and pad lease unknown'),
 'A02':('Named central retail complex; paired hub/locker search in urban centre','Potential merchant consolidation or receipt; handling/rent unknown'),
 'A03':('Named retail district with surrounding arterial monitoring support','Potential delivery consolidation; restricted airspace must be resolved before any investment'),
 'A04':('Named retail facility usable as a destination/search anchor','Potential pick-up locker receipt; permission and user take-up unknown'),
 'A05':('Bus terminal/retail interchange: investigate ground feeder logistics instead of assuming UAV pad','Potential ground-UAV consolidation; traffic and terminal operating rights unresolved'),
 'A06':('Residential development geography suited to evaluating smart locker walking catchment','Potential clustered residential receipts; residents/footpath/locker access unknown'),
 'A07':('Neighbourhood area centroid; actual residential parcel receiving location must be surveyed','Potential community collection; customer count and feasible parcel site unknown'),
 'A08':('Passenger transport hub for ground transshipment reference only','Ground transfer value, not a confirmed UAV facility'),
 'B00':('Second Link border interface; D1 freight is ground transported through customs','No UAV launch assumption at border control facility'),
 'B01':('Illustrative west-side freight transfer search centre from earlier model, NOT a real property','Truck-UAV transfer option requires legal parking and site identification before valuation'),
 'B02':('Illustrative east-side freight transfer search centre from earlier model, NOT a real property','Truck-UAV transfer option requires site and access proof before valuation'),
 'B03':('Village area centroid: evaluate community receiver, not a pad','Parcel demand and customer collection radius must be observed'),
 'B04':('Village area centroid near Second Link: potential destination cluster','Potential grouped delivery if orders exist; landing/locker site unverified'),
 'B05':('Village area centroid at edge of the local catchment','Potential feeder receipt if linked to legal transfer node; volumes unknown'),
 'B06':('Township centroid: retail/residential demand search, not a particular loading zone','Potential mixed merchant/customer flows; commercial OD and site permission unknown'),
 'B07':('Retail precinct geography; peripheral to immediate CIQ catchment','Potential regional retail demand but likely needs ground feeder; economic viability untested'),
 'B08':('Named major port logistics origin; restricted secure facility and ground freight source','Potential D1 freight demand provenance; port airside access not assumed'),
 'B09':('Hotel/tourism area centroid, non-core demand extension','Peripheral hospitality demand only if validated; no order/occupancy data')}

site_rows=[]
for s in sites:
 a,b=rationales[s['site_id']]
 o=summ_lookup[s['site_id']]
 site_rows.append(dict(site_id=s['site_id'],area=s['area'],place_name=s['place_name'],place_type=s['place_type'],functional_roles=s['functional_roles'],latitude=s['latitude'],longitude=s['longitude'],coordinate_source=s['coordinate_source'],coordinates_represent='PLACE_OR_NEIGHBOURHOOD_REFERENCE_POINT_NOT_PAD',candidate_class=status(s),specific_siting_rationale=a,potential_economic_mechanism=b, fcd_3km=o['fcd_within_3km'],fcd_4km=o['fcd_within_4km'],actual_daily_orders='UNKNOWN',demand_source='NOT_PROVIDED',parcel_boundary_verified='NO',landowner_approval='NO',caam_flight_authorisation='NO',airspace_geometry_checked='NO',building_and_public_risk_checked='NO',uav_pad_operationally_confirmed='NO',evidence_gate='FAIL_PENDING_DATA',net_economic_benefit_rm='NOT_ESTIMABLE',co2_reduction_kg='NOT_ESTIMABLE'))
outcsv(D/'01_Site_Evidence_Ledger.csv',site_rows,list(site_rows[0]))

edge_rows=[]
for e in edges:
 d=float(e['geodesic_distance_km'])
 edge_rows.append(dict(area=e['area'],from_site=e['from_site'],to_site=e['to_site'],from_name=e['from_place'],to_name=e['to_place'],straight_line_km=d,spatial_bin='<=3km' if d<=3 else '3-4km' if d<=4 else '>4km',within_3km=int(d<=3),within_4km=int(d<=4),endpoint_site_evidence='NO_CONFIRMED_PAD',airspace='NOT_VERIFIED',actual_3d_route='NOT_MODELED',wind_rain_feasibility='NOT_MODELED',landing_recovery='NOT_VERIFIED',economic_value='NOT_ESTIMATED',flight_permission='NONE_CONFIRMED',eligible_for_ground_truth_flight='NO',simulation_status='GEOMETRIC_CANDIDATE_ONLY' if d<=4 else 'GROUND_FEEDER_OR_NEW_NODE_REQUIRED'))
outcsv(D/'02_Edge_Geometric_and_Regulatory_Audit.csv',edge_rows,list(edge_rows[0]))

# Actual historical FCD data: compute per corridor family and month/hour, no interpolation.
agg=collections.defaultdict(lambda:[0,0,0.,float('inf'),float('-inf')])
monthly=collections.defaultdict(lambda:[0,0,0.,0.,0.])
monthly_nodes=collections.defaultdict(set)
file=P/'JB_FCD_G1-G5_2026_05-09'/'G1_Traffic_Node_Hour_2026_05-09.csv'
seen=0
for r in records(file):
 route=r['source_route_code']; node=r['node_id']; mon=r['month']; hour=int(r['timestamp_local'][11:13]); v=r.get('observed_speed','')
 if route not in ('R1','R2'):continue
 seen+=1
 key=(route,mon,hour);a=agg[key];a[0]+=1
 m=monthly[(route,mon)];m[0]+=1;monthly_nodes[(route,mon)].add(node)
 if v not in ('','NA','nan','NaN'):
  try:speed=float(v)
  except:continue
  if not math.isfinite(speed): continue
  a[1]+=1;a[2]+=speed;a[3]=min(a[3],speed);a[4]=max(a[4],speed)
  m[1]+=1;m[2]+=speed;m[3]+=speed*speed;m[4]+=float(speed<0)
rows=[]
for (r,m,h),a in sorted(agg.items()):
 rows.append(dict(route_family=r,month=m,hour_local=h,number_node_hour_slots=a[0],nonempty_speed_count=a[1],nonempty_fraction=round(a[1]/a[0],6) if a[0] else None,mean_raw_speed=round(a[2]/a[1],3) if a[1] else None,min_raw_speed=round(a[3],3) if a[1] else None,max_raw_speed=round(a[4],3) if a[1] else None,traffic_speed_unit='ORIGINAL_UNVERIFIED',source='G1_Traffic_Node_Hour_2026_05-09.csv',note='Descriptive sensor-point mean; not OD/travel time, not exclusively MY side'))
outcsv(D/'03_R1_R2_Month_Hour_Descriptive.csv',rows,list(rows[0]))
monthly_rows=[]
for (r,m),a in sorted(monthly.items()):
 mean=a[2]/a[1] if a[1] else None
 sd=math.sqrt(max(a[3]/a[1]-mean*mean,0)) if a[1] else None
 monthly_rows.append(dict(route_family=r,month=m,node_count=len(monthly_nodes[(r,m)]),node_hour_slots=a[0],nonempty_speed_count=a[1],missing_speed_count=a[0]-a[1],nonempty_fraction=round(a[1]/a[0],6),mean_raw_speed=round(mean,3) if mean is not None else None,sd_raw_speed=round(sd,3) if sd is not None else None,negative_speed_count=int(a[4]),unit='UNCONFIRMED',limitations='Mix of route coordinates (including SG possibility); no route distance, origin-destination or CIQ waiting time'))
outcsv(D/'04_R1_R2_Monthly_Descriptive.csv',monthly_rows,list(monthly_rows[0]))

readiness=[
 ('RQ1','345 FCD grouped node positions','YES','Frozen registry and 5 group taxonomy','OBSERVED'),
 ('RQ1','19 named or centroid POI coordinates','PARTIAL','Place/area reference only; some illustrative B T1/T2','MIXED'),
 ('RQ1','3/4 km geometric adjacency','YES','25 <=3 km; 7 additional 3-4 km; geometry only','DERIVED'),
 ('RQ1','Validated airspace polygon for current AIRAC/NOTAM','NO','WMP228 coordinate discrepancy and other restrictions need authoritative verification','REQUIRED'),
 ('RQ1','Landowner permission, UAV pads, public risk, roof/buildings','NO','No parcel/roof/land title/building-height proof','REQUIRED'),
 ('RQ1','Real merchant/residential delivery OD and demand','NO','POI/FCD counts are NOT orders','REQUIRED'),
 ('RQ1','Legal flyable coverage and route altitude','NO','Needs approvals, obstacles, energy, geofencing','REQUIRED'),
 ('RQ2','5-month R1/R2 observed traffic speed by time','YES_WITH_LIMITS','Descriptive route-family virtual FCD points; September schema difference','OBSERVED'),
 ('RQ2','Full directed MY road-network edges and lengths','NO','Static node coordinates do not define path travel times','REQUIRED'),
 ('RQ2','Ground freight and D1/D2 order timestamps, tasks','NO','No actual orders or packages','REQUIRED'),
 ('RQ2','End-to-end border processing/wait time','NO','FCD approach corridor speed cannot identify clearance time','REQUIRED'),
 ('RQ2','Ground vs UAV comparable time savings','NO','Must use same OD/fulfillment definitions','FUTURE'),
 ('RQ3','Rainfall association reported in prior paper','PARTIAL','Published manuscript method window 20 Apr–31 Aug; not UAV weather fitness','SOURCE_CLAIM'),
 ('RQ3','Timestamp-matched May-Sep rainfall/gust/thunderstorm records','NO','No joined 5-month air-operability table audited in this run','REQUIRED'),
 ('RQ3','M2/M3/FC30 per-task energy/weather certified bounds','NO','Need fixed specification source and payload assumption','REQUIRED'),
 ('RQ3','Ground fuel/EV energy, mileage, MY electricity factor','NO','No full vehicle/flight energy inventory','REQUIRED'),
 ('RQ3','Net carbon and full economic comparison','NO','Cannot infer from speed or nodes alone','FUTURE')]
ready_rows=[dict(rq=a,evidence_item=b,data_state=c,precise_limitation=d,provenance_class=e) for a,b,c,d,e in readiness]
outcsv(D/'05_RQ_Evidence_Readiness.csv',ready_rows,list(ready_rows[0]))

OD=[
 dict(demand_class='D1',name='CIQ-related parcels',origin='On Malaysia side after/before border-truck leg or verified sorting point',destination='Verified business/community parcel collection site',time_unit='order creation and promised delivery timestamp',required='site_id, origin/dest, pkg_mass_kg, release_time, deadline, failed-delivery rule, customs status, orders/day',availability='NOT PROVIDED',interpretation='Core research group, truck must cross CIQ in S1'),
 dict(demand_class='D2',name='Local on-demand GrabFood-type',origin='Verified merchant or restaurant cluster',destination='Approved community locker or attended pickup point',time_unit='merchant-ready and collection time',required='merchant count, OD, pkg mass, thermal/food safety window, walking pickup time, daily demand',availability='NOT PROVIDED',interpretation='Shared facility extension; no real Grab data assumed')]
outcsv(D/'06_OD_Required_Definition.csv',OD,list(OD[0]))

freeze=[
 dict(item='Geography',frozen='Johor side A Causeway + B Second Link, SG is contextual only',change_policy='No third region'),
 dict(item='Study time',frozen='2026-05-01 to 2026-09-30 (+08:00)',change_policy='Do not extend main period'),
 dict(item='FCD grouping',frozen='345 G1-G5 (G1 R1=24,R2=22), original node IDs',change_policy='No outcome-based regroup'),
 dict(item='Demand classes',frozen='D1 alone vs D1+D2 sharing',change_policy='No third demand class'),
 dict(item='Logistics strategies',frozen='Ground baseline, fixed-hub, truck-drone hybrid',change_policy='Same OD baseline and identical service definition'),
 dict(item='Radius',frozen='3 km vs 4 km geographic service screening',change_policy='No extra radius in main results'),
 dict(item='UAV families',frozen='M2 primary; M3 and FC30 supplementary; certification and task fit to verify',change_policy='No extra UAV families'),
 dict(item='Core configurations',frozen='2 areas x 2 logistics modes x 2 radii x 2 order mixes = 16',change_policy='Lock prior to quantitative simulation'),
 dict(item='Supplementary aircraft',frozen='2 additional aircraft x 2 areas x 2 modes at 4km+D1+D2 = 8',change_policy='Only if eligible tasks/params verified'),
 dict(item='Airspace gating',frozen='Unknown is INELIGIBLE for operational flights; theoretical edges tagged separately',change_policy='No optimistic legalization'),
 dict(item='KPIs',frozen='Eligible order coverage, end-to-end task time, on-time rate, displaced vehicle-km, net CO2e, RM/order',change_policy='No post-hoc cherry picking'),
 dict(item='Stop rule',frozen='End after locked configurations, QC and predeclared uncertainty tests',change_policy='Add experiments only through amendment log')]
outcsv(D/'07_Experimental_Freeze.csv',freeze,list(freeze[0]))

risks=[
 ('GATE-A','Airspace & aviation','CAAM SUP + current AIP/AIRAC/NOTAM for each launch, recovery and flight corridor','CAAM approval and site-specific verification','BLOCKING'),
 ('GATE-B','Parcel access','Land-use, parcel ownership, safe pad/locker availability, people/obstacles','Parcel/site survey and permission','BLOCKING'),
 ('GATE-C','Demand','Observed or transparent scenario-generated D1/D2 OD, load and time windows','OD log + scenario freeze','BLOCKING for actual benefits'),
 ('GATE-D','Ground network','Directed road edges, path lengths and matched FCD speed','Network GeoPackage with edge FCD join','BLOCKING for travel times'),
 ('GATE-E','Flight physics','Validated payload-energy, mission reserve, weather limits, height and diversion','Aircraft spec/energy model references','BLOCKING for real flyable coverage'),
 ('GATE-F','Weather','Aligned rain, wind, gust, thunderstorm data May-Sep','Hourly weather time key + spatial matching','BLOCKING for weather benefits'),
 ('GATE-G','Economics','Capex, pad lease, staffing, battery, maintenance, handling/locker costs','Cost sheet and demand throughput','BLOCKING for economic claims'),
 ('GATE-H','CO2e','Truck/rider distances, fuel/energy, UAV grid energy with battery losses','Fleet factors + grid factor + system boundary','BLOCKING for carbon claims')]
vr=[dict(gate=a,domain=b,evidence_required=c,deliverable=d,priority=e,verified='NO',signoff='PENDING') for a,b,c,d,e in risks]
outcsv(D/'08_Stage_Gates.csv',vr,list(vr[0]))

source_paths=[P/'JB_CIQ_MultiNode_V3'/'01_真实POI及候选区域清单.csv',P/'JB_CIQ_MultiNode_V3'/'04_全部候选节点两两距离_航段初筛.csv',P/'JB_CIQ_MultiNode_V3'/'03_3km4km交通支撑范围摘要.csv',P/'JB_FCD_G1-G5_2026_05-09'/'G1_Traffic_Node_Hour_2026_05-09.csv',P/'JB_FCD_G1-G5_2026_05-09'/'Node_Registry_345_Grouped.csv',P/'分组道路_Final_Group_Road_Crosswalk_v1_20260921.xlsx',P/'论文分组道路_Final_Road_Group_Freeze_v1_20260921.xlsx',P/'Manuscript.pdf'] + [P/f'PROVISIONAL_FCD_JB_2026_{month}_345NODE_ANALYSIS_V1.csv' for month in ['05','06','07','08','09']] + [V/'07_POI候选网络节点.geojson', V/'08_4km内几何候选航段_未获批.geojson', V/'09_FCD正式冻结节点_345.geojson']
man=[dict(file=str(x.relative_to(P)),size_bytes=x.stat().st_size,sha256=digest(x),role='INPUT_ARCHIVED_SEPARATELY') for x in source_paths]
outcsv(D/'09_Source_Integrity_Manifest.csv',man,list(man[0]))

counts=collections.Counter((x['area'],x['spatial_bin']) for x in edge_rows)
analysis=dict(sites=len(sites),sites_physical_real=sum(x['candidate_class']=='REAL_POI_OR_AREA_UNVERIFIED_PAD' for x in site_rows),study_centroids=sum(x['candidate_class']=='MODEL_CENTROID_NOT_PHYSICAL_SITE' for x in site_rows),ciq_reference=sum(x['candidate_class']=='CONTEXT_ONLY_NOT_UAV_SITE' for x in site_rows),edges=len(edges),edges_3=sum(x['within_3km'] for x in edge_rows),edges_3to4=sum(x['spatial_bin']=='3-4km' for x in edge_rows),edges_over4=sum(x['spatial_bin']=='>4km' for x in edge_rows),route_observations=seen,monthly=monthly_rows,area_edge_bins={a:{key:counts[(a,key)] for key in ('<=3km','3-4km','>4km')} for a in ('A','B')},eligible_sites=0,eligible_flight_edges=0,observed_order_records=0,readiness_gates_passed=0,created_at_local='2026-10-26',title='Geometric and traffic-data proof of concept, not certified operational feasibility')
(D/'10_POC_Results_Audit.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(analysis,ensure_ascii=False,indent=2)[:7000])
