# Evidence-limited drafting starter — NOT final SCI manuscript text

**Status:** 2026-10-26; this draft contains only supported study-system and geometric pilot statements. Replace all provisional text after site and data gates pass.

## 2. Study Area and Data (draft)

This study examines two road–logistics interfaces in Johor, Malaysia: the Causeway–Sultan Iskandar CIQ interface (Area A) and the Second Link–Sultan Abu Bakar CIQ interface (Area B). The main regulatory scenario maintains ground transportation for cross-border cargo. Potential UAV activity is considered only for Malaysian-side collection, transshipment, or last-mile delivery, subject to applicable airspace restrictions and operational approvals. The two areas are treated as contrasting candidate network structures, not as evidence of different operational performance.

The traffic input uses a frozen registry of 345 software-defined floating-car-data (FCD) query locations grouped into five predefined road-operating environments (G1–G5). The G1 cross-border group contains 46 traffic query nodes subdivided into 24 observations associated with route family R1 (Causeway) and 22 with R2 (Second Link). The investigation's five-month traffic window runs from May through September 2026 and is maintained on a local UTC+08 hourly timestamp grid. Records retain the original node identifiers, fixed spatial reference, route-family membership, and available original hourly speed observations. FCD sampling nodes are not physical detectors, logistics customers, or UAV facilities. Traffic speeds at these points do not by themselves identify complete origin–destination travel times or border-clearance delay.

For an initial site-search proof of concept, 19 geographic references are documented, including 15 named places or area centres, two study-defined transfer-search centroids, and two CIQ reference locations. Their coordinates and source URLs are recorded individually in the site evidence ledger. A total of 64 same-area unordered reference pairs (excluding CIQ reference nodes from candidate connections) are compared using WGS84 geodesic screening. Twenty-five pairs have straight-line separation not exceeding 3 km, and seven further pairs lie above 3 km and no more than 4 km. These pairs are geometric adjacency candidates only; no UAV airspace, obstacle, landing facility, energy reserve, or operating permit has been verified for them.

## 3. Conceptual Model and Preregistered Evaluation (draft)

The principal demand class, D1, is defined as small consignments associated with the CIQ-linked ground freight chain. D2 denotes local on-demand parcels or meals sharing potential logistics facilities. The primary comparisons will contrast D1-only demand with D1+D2 demand sharing, using the same underlying task sets for pure-ground, fixed-hub UAV and truck–UAV modes. The latter two modes are to be tested in both areas to avoid confounding transport organisation with geographic context.

The geometric service screening radius is fixed at 3 km and 4 km. A route's actual eligibility additionally requires a site-level and full-path regulatory check, a three-dimensional obstacle and terrain check, an aircraft-specific payload–energy–reserve calculation, and weather-related operating conditions. Absence of this evidence does not imply eligibility. For defensible end-to-end comparisons, the analysis must obtain or transparently simulate timestamped parcel OD demand, link-level directed road geometry joined to FCD observations, and the same trip-completion definition under ground-only and ground–air strategies. The planned environmental assessment compares matched completed orders, including vehicle and aircraft energy, support operations, and weather-induced ground fallback.

The structural primary experiment matrix is fixed at 2 study areas × 2 network modes × 2 radii × 2 demand mixes = 16 configurations using an M2-class reference. A supplementary comparison considers two other aircraft types only for the 4 km and shared-demand scenarios across both areas and modes, adding a maximum of eight configurations. These configurations are not yet executable as operational comparisons because site access, airspace, OD, complete directed road links, aircraft performance and timestamp-matched weather evidence have not passed the predetermined evidence gates. Negative, infeasible, and missing-evidence outcomes will be retained in the audit trail.

## Placeholder results (NOT available)

- RQ1: No legally flyable service area, operational hub count, or true parcel order coverage has been established.
- RQ2: No validated end-to-end time savings, on-time delivery effects, or displaced vehicle-kilometres have been estimated.
- RQ3: No net CO2e reduction, per-order economic return, or aircraft-specific weather availability has been estimated.

## Required source citations in the final manuscript

1. User-provided *Reliability-Aware Multisource Virtual Traffic Sensing...* manuscript, 2026-09-24 version, Sections 2.1–2.3. The formal study window in that document is 20 April–31 August 2026; the UAV study's September extension must be described as a distinct dataset version.
2. CAAM UAS operational approvals: https://www.caam.gov.my/public/unmanned-aircraft-system-uas/
3. Malaysia AIP ENR 5.1 historical record (must be updated and cross-checked with the effective AIRAC and NOTAM): https://aip.caam.gov.my/aip/eAIP/2025-12-02/html/eAIP/WM-ENR-5.1-en-MS.html
4. Exact per-place coordinate URLs are stored in the site ledger, not generalized in this text.
