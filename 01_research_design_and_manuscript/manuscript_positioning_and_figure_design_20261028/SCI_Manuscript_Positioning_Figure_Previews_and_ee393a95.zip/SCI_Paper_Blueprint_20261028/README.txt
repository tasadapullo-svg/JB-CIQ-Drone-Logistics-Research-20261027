SCI 投稿定位工作包，2026-10-28

主要文档：JB_SCI_初稿定位_完整大纲与图表设计_20261028.docx
figures/ 包含六组CSV派生的300dpi PNG和矢量SVG图表预览。
figure_evidence_matrix.csv 可编辑图表—RQ—数据—证据矩阵。
build_blueprint.py 为完全可复算的图表与DOCX生成脚本，需要 pandas, matplotlib, python-docx。

inputs/ 含本次图表所使用的四个既有 SCI_Final CSV 的工作副本；脚本可就地复算图表与DOCX，不是重新运行Stage6引擎。
此包用于论文定位与图表设计，不是投稿完成稿；图表只展示现有模型假设下的结果。
