from pathlib import Path
import pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_BREAK
import csv

ROOT=Path(__file__).resolve().parent; FIG=ROOT/'figures'; SRC=ROOT/'inputs'
daily=pd.read_csv(SRC/'sci_final_daily.csv'); mask=pd.read_csv(SRC/'rq1_WMP228_summary.csv'); mselect=pd.read_csv(SRC/'sci_final_feasible_modes.csv'); area=pd.read_csv(SRC/'sci_final_area_summary.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':12,'axes.labelsize':10,'figure.dpi':100,'savefig.dpi':300,'svg.fonttype':'none'})
COL=['#3A5F82','#C46B35','#4E8678','#805A9C','#666666']

def save(name):
 plt.savefig(FIG/(name+'.png'),bbox_inches='tight',dpi=300)
 plt.savefig(FIG/(name+'.svg'),bbox_inches='tight')
 plt.close()

# Fig A: conceptual flow
fig,ax=plt.subplots(figsize=(12.0,2.5));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
blocks=[('Input evidence','Synthetic orders, OSM OD,\nweather & UAV scenarios'),('RQ1 · Feasibility','Sites, range, weather,\nCAAM/CAAS masks'),('RQ2 · Operations','M0 / M1 / M2,\ncompletion, P95, fallback'),('RQ3 · Carbon','Fuel + electricity ledger,\nLC-M1 / simple rule'),('Decision boundary','Service + cost constraints;\nconditional mode advice')]
xs=np.linspace(0.102,0.90,len(blocks))
for i,(name,txt) in enumerate(blocks):
 x=xs[i]; ax.text(x,.61,name,ha='center',va='center',weight='bold',fontsize=10,bbox={'boxstyle':'round,pad=.45','facecolor':'#F0F3F6','edgecolor':'#8A98A7'})
 ax.text(x,.27,txt,ha='center',va='center',fontsize=7.7,color='#354454')
 if i:ax.annotate('',xy=(x-.07,.62),xytext=(xs[i-1]+.07,.62),arrowprops={'arrowstyle':'->','color':'#667D92','lw':1.7})
fig.text(.5,.02,'Scenario-based feasibility → operational comparison → constrained operational-carbon choice',ha='center',fontsize=9,color='#555')
save('preview_F2_research_workflow')
# Fig B RQ1 coverage
r=mask[(mask.aircraft=='W198')].copy()
order=['REFERENCE_UNMASKED','CAAS_2025','CAAM_2025','UNION_CONSERVATIVE']; labels=['No WMP mask','CAAS 2025','CAAM 2025','Conservative union']
fig,axs=plt.subplots(1,2,figsize=(11.5,3.7),sharey=True)
for ax,reg,c in zip(axs,['A','B'],[COL[0],COL[2]]):
 s=r[r.area==reg].set_index('case').loc[order]; v=s.air_drone_coverage_pct.to_numpy(); bars=ax.bar(labels,v,color=[c]*4,width=.62)
 ax.set_title('Area '+reg+' · '+('Causeway' if reg=='A' else 'Second Link'));ax.set_ylim(0,15.5);ax.tick_params(axis='x',rotation=20,labelsize=8); ax.grid(axis='y',alpha=.15)
 for bar,val in zip(bars,v):ax.text(bar.get_x()+bar.get_width()/2,val+.3,f'{val:.1f}%',ha='center',fontsize=8)
axs[0].set_ylabel('Share of synthetic order records (%)')
fig.text(.5,-.03,'W198 central scenario; 30 seeds × 5 dates. Complete-circle exclusion; not a flight-permission map.',ha='center',fontsize=8)
fig.tight_layout();save('preview_F3_airspace_coverage')
# Fig C time P95 distributions (per day, W198 central)
fig,axs=plt.subplots(1,2,figsize=(11.5,4),sharey=False)
for ax,reg in zip(axs,['A','B']):
 sels=[]
 for mode in ['M0','M1','M2','LC-M1']:
  s=daily[(daily.area==reg)&(daily['mode']==mode)]
  if mode!='M0':s=s[(s.aircraft=='W198')&(s.energy_case=='central')&(s.fuel_case=='CAR')]
  else:s=s[s.fuel_case=='CAR']
  sels.append(s.p95_door_min.values)
 bp=ax.boxplot(sels,patch_artist=True,showfliers=False,medianprops={'color':'black'},whiskerprops={'color':'#777'})
 for patch,c in zip(bp['boxes'],[COL[4],COL[0],COL[2],COL[1]]):patch.set_facecolor(c); patch.set_alpha(.64)
 ax.set_xticks([1,2,3,4],['M0','M1','M2','LC-M1']); ax.set_title('Area '+reg+' · daily P95');ax.set_ylabel('Daily 95th percentile completion time (min)');ax.grid(axis='y',alpha=.2)
 fig.text(.5,.015,'Each box pools 150 seed–date units; descriptive distributions, not independent observations.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.04,1,1));save('preview_F4_service_p95')
# Fig D Carbon cost axes (ratio vs M0) for each group
fig,axs=plt.subplots(1,2,figsize=(11.5,4.6))
for ax,reg in zip(axs,['A','B']):
 baseline=daily[(daily.area==reg)&(daily['mode']=='M0')&(daily.fuel_case=='CAR')]
 E=baseline.operational_CO2e_kg.sum();C=baseline.total_cost_MYR.sum();
 labels=['M0','M1','M2','SimpleLC','LC-M1'];lookup={}
 for mode in labels:
  if mode=='M0':e,c=E,C
  else:
   d=area[(area.area==reg)&(area['mode']==mode)&(area.aircraft=='W198')&(area.energy_case=='central')&(area.fuel_case=='CAR')]
   e=float(d.operational_CO2e_kg.iloc[0]);c=float(d.total_cost_MYR.iloc[0])
  lookup[mode]=(e/E,c/C)
 dx={'M0':(.018,-.030),'M1':(.01,.026),'M2':(.015,.027),'SimpleLC':(.015,-.025),'LC-M1':(.015,.015)}
 for i,mode in enumerate(labels):
  x,y=lookup[mode]
  ax.scatter(x,y,s=100,color=COL[i],marker=['s','o','D','^','X'][i],zorder=4)
  if reg=='B' and mode=='SimpleLC': continue
  tag=mode if not(reg=='B' and mode=='LC-M1') else 'LC-M1 / SimpleLC'
  ax.annotate(tag,(x,y),xytext=(x+dx[mode][0],y+dx[mode][1]),fontsize=8)
 ax.axvline(1,lw=1,ls='--',color='#888');ax.axhline(1,lw=1,ls='--',color='#888')
 ax.axhline(1.25,lw=1,ls=':',color='#aa6666');ax.set_xlabel('Operational CO₂e / M0');ax.set_ylabel('Total scenario cost / M0');ax.set_title('Area '+reg+' · W198 central');ax.grid(alpha=.12)
 if reg=='A':ax.set_xlim(.82,1.15);ax.set_ylim(.95,1.78)
 else:ax.set_xlim(.95,1.055);ax.set_ylim(.95,2.75)
fig.text(.5,.012,'All-mode totals across 150 seed–date units. Points are NOT all constraint-feasible; A UAV scenarios are unmasked diagnostics.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.05,1,1));save('preview_F5_carbon_cost')
# Fig E feasible ex post
counts=mselect.groupby(['area','preferred_mode_under_constraints']).size().unstack(fill_value=0)
fig,ax=plt.subplots(figsize=(9.5,3.7));y=np.arange(2);width0=[counts.loc[x,'M0'] for x in ['A','B']];width2=[counts.loc[x,'M2'] if 'M2' in counts.columns else 0 for x in ['A','B']]
ax.barh(y,width0,label='M0',color=COL[4],height=.44);ax.barh(y,width2,left=width0,label='M2',color=COL[2],height=.44)
for i,vals in enumerate(zip(width0,width2)):
 w0,w2=vals;ax.text(w0/2,i,str(w0),color='white',ha='center',va='center',weight='bold')
 if w2:ax.text(w0+w2/2,i,str(w2),color='white',ha='center',va='center',weight='bold')
ax.set_yticks(y,['Area A','Area B']);ax.invert_yaxis();ax.set_xlim(0,160);ax.set_xlabel('Seed–date units (150 per area)');ax.legend(loc='upper center',ncol=2,frameon=False);ax.set_title('Ex-post feasible-mode choices, central W198 reference');ax.grid(axis='x',alpha=.18)
fig.text(.5,.007,'Separate from strict LC-M1 subset test (0 UAV days across 1,800 evaluations); not an online decision policy.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.055,1,1));save('preview_F6_mode_choice')
# Supplement: motorcycle sensitivity is deliberately a car-route proxy, not an empirically validated motorcycle operation.
fig,ax=plt.subplots(figsize=(9.8,3.5))
regs=['A','B']; mcar=[daily[(daily.area==g)&(daily['mode']=='M0')].operational_CO2e_kg.sum() for g in regs]; moto=[daily[(daily.area==g)&(daily['mode']=='M0_MOTO')].operational_CO2e_kg.sum() for g in regs]
xs=np.arange(2);b0=ax.bar(xs-.2,mcar,width=.36,color=COL[4],label='M0 petrol car'); b1=ax.bar(xs+.2,moto,width=.36,color=COL[1],label='M0 motorcycle proxy')
for bar in list(b0)+list(b1):ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+280,f'{bar.get_height():,.0f}',ha='center',fontsize=9)
ax.set_xticks(xs,['Area A','Area B']); ax.set_ylabel('Aggregated operational CO₂e (kg)');ax.set_title('Motorcycle intensity sensitivity: ground-only modes');ax.legend(frameon=False);ax.grid(axis='y',alpha=.15)
fig.text(.5,.01,'Motorcycle keeps car routing/travel-time/resource assumptions; emissions difference is a proxy scenario, not field validation.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.06,1,1));save('preview_SF_motorcycle_proxy')


# Blueprint register for editable import
specs=[
('F1','Main','RQ1','Johor Bahru spatial context and candidate networks','Two Malaysia-side corridor maps; candidate sites, OSM connectivity, technical legs, border location','Network-level geography; MUST verify coordinates and GIS attribution; no approval implication','Site/edge GIS source; needs final cartography','Planned'),
('F2','Main','RQ1–RQ3','Evidence-to-decision methodological workflow','Synthetic demand, road/weather, airspace, scenario engine, costs, services, carbon, audit','Explains causal order of evaluation, not claim of algorithmic novelty','Created preview_F2','Ready for layout'),
('F3','Main','RQ1','WMP228 boundary sensitivity and eligible coverage','A/B coverage across unmasked/CAAM/CAAS/union; map inset','A is boundary-sensitive; B unaffected by this mask alone','rq1_WMP228_summary.csv; existing schematic','Data-ready'),
('F4','Main','RQ2','Full-chain delivery service and reliability','M0/M1/M2/LC-M1 paired completion times, P95, 30-min SLA by area','Service benefits are conditional and not universal','sci_final_daily.csv; sci_final_pairs.csv','Data-ready'),
('F5','Main','RQ3','Operational emissions–cost–service trade-offs','CO2e ratio vs cost ratio; symbols for feasible/violating modes','Carbon-only improvements do not imply admissibility','sci_final_area_summary.csv + daily/constraint tables','Data-ready, refine feasibility symbols'),
('F6','Main','RQ3','Constraint-acceptable scenario choices','A/B choice frequencies and strict LC-M1 failure vs M0 fallback','M2 B feasible in subset; strict LC-M1 test has zero UAV candidates accepted','sci_final_feasible_modes.csv; lc_m1_closed_summary.csv','Data-ready'),
('F7','Main','RQ1–RQ3','Conditional decision matrix for corridor deployment','Flowchart: airspace → weather/range → SLA/cost → emissions → choose M0/M2/other','Converts findings into conditional policy, not an issued flight license','Synthesis of all outputs','Concept ready'),
('S-F1','Supplement','RQ1','Reference UAV/energy scenario envelope','Range, payload, Wh/km low/central/high','Energy numbers are engineered, not measured','sci_final_parameter_registry.json','Planned'),
('S-F2','Supplement','RQ2','Release-hour weather eligibility / fallback','Months/areas; weather pass + fallback proportions','Not actual-time take-off screening','sci_final_weather_screen.csv','Partly ready'),
('S-F3','Supplement','RQ3','Seed-cluster paired uncertainty','Paired effect intervals across 30 seeds','Uncertainty excludes systematic assumptions','sci_final_bootstrap.csv','Ready for editorial selection'),
('S-F4','Supplement','RQ3','Scenario sensitivity and boundary stress','Aircraft energy × fuel baseline, B stress','Which rankings depend on assumptions','stage6_sensitivity_B_summary.csv + sci_final_area_summary.csv','Planned'),
('S-F5','Supplement','RQ3','Motorcycle fuel-intensity proxy vs petrol car','M0 car/motorbike CO2e per A/B, with limitations note','Lower motorbike proxy emissions are not validated dispatch feasibility','sci_final_daily.csv','Data-ready')]
with open(ROOT/'figure_evidence_matrix.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['Figure','Placement','RQ','Working title','Contents','Supports and does not support','Source','Status']);w.writerows(specs)

# DOCX helpers
D=Document();sec=D.sections[0];sec.top_margin=Cm(2.15);sec.bottom_margin=Cm(2.0);sec.left_margin=Cm(2.35);sec.right_margin=Cm(2.15)
styles=D.styles;normal=styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(10.2);normal.paragraph_format.space_after=Pt(5);normal.paragraph_format.line_spacing=1.2
normal._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Serif CJK SC')
for nm,sz in [('Title',20),('Heading 1',14),('Heading 2',11.5),('Heading 3',10.5)]:
 st=styles[nm];st.font.name='Times New Roman';st.font.size=Pt(sz);st.font.color.rgb=RGBColor(18,26,37);st._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Serif CJK SC')
 st.paragraph_format.space_before=Pt(10 if nm!='Title' else 0);st.paragraph_format.space_after=Pt(5)

def P(t='',boldlead=None):
 x=D.add_paragraph()
 if boldlead and t.startswith(boldlead):x.add_run(boldlead).bold=True;x.add_run(t[len(boldlead):])
 else:x.add_run(t)
 return x

def H(t,lev=1):D.add_heading(t,level=lev)

def TAB(headers,rows,widths=None):
 t=D.add_table(rows=1,cols=len(headers));t.style='Table Grid';t.alignment=WD_TABLE_ALIGNMENT.CENTER
 for i,h in enumerate(headers):
  c=t.rows[0].cells[i];c.text=str(h)
  for pp in c.paragraphs:
   for rr in pp.runs:rr.bold=True;rr.font.size=Pt(8.7)
 for rr in rows:
  c=t.add_row().cells
  for i,v in enumerate(rr):
   c[i].text=str(v)
   c[i].vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   for pp in c[i].paragraphs:
    pp.paragraph_format.space_after=Pt(0)
    for run in pp.runs:run.font.size=Pt(8.3)
 for row in t.rows:
  for cell in row.cells:
   cell._tc.get_or_add_tcPr()
 D.add_paragraph('').paragraph_format.space_after=Pt(1)
 return t

def FIGURE(filename,caption,width=16.0):
 para=D.add_paragraph();para.alignment=WD_ALIGN_PARAGRAPH.CENTER;para.add_run().add_picture(str(FIG/filename),width=Cm(width))
 cp=D.add_paragraph(caption);cp.alignment=WD_ALIGN_PARAGRAPH.CENTER
 for run in cp.runs:run.italic=True;run.font.size=Pt(8.4)

def BUL(txt):
 x=D.add_paragraph(style='List Bullet');x.add_run(txt)

# Cover
p=D.add_paragraph();p.style=styles['Title'];p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run('JB 低碳无人机物流 SCI 论文\n初稿定位、图表设计与全文大纲')
p=D.add_paragraph('Manuscript Positioning & Evidence-Driven Figure Blueprint');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.runs[0].italic=True
p=D.add_paragraph('2026-10-28   |   Research Article   |   Target: Sustainability (MDPI)');p.alignment=WD_ALIGN_PARAGRAPH.CENTER
P('文档性质：论文写作蓝图与第一版论证稿，不是已经完成同行评审的全文。严格依据已核验的 Stage 6 / SCI Final 工程文件及附带中文报告，外部文献仅用于期刊定位和研究背景。')
H('0. 一页执行摘要')
P('建议论文唯一主题：在 Johor Bahru 两条马来西亚侧边境走廊中，识别无人机—地面物流在空间、服务、成本和运营碳排放方面的可接受条件与失效边界。研究是条件性情景仿真，而非真实跨境通关服务或商业飞行可行性认证。')
TAB(['维度','冻结定位 / 已有证据','写作边界'],[
 ('研究对象','A: Causeway；B: Second Link；仅马来西亚侧模拟 OD','不能写成跨境清关配送'),
 ('数据规模','29,842 合成订单记录；30 种子×5 日期；2 区域','同一合成需求重复仿真不等于29,842份真实订单'),
 ('主要模式','M0 汽油基线、M1 常规地空、M2 协同、SimpleLC、LC-M1','M2 主要用于效率和可行性比较'),
 ('RQ1 结论','A：1,934→保守并集0；B：726→726（均为参考任务累计）','WMP 圆域是保守代理、不是许可'),
 ('RQ3 结论','严格 LC-M1 1,800个情景日组全部最终回退 M0；B M2另有65/150组可选','离线后验基准，不能称在线控制成功'),
 ('摩托车对照','M0_MOTO：A 4,367.7kg、B 11,670.5kg；低于汽车M0','仅燃油强度代理，不具独立摩托车派单验证'),
 ('证据质量','已有订单配对、燃油账本与独立 QA','未取得12配置清单；无实测飞行与完整LCA')])

H('1. 投稿期刊、写作定位和与现有研究的差异')
H('1.1 主投建议：Sustainability',2)
P('根据期刊 2026 年官方网页：Sustainability 是同行评审开放获取期刊；2025 JCR Environmental Sciences、Environmental Studies 属 Q2，但 Green & Sustainable Science & Technology 属 Q3；2025 IF 4.1；官方 APC 为 CHF 2,400（投稿前再次核对）。因此是否满足学院“JCR Q2”要求需按学院认可的具体学科类别判定，不能笼统声称所有类别均 Q2。')
P('文章类型：Research Article。推荐按 IMRaD 写法组织，不采用“新型优化算法”叙事。建议正文 7,500–9,000 英文词（内部编写目标，非期刊硬性字数限制），主图 7 张、主表 6 张，追加 Supplementary 文件。摘要目标 180–200 词并按期刊最终投稿须知复核。')
H('1.2 文献竞争与真实研究空白',2)
P('特别需要正面比较 Cui 与 Li（Sustainability 2026, 18, 3978, DOI: 10.3390/su18083978）：该文已开展边境地区、空域限制、卡车—无人机协同与碳价不确定性研究，并开发了优化模型。因此，“首次考虑边境空域＋无人机低碳”不是可支持的创新声明。')
P('本文应定位为另一类贡献：以 JB 双口岸邻近走廊为独立地理案例，基于合成需求、历史交通/天气代理、WMP228 双资料保守圆域、燃油/柴油/购电运营账本，比较完整链路可靠性并呈现无人机不可行或不低碳时的决策边界。研究空白的普遍性仍需用足量文献核验，不能由单一文献推定。')
TAB(['与已有代表性文献相比','已有研究关注点','本研究可主张的差异'],[
 ('Brown & Bushuev, 2024','无人机、燃油车、电车等末端配送碳排放；结果受参数影响','增加特定口岸邻近双走廊的空间/服务约束'),
 ('Bao et al., 2025','无人机—车辆并行系统生命周期与经济评估','本研究限定运营碳，不宣称LCA优势'),
 ('Cui & Li, 2026','边境约束、卡车-无人机、优化算法与碳价','本研究聚焦双来源空域冲突＋完整服务基线＋负向可行结果'),
 ('TR-D, 2026 LCA研究','无人机/三轮车/燃油车生命周期差异','本文解释为何运营净减排不等于生命周期减排')])
H('1.3 候选标题与关键词',2)
P('主标题（建议冻结）：Airspace-Constrained Drone–Ground Logistics in Johor Bahru: A Reproducible Assessment of Spatial Feasibility, Service Reliability, and Operational Carbon Trade-offs')
P('中文题名：空域约束下柔佛新山无人机—地面协同物流的空间可行性、服务可靠性与运营碳排放权衡：一项可复现仿真研究')
P('Keywords: drone–ground logistics; last-mile delivery; airspace constraints; operational carbon emissions; service reliability; synthetic demand; Johor Bahru; scenario analysis.')
H('2. 核心科学问题、可验证假设与贡献')
TAB(['研究问题','检验机制','证据','允许的结论'],[
 ('RQ1 · 哪里可能可行？','候选站点/航段×载荷/航程×释放小时天气×WMP228情景','F1/F3；T1/T3','具体技术候选与边界敏感性'),
 ('RQ2 · 何时更有效？','M0/M1/M2完整链路，完成率、门到门时间、日级P95、30min准时率','F4；T4','模式效率是区域/天气/场景依赖的'),
 ('RQ3 · 何种模式最低运营碳？','燃油车+柴油干线+无人机购电；成本/服务硬约束；SimpleLC/LC-M1','F5/F6/F7；T5/T6','有些无人机候选排放下降但不可接受，M0可为合理选择')])
P('建议三项贡献（均须以已有结果/图表支持）：① 多源公开资料争议下的保守空间候选筛查与网络覆盖报告；② 对完整物流链采用可配对、成本和服务一致的运营评价，报告负向时段与天气回退；③ 明确区分“可见碳排放潜力”和“满足硬约束的条件性模式选择”，将失败结果纳入决策准则。')
P('不建议写：提出最优在线 LC-M1 算法、验证实际合法航线、证明全生命周期减排、对新加坡跨境运营已完成验证、验证12配置全矩阵、两参考机型已实测标定。')

H('3. 摘要雏形（英文，可按主图最终数据微调）')
abstract=(
'Drone–ground delivery may reduce road transport emissions, but its usefulness in border-adjacent urban corridors depends on spatial restrictions, service reliability, and operating costs. This study presents a reproducible scenario-based assessment for two Malaysian-side logistics corridors in Johor Bahru, associated with the Causeway and Second Link. We evaluate 29,842 synthetic order records over five representative dates and 30 demand seeds, combining road travel-time proxies, historical weather at order-release hours, two reference drone specifications, and an operational emissions ledger for petrol cars, motorcycle proxies, diesel linehaul, and grid electricity. The assessment compares ground-only and hybrid delivery modes and tests conservative exclusion circles derived from conflicting WMP228 aeronautical information sources. In Area A, 1,934 unmasked candidate drone deliveries fall to zero under the conservative union mask; in Area B, 726 remain unaffected by this particular mask. Under strict daily cost and service constraints, a finite offline LC-M1 candidate search finds no admissible drone solution and defaults to ground delivery. Separately, an ex-post comparison identifies a hybrid M2 mode in 65 of 150 Area B seed–date cases. The findings show that technical feasibility, operational efficiency, and acceptable carbon reduction require distinct evidence and support conditional rather than unconditional drone deployment recommendations.')
P(abstract)
P('摘要写作核查：以上“29,842”为合成订单数据规模；“1,934/726”为在 30×5 重采样情况下的候选任务累计；“65/150”为后验模式选择而非在线策略成功。为保持篇幅，可在正式稿中删减重复情景解释。')

H('4. Methods · 完整章节提纲与材料清单')
methods=[
('2.1 Study area and decision scope','说明 JB Causeway / Second Link 在马来西亚侧的道路物流背景与边界；A、B 的站点和道路结构。以 F1 对齐，并明确不模拟真实跨境清关。'),
('2.2 Data provenance and synthetic demand','定义29,842订单的生成机制、随机种子20261027起、2026-05-15至2026-09-15五个日期、OD映射、总订单分母；原交通/天气数据的真实来源、原生分辨率、缺失处理。'),
('2.3 Candidate network and reference drones','报告冻结候选站点、可达网络、参考机型 Wingcopter 198 与 DJI FlyCart 30 官方载荷/航程；能耗低中高是工程假设、不是遥测标定。'),
('2.4 Conservative airspace screening','WMP228 两资料版本，圆心及半径2 NM，完整圆域无海岸裁剪；REFERENCE、CAAM、CAAS、UNION四情景，候选航段相交即排除；说明不代表合法许可。'),
('2.5 Operational modes and simulation','定义 M0 / M1 / M2 / SimpleLC / LC-M1；原 Stage6 排队、批次、接驳、B柴油干线、天气回退与车辆资源/成本一致性协议。'),
('2.6 Carbon and cost accounting','将 petrol L、diesel L、grid kWh分别乘各自官方/情景因子；共同路线按增量计；区分运营排放 CO2e 与采购资本日摊/资产假设，不声称生命周期总碳。'),
('2.7 Constraint-based decision assessment','明确30min SLA不低于 M0、完成率不低于 M0、总成本≤1.25×M0；按seed-date配对；LC-M1候选有限子集和M0回退为离线后验基准，不是在线策略。'),
('2.8 Metrics and inferential design','订单完成率=完成/释放，准时率=30min内完成/释放，日级P95=该日完成订单时间的P95；统计以30种子为重采样簇，5日期关联保留；不将每笔订单当成独立重复。'),
('2.9 Reproducibility and QA','报告版本、manifest hashes、重复结果核对、门到门配对、共享柴油干线一次计量、代码入口、输入/运行/结果一致性与未通过项。')]
for t,description in methods:H(t,2);P(description)
H('5. Results · 按 RQ 整理结果，不按运行脚本整理')
res=[
('3.1 RQ1: Demand and network baseline','表T1交代14943(A)/14899(B)种子汇总需求、天气与路网可评价比例；F1标明地理范围，避免“5天是五个月时间序列”的误解。'),
('3.2 RQ1: Airspace sensitivity','F3和T3呈现 A 的 1,934→1,440→0；B 的 726不随WMP遮罩变化。先陈述数值，再指出完整圆域只是一种保守几何代理。'),
('3.3 RQ2: Operational service comparisons','F4按区域及模式展示完成时间、P95与30min服务；配对比较，报告负向结果。初步描述性结果：A区M0平均日级P95约25.33min，W198中央M1约36.60min；B区M0约93.97min，M2约92.43min。'),
('3.4 RQ3: Carbon versus cost','F5/T5将M0与M1、M2、SimpleLC、LC-M1按相同需求对照。A W198中央LC-M1未遮罩排放约10038.5kg，对应M0约11647.2kg，但违反约束且保守空域下不应作为可实施A区方案。'),
('3.5 RQ3: Strict constrained acceptance','F6/T6：LC-M1每个区域/机型/能耗/seed-date组合1800次最终全部回退M0，UAV任务数0；B区M2的150组中另有65组在后验模式选择下被采用，条件性累计节约714.89kg。'),
('3.6 Sensitivities and consistency','M0_MOTO：A累计4367.7kg，B累计11670.5kg，均远低于对应汽车M0，但完全沿用汽车路由时间与资源模型，故仅为燃油强度敏感性而非真实摩托车运营比较。另披露设备能耗、天气释放小时、双空域版本和seed区间；不得把不存在的12配置写成已复算。')]
for t,desc in res:H(t,2);P(desc)
H('6. Discussion / Conclusions 的论证与措辞')
H('4.1 现象机制（证据支持的解释）',2)
P('A 区技术航段更容易落入保守 WMP228 圆域；候选网络的空间邻近性可能放大空域假设对可行覆盖的作用。B 区 M2 有时比地面基线更好，但效益受到共享干线、批次、天气和额外设施成本共同影响。应将这些称为“与仿真机制一致的解释”，而非已实测因果机制。')
H('4.2 为什么负向 LC-M1 结果仍值得发表',2)
P('方法学增量是以硬约束揭露平均减排指标可能掩盖的服务与成本冲突。不能将“所有严格测试均回退 M0”解读为现实无人机永不可减排，因为候选搜索有限、阈值人为预设、机型能耗未标定，而且选择采用了全日后验信息。')
H('4.3 Limitations 必须逐条具体披露',2)
TAB(['缺口','对结论的影响','论文处理'],[
('合成订单、5代表日','外推实际需求强度和季节波动受限','以scenario-based simulation命名；公开生成机制'),
('释放小时天气代理','不能证明实际起飞时点天气合规','承认静态小时级筛查'),
('WMP228完整圆域、无海岸线裁剪','可能高估A区空域排除','保守/分来源敏感性；不声称飞行许可'),
('两个参考机型工程能耗','运营碳结果有系统不确定性','低/中/高敏感性；来源追溯'),
('离线后验模式选择','不可直接部署为在线订单派单算法','明确offline hindsight benchmark'),
('无生命周期制造与退役阶段','不可宣称LCA净减排','统一“operational CO2e”措辞'),
('原12配置清单缺失','不能复述12配置完成','用真实已核验矩阵数量与协议'),
('摩托车采用汽车路网/时间/车队代理','低碳基准排序可能不同、容量不真实','补充M0_MOTO敏感性，严禁写成实地验证')])
H('5. Conclusions 推荐三句话结构',2)
P('第一句 RQ1：JB 两条走廊存在条件性技术候选，但 A 区结论对 WMP228 资料与保守遮罩高度敏感。第二句 RQ2：完整链路性能不呈普遍优势，B 区特定 M2 运行日可满足效率与服务条件。第三句 RQ3：在本研究严格约束与有限候选集下，LC-M1 未得到可接受的无人机策略，而纯地面或特定地空模式可能更适宜；应以场景和约束为依据选择模式。')

H('7. 主文图表体系（逐图承担独立证据任务）')
for code,placement,rq,title,contents,interpret,source,status in specs[:7]:
 H(f'{code} · {title}',2)
 P(f'对应：{rq}。图形设计：{contents}。')
 P(f'支撑：{interpret}。数据：{source}；状态：{status}。')
 P('不可声称：由本图推出真实合法飞行许可、实际商业收益或未经试验的全生命周期减排。')
H('8. 主文表格体系')
TAB(['编号','标题 / 字段','作用与核查点'],[
 ('T1','Data provenance, scenarios and observation units','数据来源、代表日期、种子、原始/有效订单分母'),
 ('T2','Drone, vehicle, fuel, weather and model assumptions','机型官方规格vs工程情景；参数与来源'),
 ('T3','Spatial coverage under alternative airspace masks','A/B × W198/FC30 × WMP四情景；技术候选不等于许可'),
 ('T4','Paired end-to-end operational metrics','M0/M1/M2 × 区域；完成率、均时、P95、30min准时率及配对区间'),
 ('T5','Operational CO2e, cost and service trade-off','统一燃油基线下的总CO2e、成本、差异、是否过硬约束'),
 ('T6','Strict constraint acceptance and conditional mode decision','LC-M1 0 UAV可接受日 vs B区 M2 65/150；后验边界说明')])
P('附录表建议：S-T1 详细机型能耗；S-T2 摩托车代理与 B 区扰动；S-T3 复现检查点及 SHA-256/QA；附录图为工程能耗、天气代理和seed区间。')
H('9. 已有数据生成的图表预览（非最终投稿版）')
P('以下预览根据 SCI Final 当前 CSV 生成，用于图型和证据结构审核。真正投稿图需统一字体、GIS底图许可、统计区间、图例以及期刊图宽；不可直接使用未充分核查的空间示意图作为测量地图。')
FIGURE('preview_F2_research_workflow.png','Fig. 2 Draft — Study workflow, linking RQ1–RQ3.',15.3)
FIGURE('preview_F3_airspace_coverage.png','Fig. 3 Draft — Conservative WMP228 mask sensitivity; conditional synthetic coverage.',15.3)
FIGURE('preview_F4_service_p95.png','Fig. 4 Draft — Per-run P95 comparison (150 seed–date groups per area).',15.3)
FIGURE('preview_F5_carbon_cost.png','Fig. 5 Draft — Carbon–cost ratios; plotted scenarios are not necessarily admissible.',15.3)
FIGURE('preview_F6_mode_choice.png','Fig. 6 Draft — Ex-post admissible-mode choices, not online policy evaluation.',15.3)
FIGURE('preview_SF_motorcycle_proxy.png','Supplementary Figure Draft — Motorcycle petrol intensity sensitivity, not an independent dispatch validation.',15.3)
H('10. 审稿人高风险问题与最后修订原则')
TAB(['可能的审稿质疑','现有回答','不应新增无界实验'],[
 ('“为何不是创新算法？”','贡献是区域决策证据与有界评价协议，非算法新颖性','不引入新的深度强化学习模型'),
 ('“为何空域两版本冲突？”','分别陈列CAAM/CAAS来源版本并做保守并集','无需真实飞行许可'),
 ('“LC-M1为什么没有可行改进？”','硬约束与成本/准时率冲突；明确零UAV为失败结果','不人为放松阈值以求正效应'),
 ('“是什么样的碳边界？”','燃油/柴油/购电运营CO2e，不是生命周期','不添加未标定制造碳'),
 ('“有没有独立重复？”','30需求种子为簇，5日期相关；披露统计范围','不能把626k记录视为626k独立实验'),
 ('“为什么说12配置？”','目前源包不能验证该配置清单','正式稿删除或取得清单后再写'),
 ('“结果能推及真实跨境服务吗？”','不推及；马来西亚侧OD、合成订单、无实际清关','不重建真实订单数据库'),
 ('“摩托车是不是更低碳？”','当前M0_MOTO代理排放更低，但使用汽车路网/队列资源','列为敏感性，不能伪称已公平验证骑手配送')])
H('11. 最终论文编写冻结顺序')
P('按以下顺序形成完整英文稿：先确认T1/T2的输入定义→完成F1真实区域图及F3保守空域图→锁定T4/T5/T6主统计表→写Results→写Methods→写Discussion→写Introduction和Abstract→全文检查每句结论对应图表与QA。该顺序服务于既有实验收束，不延长研究矩阵。')
H('12. References — 核验后纳入的关键起始文献')
refs=[
 'Cui, C.; Li, J. (2026). Strategic Planning for Sustainable Last-Mile Logistics: Balancing Airspace Constraints and Carbon Price Uncertainty in Truck–Drone Delivery. Sustainability, 18(8), 3978. https://doi.org/10.3390/su18083978',
 'Brown, J.R.; Bushuev, M.A. (2024). Last mile delivery with drones: A carbon emissions comparison. International Journal of Sustainable Transportation, 18(9), 791–802. https://doi.org/10.1080/15568318.2024.2407150',
 'Kumar, A.; Prybutok, V.; Sangana, V.K.R. (2025). Environmental Implications of Drone-Based Delivery Systems: A Structured Literature Review. Clean Technologies, 7(1), 24. https://doi.org/10.3390/cleantechnol7010024',
 'Bao, D. et al. (2025). The Future of Last-Mile Delivery: Lifecycle Environmental and Economic Impacts of Drone-Truck Parallel Systems. Drones, 9(1), 54. https://doi.org/10.3390/drones9010054',
 'Decarbonizing last-mile delivery: A life cycle comparison of low-altitude and traditional logistics. (2026). Transportation Research Part D, 152, 105176. https://doi.org/10.1016/j.trd.2025.105176',
 'Sustainability (MDPI) official journal page/stats/APC (accessed 2026-10-28): https://www.mdpi.com/journal/sustainability; https://www.mdpi.com/journal/sustainability/stats; https://www.mdpi.com/journal/sustainability/apc',
 'CAAM ENR 5.1 (2 Dec 2025): https://aip.caam.gov.my/aip/eAIP/2025-12-02/html/eAIP/WM-ENR-5.1-en-MS.html',
 'CAAS ENR 5.1 (12 Jun 2025): https://aim-sg.caas.gov.sg/aim-content/uploads/aip/2025-07-24/final/2025-06-12-Non-AIRAC/html/eAIP/ENR-5.1-en-GB.html'
]
for s in refs:P(s)
# footer page field
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run('SCI manuscript blueprint | Working draft | ');r.font.size=Pt(8);r.font.color.rgb=RGBColor(110,110,110)
f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');footer._p.append(f)
D.core_properties.title='JB低碳无人机物流 SCI 论文初稿定位与图表大纲';D.core_properties.subject='Reproducible scenario-based drone-ground logistics assessment'
out=ROOT/'JB_SCI_初稿定位_完整大纲与图表设计_20261028.docx';D.save(out)
(ROOT/'README.txt').write_text('SCI 投稿定位工作包，2026-10-28\n\n主要文档：JB_SCI_初稿定位_完整大纲与图表设计_20261028.docx\nfigures/ 包含六组CSV派生的300dpi PNG和矢量SVG图表预览。\nfigure_evidence_matrix.csv 可编辑图表—RQ—数据—证据矩阵。\nbuild_blueprint.py 为完全可复算的图表与DOCX生成脚本，需要 pandas, matplotlib, python-docx。\n\ninputs/ 含本次图表所使用的四个既有 SCI_Final CSV 的工作副本；脚本可就地复算图表与DOCX，不是重新运行Stage6引擎。\n此包用于论文定位与图表设计，不是投稿完成稿；图表只展示现有模型假设下的结果。\n',encoding='utf-8')
print('WROTE',out,'size',out.stat().st_size)
