# CIQ 无人机物流 SCI — 全文收束、图表数据与理论依据总控稿

**研究冻结日期**：2026-10-31  
**性质**：研究与写作底稿；不是已完成投稿稿件。作者自行制作正式图件和表格。  
**证据审查**：引用了本次上传的 `CIQ_MINIMAL_EVIDENCE_CHECK_COMPLETE.zip`（SHA-256 `e7dcac180625236c17d6ddc2ff7c4861e0b733539bb2ca69f56111e7765f0c64`，12 个成员、CRC 正常）和此前的 `CIQ_S11B_S12_S13_FINAL_HANDOFF_COMPLETE.zip`，并核查了部分公开理论、技术和监管来源。两者未包含所有外部原始来源与实测许可。

## 0. 全文唯一研究定位（先冻结）

**建议英文标题（工作标题）**：*When Can Truck–Drone Delivery Reduce Operational Emissions? A Weather- and Resource-Constrained Simulation around the Johor Bahru–Singapore Land Border*. 

**研究对象**：Johor Bahru 马来西亚境内、与 Causeway 和 Second Link 相关联的 A/B/C 候选物流网络；并**不是**实际跨境航空货运或通关耗时研究。研究期为 2026-05-01—2026-09-30（153 个日历日）。数据包括 68 个冻结空间候选节点、58 个合成订单参与节点、11 个 M1 条件性站点、历史交通/格点天气代理、82,620 个冻结合成订单、30 个随机种子（4,590 个日期—种子场景）。

**对比对象**：共享三辆汽油地面车辆的 M0 / M1-DJI / M1-WING / M2-DJI / M2-WING；NO-UAV 控制使用一致调度内核。主分析：24 小时运营窗口、距离天气格点中心 >10 km 的任务作严格排除（审计门槛，**不是气象物理限界**），统一事件时钟、返航、SOC 与回仓约束。

**核心贡献（按研究证据顺序）**：① 约束筛查下的空间网络与可执行任务界定；② 同冻结需求和共同调度器的地面、固定站和车载 UAV 模式配对比较；③ 物理路段 / 飞行事件能耗账本和服务约束下的运营 GHG 代理及部分 OPEX；④ 对天气空间代表性、运营时间、能耗与汽油假设的依赖性分析。

**严禁表述**：真实需求代表性已验证；航线/场地已获得批准；Wing 实机 kWh 已标定；汽油 TTW+网电排放系数等于完整 WTW/LCA；M2-Wing 全局最优；模型内统计 CI 是实地因果效应。

## 1. 三个研究问题及实证边界

| RQ | 可以实际回答 | 不允许跨越的证据边界 | 主要证据 |
|---|---|---|---|
| RQ1 Where | V5 条件性候选网络及几何、载荷、天气与能源筛查后的服务范围；不同区域可飞比例 | 68 个候选点不等于 68 个获批场地；不等于真实需求分布 | S07 V5；S09；S12_A `S12_A_V5_68_NODE_REGISTRY.csv`；Fig1/Table1–2 |
| RQ2 When | 在统一合成订单、FCD 与格点天气代理、共同调度器下完成率、全订单准时率、时间分位与回退变化 | 不等于已实测的道路和无人机效率 | S11B `G1_SCENARIO_SUMMARY.csv`、`G2_ORDER_SERVICE_STATUS.parquet`；S12_A 分层；Fig4–5/Table3–5 |
| RQ3 Carbon/cost | 五测试配置的运营排放混合边界代理和部分 OPEX，配对差异与有限参数稳健性；测试集合内非支配 | 不等于 LCA 净减排、完整 TCO 或全局最优 | S11B `G2_PER_SEED_153DAY.csv`；S12_C Pareto；A 模块 13 组；Fig6–7/Table5–7 |

## 2. 主结果冻结数值（每个种子代表一次完整 153 日模拟，30 种子平均）

| mode | 全订单完成率 | 全订单准时率 | 运营混合边界代理 kg / 153 日重复 | 部分 OPEX MYR / 153 日重复 |
|---|---:|---:|---:|---:|
| M0_SHARED_NO_UAV | 95.88% | 91.32% | 14,374.73 | 171,022.12 |
| M1_DJI | 96.02% | 91.42% | 14,396.97 | 171,283.87 |
| M1_WING | 96.01% | 91.46% | 14,324.89 | 171,100.89 |
| M2_DJI | 95.89% | 91.40% | 14,124.21 | 170,882.62 |
| M2_WING | 95.91% | 91.47% | 13,870.97 | 170,445.81 |

完整主实验 M2-Wing 相对 M0 减少 **3.50%** 运营 GHG 代理；该数为条件性模型输出。M1-DJI 代理排放增加，不可概括为“四种 UAV 均减排”。本表来自历史 S11B/S13，必须在最终排版前逐项绑定 S11B 主 CSV。

**新增模块 A（独立呈现为参数稳健性，不与主实验混算）**：900 个按月份及压力分层选定的日期—种子场景 × 13 组参数 × 5 模式 = **58,500** 条场景级记录。子集基准 M2-Wing 相对 M0 下降 **3.527%**，日期/种子双向聚类 Bootstrap 95% CI 下限为 **2.988%**、上限为 **4.087%**；13 组下降范围为 **2.416%–4.341%**，这些测试组合内未出现最低排放模式排名反转。不得将此结论推广到所有可能的气候、车型和实机能源参数。

**模块 B 的需求来源限制**：每个日期—种子场景固定 18 单，三区各 6 单；每区 5 单区内、1 单跨区压力情景；重量集合 0.5/1/2.5/4.5/5/8 kg；截止时窗 45/90/150 min；目的地在允许候选中均匀抽取；无企业真实订单实证校准。30 个种子不等于 30 份真实独立物流调查。

## 3. 全文结构与每节必须写清的理论依据

### Introduction（建议 4 段）
1. CIQ 周边物流面临地理、道路交通和气象交互约束，明确研究为 JB 境内 CIQ 关联的物流情景，不把边境通关纳入模型。
2. Truck–drone routing 从传统 vehicle routing / FSTSP 扩展至站点与车载协同，多数理论模型需要权衡任务同步、载重、能量、时窗及返航。
3. 气象可飞性与能源账本、共同调度器、公平对照和混合边界排放代理需要统一，不能把“飞得了”当成“减碳了”。
4. 介绍 RQ1–3、四个方法贡献和对“条件性仿真”的限定。

### Related work / theoretical background（建议 4 节）
2.1 时间依赖车辆路径与 truck–drone 配送：引用 Murray & Chu (2015)，近年 truck–drone review。明确 M1 固定站与 M2 同点回收架构，不混为同一种 FSTSP。
2.2 载荷—能量—气象耦合：引用 2023 风能量论文和 2024 含能耗/时窗 truck–drone routing；机型 OEM 规格仅提供产品范围，不提供全部任务能耗曲线。
2.3 合成需求驱动的受控仿真：可引用 Lyon 2023 合成包裹需求方法作一般方法论动机，但不得说其验证了本项目 JB 订单分布。
2.4 运营排放、系统边界和监管限制：汽油 TTW CO2、网电因子 0.740（2024 临时马来半岛 GEF，用于 2026 的情景代理）、未计资本和全生命周期；CAAM SUP/BVLOS 为潜在监管要求而非许可证明。

### Methods（这是全文的理论核心，应从代码写成可复现方法，而非仅 3 段概述）
3.1 研究边界与空间网络：A/B/C、68 节点、58 活跃订单节点、11 站白名单、OSM 有向路网、候选线和参考 WMP228，列图层坐标系、空间筛选与 HOLD。
3.2 数据来源与时空融合：2026 年 5–9 月逐小时天气与 FCD、345 个 FCD 节点、3,672 小时；FCD 无方向观测；天气格点 >10 km 的审计处置；当地/UTC 时间转换规则。
3.3 合成订单生成：153 日×30 种子×18 单；三区均衡、区内/跨区配比、时间窗/重量、抽样规则、冻结 SHA；说明样本是设计场景非需求预测。
3.4 运营模式及公平控制：M0 纯汽油车；M1 11 固定点；M2 三车三机的车载发射同点回收；相同三车、同一订单、共同地面调度内核、NO-UAV 对照及 fallback 机制。
3.5 事件时钟、动态天气、航程与电池 SOC：release、出发、取货、实际 launch、delivery、return-launch、recovery、vehicle return；飞行四事件天气检查、SOC 能量守恒、最小储备、充/换电及资源排他。必须与实际代码保持严格同义。
3.6 时间依赖地面路网：FCD 时段速度代理的逐边时间计算、小时缓存与精确时刻校验；不把 FCD 无方向代理当作实测有向交通。
3.7 物理运营能量及部分成本：共享行程一次计费、燃油与电量分账、成本分账、系统边界。参见公式框架。
3.8 实验与统计：主运行 4,590 个日期—种子场景、30 个 153 日重复；严格 10 km、24 小时、5 模式；服务门槛 95% 完成与 90% 准时；日期/种子关联、配对种子 Bootstrap；13×900 联合参数压力实验为独立补充证据。
3.9 非支配分析：仅对预先测试的可行配置，用完成率/准时率作约束，成本—排放—时间作优化目标；定义和执行代码一致；不声称全局求解。

### Results（推荐 6 段）
4.1 区域空间可达性与条件性网络；4.2 天气、FCD 与任务可飞时窗；4.3 任务分配与服务表现；4.4 能源、排放代理和部分 OPEX；4.5 13 组联合敏感性与需求审计；4.6 服务约束下的受测方案 Pareto。

### Discussion（推荐 4 段）
5.1 M2 模式仅在当前严格模型内表现最优，何种模型假设能改变排名；5.2 3.50% 运营代理与约 0.34% 部分 OPEX 改善的实际幅度与资本成本风险；5.3 天气代表性、同步等待、能源与调度公平性的机制性解释；5.4 外部效度、合规、地面真实交通、需求权重、Wing 未标定能耗、边界不对称性。

### Conclusions（建议 1 个实证主结论 + 1 个条件句 + 1 个证据限制段）
严格情景下，在冻结受控需求和测试配置内 M2-Wing 的运营代理较 M0 下降 3.50%；有限联合参数网格内 900 场景的结果未反转。说明仅为条件性运营比较；未经验证的实际飞行、LCA、完整 TCO 与批准不能推论。

## 4. Methods 中应出现的数学定义（概念表达；必须按运行代码校对）

**合成需求**：\(\mathcal{O}_{d,s}=\{o_1,\ldots,o_{18}\}\)，\(d\in\{1,\ldots,153\},\;s\in\{1,\ldots,30\}\)。相同订单同时输入每一个模式。\(w_o\)、\(r_o\)、\(\delta_o\) 分别表示包裹重量、发布时间和相对承诺时窗。

**全订单服务率**：\(R_{\mathrm{complete}}=N_{\mathrm{completed}}/N_{\mathrm{all}}\)，\(R_{\mathrm{ontime}}=N_{\mathrm{completed\ ontime}}/N_{\mathrm{all}}\)。未服务订单必须留在分母；“完成订单平均配送时间”另定义，避免分母混用。

**车辆边时间**：\(T_{ij}^{\mathrm{road}}(t)=L_{ij}/v_{ij}(t)\)（单位换算、缺测回退、路径缓存必须依代码）。不能把可用车速观测称为有向实测速度。

**电池守恒与可飞性**：\(SOC_{k,t+1}=SOC_{k,t}-E_{k,m}+E_{k,\mathrm{charge}}\)，每次发射满足剩余 SOC 下界和资源互斥；\(E_{k,m}\) 是项目假设的任务能耗函数，不代表 Wing OEM 标定值。

**运营混合边界代理**：\(G_m=\sum_{\ell\in\mathcal{L}_m}F_{\ell}\,EF_{\mathrm{petrol,TTW}}+E^{\mathrm{grid}}_m EF_{\mathrm{grid}}\)。冻结参数：\(F_{\ell}=0.1\,\mathrm{L/km}\times L_\ell\)；\(EF_{\mathrm{petrol,TTW}}=2.2410927\,\mathrm{kg\ CO_2/L}\)；\(EF_{\mathrm{grid}}=0.740\,\mathrm{kg\ CO_2e/kWh}\)。它是**混合边界代理**，不应将两项合计解释成一致的 WTW 或完整生命周期 CO2e。

**相对变化**：\(\Delta G_m(\%)=100(G_m-G_0)/G_0\)。负号表示减少；中文“减少 3.50%”可用正向降幅 \(100(G_0-G_m)/G_0\)，全文选择一个符号惯例。

**部分 OPEX**：\(C_m=C_{\mathrm{petrol}}+C_{\mathrm{grid}}+C_{\mathrm{ground\ maintenance}}+C_{\mathrm{driver\ time}}+C_{\mathrm{UAV\ operator}}+\text{其他确实计入的运营项}\)。不得添加代码未计算的资本折旧到已发表成本总值。

**服务约束**：\(R_{\mathrm{complete}}\geq0.95\)，\(R_{\mathrm{ontime}}\geq0.90\)。非支配性仅在受测服务可行配置和明确的目标向量上求得。

## 5. Fig.1–7 建议最终版定义（作者自行绘图）

| Fig. | 论文必须传达的科学信息 | 从何取数 | 制作/科学审核边界 |
|---|---|---|---|
| 1 Study area and frozen V5 network | (a) JB/CIQ 地理背景；(b) A 区；(c) B/C 展开或分区总图；68 候选节点、11 条件性 M1 点与连接；国界、岸线、比例尺/指南针 | V5 原 GPKG + `S13_PAPER_RESULTS/figures/Fig1_source.csv`；S12_A 节点表 | Fig1_source 只是节点点位表，**不能替代 QGIS 官方底图/权威边界核验**；不把点位绘入新加坡 |
| 2 Research framework | 冻结输入 → 空域与天气资格 → 同任务五模式调度 → SOC/资源 → 物理能耗及成本 → 30 种子分析 | `Fig2_source.csv`、Methods 代码 | 与实际执行顺序一致，避免将 HOLD 写作 PASS |
| 3 UAV technologies and operating conditions | DJI FlyCart 30/Wingcopter 198 Cargo 的载荷、航程、风阈及项目能耗情景；11 M1 站、M2 同点回收示意 | 项目 `PARAMS.yaml`；本轮 `PARAMETER_AND_SOURCE_AUDIT.csv`；OEM 官方页面 | 必须区分 Wing **198 Cargo** 公开上界与 3 kWh 未标定假设；旧 `Fig3_source.csv` 主要为月度任务/天气，适合转到 Fig4 |
| 4 Historical road/weather operating windows | 5–9 月速度、雨、风与严格/放宽天气筛查的变化及其对任务可飞数的影响 | `Fig3_source.csv`；S07 小时天气/FCD；S12_A 与 S12_B | 月均值不能替代每任务时刻天气；旧 Fig4 模型修订比较可移 SI |
| 5 Assignment and service | M0/M1/M2 UAV 数、回退、未完成，完成/准时率、P50/P90/P95（若原始结果存在） | `Fig5_source.csv`，G1 订单/场景级，S12_A 分层 | 不能把只完成订单的准时率冒充全订单准时率 |
| 6 Operational GHG proxy and partial OPEX | 各模式 153 日平均排放代理和成本；与共享 M0 的配对变化及 CI；标注混合边界 | `Fig6_source.csv`，`G2_PER_SEED_153DAY.csv`，Table 5–6 | 坚持每种子五个月平均，不能将30次累加当作一年或5个月实况 |
| 7 Conditional robustness and service-constrained Pareto | 受测五配置非支配；13 联合参数热力/条形与效应 CI 可作为子图或 SI | `Fig7_source.csv`；`S12_C_SERVICE_CONSTRAINED_PARETO.csv`；本轮 `JOINT_SENSITIVITY_SUMMARY.csv` | 必须标注 900 分层子集、13 参数组合，不得画成全局最优可行域 |

> **主文篇幅建议**：Fig1–2 研究设定、Fig3–4 模型与条件、Fig5–7 结果；如果图幅或期刊限制严格，Fig4 的历史模型修订对比移 Supplementary Figure，不必强迫所有内容进主文。

## 6. Table 1–7 数据锁定与主文/补充材料分工

| Table | 主要内容 | 证据入口 | 推荐位置 |
|---|---|---|---|
| 1 Sources and evidence grades | V5、OSM、FCD、ERA5、订单、UAV 规格、燃料、电网因子、监管状态 | S13 `Table1...csv` + 本轮 `PARAMETER_AND_SOURCE_AUDIT.csv` | 主文压缩版；逐 SHA 扩展到 SI |
| 2 Operating/model parameters | 3 车、11 M1 点、M2 资源、任务载荷/时间窗、严格10km、SOC、机型能耗假设 | S13 `Table2...csv`、S11B `PARAMS.yaml`、订单审计 | 主文 |
| 3 Five-mode main performance | 五模式完成率、全订单准时率、平均时间、里程、飞行数、排放代理与部分 OPEX | S13 `Table3...csv`、`G2_PER_SEED_153DAY.csv` | 主文 |
| 4 Stratified effects | A/B/C、5 个月、天气与订单分层；严格与宽松对照 | S13 `Table4...csv`、S12_A | 建议 SI，主文概述关键分区差异 |
| 5 Paired estimates and uncertainty | M1/M2 vs 共享控制的效应、95% CI，统计单元与分母 | S13 `Table5...csv`；本轮 13 组汇总 | 主文 |
| 6 Cost and carbon boundaries / break-even | 各成本组成、五个月每次重复、可容纳的资本增量、变量来源 | S13 `Table6...csv`；S11B `G2_BREAK_EVEN_CORRECTED.csv` | 主文精简；成本细目 SI |
| 7 Sensitivity and tested Pareto | 历史严格/放宽、运行窗口 8/12/30h 子集，以及本轮 13×900 联合敏感性；可行性与非支配性 | S13 `Table7...csv`、S12_B/C、本轮 `JOINT_SENSITIVITY_SUMMARY.csv` | 主文核心摘要 + SI 完整表 |

## 7. 可追溯的理论与参数来源（首批核验；不是完整参考文献库）

1. **Murray, C. C. & Chu, A. G. (2015)**. *The flying sidekick traveling salesman problem: Optimization of drone-assisted parcel delivery*. Transportation Research Part C 54, 86–109. DOI: https://doi.org/10.1016/j.trc.2015.03.005 — 支撑车—机协同问题基础，不证明本项目移动同点回收最优。
2. **Approaches to the truck-drone routing problem: A systematic review (2024)**. DOI: https://doi.org/10.1016/j.swevo.2024.101825 — 支撑模型分类和研究空白，最终应核作者和条目元数据。
3. **Chen et al. (2026)**. *Truck-drone collaborative routing optimization: a unified framework and systematic review*. Transportation Research Part E. DOI: https://doi.org/10.1016/j.tre.2026.105096 — 最新综述支持理论背景；引用前核对正式卷期。
4. **Betti Sorbelli et al. (2023)**. *How the Wind Can Be Leveraged for Saving Energy in a Truck-Drone Delivery System*. IEEE TITS. DOI: https://doi.org/10.1109/TITS.2023.3234627 — 风与能源耦合的动机，**不代表本项目已标定风致电耗**。
5. **Cooperated Truck-Drone Routing With Drone Energy Consumption and Time Windows (2024)**. IEEE TITS. DOI: https://doi.org/10.1109/TITS.2024.3478175 — 载重、能耗和时窗模型背景。
6. **From synthetic population to parcel demand: A modeling pipeline and case study for last-mile deliveries in Lyon (2023)**. Transportation Research Procedia. DOI: https://doi.org/10.1016/j.trpro.2023.11.644 — 只支持合成需求方法论，不是 JB 的实测订单权重依据。
7. **Hersbach et al. (2020)**. *The ERA5 global reanalysis*. QJRMS. DOI: https://doi.org/10.1002/qj.3803 — 格点气象数据的技术来源。
8. **DJI FlyCart 30 官方规格**: https://www.dji.com/flycart-30/specs — DJI DB2000 每块 1984.4 Wh，两块名义 3968.8 Wh，规格测量多在理想试验条件下；任务级耗电仍需情景化。
9. **Wingcopter 198 Cargo 官方规格**: https://wsd.wingcopter.com/w198-cargo — 4.7 kg 载荷、最高 92 km、风阻最高 18 m/s；**没有从该页面核到项目 3.0 kWh 的实测电池证据**。
10. **Malaysia Energy Commission (2022–2024 provisional GEF)**: https://myenergystats.st.gov.my/documents/d/guest/grid-emission-factor-gef-in-malaysia-2022-2024-provisional- — 2024 Peninsular 0.740 kg CO2e/kWh；是 2026 实验的历史因子代理。
11. **CAAM UAS 官方说明**: https://www.caam.gov.my/public/unmanned-aircraft-system-uas/ — SUP、BVLOS、载物/特殊任务监管要求；不表示模拟航线获批。

**参考文献质量门槛**：逐篇核 DOI、题名、作者、出版年份；区分同篇综述与不同论文；不要为每句方法公式强行挂无关引用。所有 OEM 官网为参数来源，不计作独立同行评审理论文献。

## 8. 投稿前最后的「只检查、不新增实验」清单

- [ ] 全文只用 S11B 修订版五模式数据；S08、S10、S11 旧结果只作为模型演进审计或 SI，不与主文混算。
- [ ] Fig./Table 每个数值可回溯到 CSV 列、文件 SHA、统计单位及实验情景。
- [ ] 主文 4,590 场景 × 5 模式、30 个 153 日重复，与 900 场景 × 13 参数组合分开报告。
- [ ] `G0–G7 PASS_CONDITIONAL` 不写成 external/field validated。
- [ ] 每张结果表明确全订单分母、排放边界、成本边界、时间单位及 95% CI 方法。
- [ ] RQ1 的 68/58/11 节点、A/B/C 三区描述一致；制图采用原生 QGIS 与有授权地理数据。
- [ ] 合成订单均匀/均衡的限制清楚写入 Methods/Limitations。
- [ ] 13 组参数未反转只解释为有限区间内的稳健性，不能推断 Wing 的 OEM 能耗准确。
- [ ] 论文写成“CIQ 邻近的马来西亚境内条件性物流仿真”，而非已完成跨境配送。
- [ ] 实际站点、CAAM/SUP、成本资本项、完整 LCA、真实物流订单等继续 HOLD。

## 9. 完成顺序（全部是写作与核对，不新增实验）

1. **冻结图表数字/来源与名词词典**（先审计全文唯一数字）；
2. **写 Methods 正式长稿**，对应每个已运行模块的理论定义、公式、参数表和条件假设；
3. **写 Results 正式长稿**，按 RQ1→RQ2→RQ3，结果只来自冻结 CSV；
4. **写 Discussion**，解释效应量与边界，强调 13 组稳健性只是有限网格；
5. **作者根据图表源表自行正式绘图**，再逐图与正文复核；
6. **补完整 Introduction / literature、Abstract、Conclusions 和 SI、参考文献、数据可用性声明**；
7. **最终交叉审计**：文字数字 = 统计表 = Figure/Table = 程序输出；通过后才称“投稿稿件冻结”。
