# Public sources only (2026-10-27)

- Crossref public REST API: https://www.crossref.org/documentation/retrieve-metadata/rest-api/access-and-authentication/ — no signup/key, limits requests per second. Publisher DOI bibliographic identity and available metadata abstracts may be used in evidence records.
- Semantic Scholar public API: https://www.semanticscholar.org/product/api — publicly accessible endpoints without keys, shared unauthenticated rate limits; OA-PDF links and abstract if returned. If 429, back off; do not create an API key.
- Public publisher PDFs, author repositories (UTM ePrints, accepted-manuscript repositories), federal transport archives and official report pages. A paid PDF, publisher preview, DOI redirect or HTML page does not qualify as a local PDF.
- Do not use OpenAlex, Unpaywall, any paid research connector or daily-credit quota provider. Free public endpoints can throttle; this is not infinite bandwidth. Unpaywall's 100k requests/day limit is not needed for 34 entries.

Acquisition order: direct exact-work PDF hint → Crossref DOI/author/year/abstract → Semantic Scholar openAccessPdf if available → legally free publisher PDF patterns → verified public institutional or government copy. For unresolved entries, metadata/abstract can still justify retaining a bibliographic reference; distinguish evidence level.
