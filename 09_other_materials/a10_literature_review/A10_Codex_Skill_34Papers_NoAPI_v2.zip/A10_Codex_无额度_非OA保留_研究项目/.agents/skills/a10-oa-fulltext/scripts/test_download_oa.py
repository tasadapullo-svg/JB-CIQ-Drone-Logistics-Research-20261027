"""Offline unit tests for metadata identity, candidate selection and API-key hygiene."""
import importlib.util
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import hashlib
import zipfile
import unittest
from unittest.mock import patch

CODE = Path(__file__).with_name('download_oa.py')
spec = importlib.util.spec_from_file_location('a10_downloader', CODE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class FakeClient:
    def json(self, url):
        if 'crossref.org' in url:
            return {'message': {'title': ['Machine learning methods for commercial vehicle wait time prediction at a border crossing'],
                                'DOI': '10.1016/j.retrec.2021.101034', 'publisher': 'Elsevier',
                                'author':[{'given':'A', 'family':'Researcher'}],
                                'abstract':'<jats:p>Traffic wait time modeling.</jats:p>'}}
        if 'semanticscholar' in url:
            return {'title': 'Machine learning methods for commercial vehicle wait time prediction at a border crossing',
                    'isOpenAccess': False, 'openAccessPdf': {'url': 'https://university.edu/repository/accepted.pdf'}}
        return {}


class TestOA(unittest.TestCase):
    def test_title_matching(self):
        self.assertGreater(mod.similarity('Traffic forecast using LSTM', 'Traffic forecast: using LSTM!'), 0.95)
        self.assertLess(mod.similarity('Transport delays at a checkpoint', 'New economy of marine traffic'), 0.75)

    def test_source_recovery(self):
        r = {'title': 'Machine learning methods for commercial vehicle wait time prediction at a border crossing',
             'doi': '10.1016/j.retrec.2021.101034', 'source_url': 'https://doi.org/10.1016/j.retrec.2021.101034',
             'fulltext_hint_url': ''}
        candidates, metadata, errors, mismatch = mod.collect(FakeClient(), r)
        self.assertFalse(mismatch)
        self.assertEqual(metadata['crossref_doi'], r['doi'])
        self.assertEqual(metadata['crossref_abstract'],'Traffic wait time modeling.')
        self.assertIn('https://university.edu/repository/accepted.pdf', [x['url'] for x in candidates])

    def test_report_doi_placeholder(self):
        self.assertFalse(mod.valid_doi('无 DOI（报告）'))
        self.assertTrue(mod.valid_doi('10.1016/j.trc.2013.11.018'))

    def test_url_secret_redaction(self):
        target = mod.safe_public_url('https://content.openalex.org/works/W123.pdf?api_key=SECRET&email=user%40example.org&source=oa')
        self.assertNotIn('SECRET', target)
        self.assertNotIn('example.org', target)
        self.assertIn('source=oa', target)

    def test_pdf_url_rules(self):
        self.assertTrue(mod.likely_pdf('https://eprints.utm.my/file.pdf'))
        self.assertFalse(mod.likely_pdf('https://doi.org/10.3390/machines10100937'))
        self.assertFalse(mod.url_ok('http://example.org/a.pdf'))

    def test_end_to_end_offline(self):
        manifest = (CODE.parents[4] / 'catalog_34.json').read_text(encoding='utf-8')
        with tempfile.TemporaryDirectory() as t:
            root = Path(t)
            (root/'catalog_34.json').write_text(manifest, encoding='utf-8')
            payload = b"%PDF-1.4\n" + b"x"*2000 + b"\n%%EOF\n"
            def stub_download(self, url, path):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(payload)
                return hashlib.sha256(payload).hexdigest(), len(payload), url
            def stub_collect(client, record):
                return ([{'url': 'https://example.org/one.pdf', 'source': 'oa-test', 'version': 'acceptedVersion', 'license': 'cc-by'}], {}, [], False)
            args = SimpleNamespace(project=str(root), timeout=1, delay=0,
                                   ids=[1], force=False, supplements=False, supplement_limit=1, no_preflight=True)
            with patch.object(mod, 'collect', side_effect=stub_collect), patch.object(mod.Client,'download_pdf', new=stub_download), patch.object(mod, 'extract_pdf', return_value=('not_installed',None,'')):
                mod.run(args)
            status = json.loads((root/'output'/'STATUS_34.json').read_text(encoding='utf-8'))
            self.assertEqual(len(status), 34)
            self.assertEqual(status[0]['status'], 'DOWNLOADED_NEEDS_QA')
            self.assertEqual(status[1]['status'], 'NOT_RUN')
            self.assertTrue((root/'output'/'EVIDENCE_MATRIX_34.csv').is_file())
            with (root/'output'/'CITATION_AUDIT_34.csv').open(encoding='utf-8-sig') as fp:
                self.assertEqual(len(list(__import__('csv').DictReader(fp))),34)
            self.assertTrue((root/'output'/'A10_核心34篇_含非OA.bib').is_file())
            with zipfile.ZipFile(root/'output'/'PDF_34_Core.zip') as z:
                self.assertEqual(z.namelist(),['A10_01.pdf'])

    def test_non_oa_citable_from_abstract(self):
        with tempfile.TemporaryDirectory() as t:
            out = Path(t)
            records = [{'id':1,'title':'Study of border travel', 'doi':'10.1234/example',
                        'year':'2020', 'doi_url':'https://doi.org/10.1234/example',
                        'status':'NO_FREE_PDF_FOUND', 'metadata_status':'VERIFIED',
                        'abstract_text':'Border travel methods are investigated.', 'abstract_source':'Crossref',
                        'journal':'Test Transportation', 'authors':'Researcher, A'}]
            mod.create_reference_outputs(out, records)
            with (out/'CITATION_AUDIT_34.csv').open(encoding='utf-8-sig') as fp:
                ledger = list(__import__('csv').DictReader(fp))
            self.assertEqual(ledger[0]['citation_evidence_level'],'ABSTRACT_ONLY')
            self.assertEqual(ledger[0]['access_status'],'NOT_LOCATED_OR_ACCESS_RESTRICTED')
            self.assertIn('@article{A10_01', (out/'A10_核心34篇_含非OA.bib').read_text())

    def test_no_metered_api_identifiers_in_source(self):
        source = CODE.read_text(encoding='utf-8')
        self.assertNotIn('api.openalex.org', source)
        self.assertNotIn('api.unpaywall.org', source)
        self.assertNotIn('OPENALEX_API_KEY', source)

    def test_fixed_records(self):
        records = json.loads((CODE.parents[4] / 'catalog_34.json').read_text(encoding='utf-8'))
        self.assertEqual(len(records),34)
        self.assertEqual(sum(bool(x['doi']) for x in records),31)
        self.assertEqual([x['id'] for x in records],list(range(1,35)))


if __name__ == '__main__':
    unittest.main()
