#!/usr/bin/env python3
"""A10: OA full-text acquisition, immutable 34-record core and documented failures.

No paywall bypass, CAPTCHA automation, Sci-Hub/LibGen, or guessed matches.
Stdlib-only for harvesting; optional pypdf for page count/text extraction.
"""
import argparse
import csv
import html
import difflib
import hashlib
import json
import os
import re
import shutil
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlparse, urlsplit, urlunsplit, parse_qsl
from urllib.request import Request, build_opener, HTTPRedirectHandler

AGENT = "A10-Open-References/2.0 (non-commercial academic research; no API key)"
CATEGORIES = {
    "A": "Johor Singapore border crossing congestion prediction",
    "B": "international border crossing wait time forecasting",
    "C": "multisource traffic travel time prediction data fusion",
    "D": "spatiotemporal traffic forecasting systematic survey",
    "E": "Johor Bahru Singapore cross border public transport mobility",
    "F": "border crossing traffic prediction queue control",
    "G": "border crossing delay measurement traffic technical report",
}


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def normalize_title(s):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", (s or "").lower())).strip()


def similarity(a, b):
    a, b = normalize_title(a), normalize_title(b)
    if not a or not b:
        return 0.0
    ratio = difflib.SequenceMatcher(None, a, b).ratio()
    aa, bb = set(a.split()), set(b.split())
    overlap = len(aa & bb) / max(len(aa | bb), 1)
    return round(max(ratio, 0.7 * ratio + 0.3 * overlap), 3)


def valid_doi(s):
    return bool(re.fullmatch(r"10\.\d{4,9}/\S+", s or "", flags=re.I))


def url_ok(url):
    try:
        p = urlparse(url)
        return p.scheme == "https" and bool(p.netloc) and not p.username and not p.password
    except Exception:
        return False


def likely_pdf(url):
    if not url_ok(url):
        return False
    p = urlparse(url)
    path = p.path.lower()
    return (path.endswith(".pdf") or "/pdf/" in path or path.endswith("/pdf") or
            "downloadpdf" in path or "pdf=1" in p.query.lower() or "format=pdf" in p.query.lower())


class Client:
    def __init__(self, timeout=22, delay=0.6):
        self.timeout, self.delay = timeout, delay
        self.last = 0.0
        self.opener = build_opener(HTTPRedirectHandler())

    def _open(self, url, *, accept="application/json"):
        if not url_ok(url):
            raise ValueError("HTTPS URL missing/invalid")
        pause = self.delay - (time.monotonic() - self.last)
        if pause > 0:
            time.sleep(pause)
        self.last = time.monotonic()
        return self.opener.open(Request(url, headers={"User-Agent": AGENT, "Accept": accept}), timeout=self.timeout)

    def json(self, url):
        for attempt in range(3):
            try:
                with self._open(url) as response:
                    body = response.read(6_000_000)
                return json.loads(body.decode("utf-8"))
            except HTTPError as e:
                if e.code in (429, 500, 502, 503, 504) and attempt < 2:
                    # Back off instead of seeking a registered quota/paid key.
                    time.sleep((2.5, 7.0)[attempt])
                    continue
                raise
        return {}

    def download_pdf(self, url, target, max_bytes=60_000_000):
        target.parent.mkdir(parents=True, exist_ok=True)
        part = target.with_name(target.name + ".part")
        try:
            with self._open(url, accept="application/pdf,application/octet-stream;q=0.9,*/*;q=0.2") as response:
                resolved = response.url
                if not url_ok(resolved):
                    raise RuntimeError("redirected outside HTTPS")
                length = response.headers.get("Content-Length")
                if length and length.isdigit() and int(length) > max_bytes:
                    raise RuntimeError("pdf exceeds size limit")
                total = 0
                with part.open("wb") as fp:
                    while True:
                        chunk = response.read(65536)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > max_bytes:
                            raise RuntimeError("pdf exceeds size limit")
                        fp.write(chunk)
            with part.open("rb") as fp:
                head = fp.read(1024)
                if b"%PDF-" not in head:
                    raise ValueError("response is not a PDF (HTML/login/other)")
                if total < 1800:
                    raise ValueError("PDF unexpectedly small")
                fp.seek(max(0, total - 4096))
                if b"%%EOF" not in fp.read():
                    raise ValueError("incomplete PDF (no EOF marker)")
            os.replace(part, target)
            h = hashlib.sha256()
            with target.open("rb") as fp:
                for chunk in iter(lambda: fp.read(1 << 18), b""):
                    h.update(chunk)
            return h.hexdigest(), total, resolved
        finally:
            if part.exists():
                part.unlink()


def api(client, url, errors, label):
    try:
        return client.json(url)
    except Exception as exc:
        errors.append(f"{label}: {type(exc).__name__}: {str(exc)[:140]}")
        return {}


def add_candidate(candidates, url, source, version="unknown", license_value="", host="unknown"):
    if not url_ok(url):
        return
    canonical = url.split("#")[0]
    if canonical not in {x["url"] for x in candidates}:
        candidates.append({"url": canonical, "source": source, "version": version,
                           "license": license_value or "unknown", "host": host})


def safe_public_url(url):
    """Never write private API keys/email into logs, CSV, or trace files."""
    try:
        parts = urlsplit(url)
        pairs = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True)
                 if k.lower() not in ("api_key", "apikey", "key", "email", "access_token")]
        return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(pairs), ""))
    except Exception:
        return "<invalid URL>"


def host_name(s):
    return urlparse(s).hostname or ""


def oa_locations(candidates, locations, source):
    for loc in locations or []:
        if not isinstance(loc, dict):
            continue
        url = loc.get("pdf_url") or loc.get("url_for_pdf")
        if url:
            add_candidate(candidates, url, source, loc.get("version") or "unknown",
                          loc.get("license") or "", loc.get("landing_page_url") or loc.get("url") or "")


def publisher_patterns(doi):
    d = quote(doi, safe="/")
    patterns = []
    if doi.startswith("10.3390/"):
        # DOI alone does not reliably map to an MDPI PDF path. OA index preferred.
        pass
    elif doi.startswith("10.1088/"):
        patterns.append(f"https://iopscience.iop.org/article/{d}/pdf")
    elif doi.startswith("10.1177/"):
        patterns.append(f"https://journals.sagepub.com/doi/pdf/{d}")
    elif doi.startswith("10.1007/"):
        patterns.append(f"https://link.springer.com/content/pdf/{d}.pdf")
    elif doi.startswith("10.1080/"):
        patterns.append(f"https://www.tandfonline.com/doi/pdf/{d}")
    return patterns


def clean_abstract(value):
    """Extract plain text only for internal evidence auditing; never invent absent abstracts."""
    cleaned = html.unescape(re.sub(r"<[^>]*>", " ", value or ""))
    return re.sub(r"\s+", " ", cleaned).strip()


def collect(client, record):
    """Only public, keyless, no-account endpoints. No OpenAlex or Unpaywall calls."""
    doi, title = record["doi"], record["title"]
    errors, candidates, metadata = [], [], {}
    for name in ("fulltext_hint_url", "source_url"):
        u = record.get(name, "")
        if likely_pdf(u):
            add_candidate(candidates, u, "catalog:" + name, host=host_name(u))
    # Public DOI registry, free and without registration. Observe server request limits.
    if doi:
        cr = api(client, "https://api.crossref.org/works/" + quote(doi, safe="/"), errors, "Crossref")
        msg = cr.get("message") or {}
        metadata["crossref_title"] = (msg.get("title") or [""])[0]
        metadata["crossref_doi"] = msg.get("DOI") or ""
        metadata["crossref_publisher"] = msg.get("publisher") or ""
        metadata["crossref_journal"] = (msg.get("container-title") or [""])[0]
        metadata["crossref_year"] = ((msg.get("published") or {}).get("date-parts") or [[None]])[0][0]
        metadata["crossref_authors"] = [{"given": a.get("given", ""), "family": a.get("family", ""), "name": a.get("name", "")}
                                         for a in (msg.get("author") or [])]
        metadata["crossref_abstract"] = clean_abstract(msg.get("abstract") or "")
        metadata["crossref_url"] = msg.get("URL") or ""
        metadata["crossref_similarity"] = similarity(title, metadata["crossref_title"])
        metadata["doi_match"] = not metadata["crossref_doi"] or metadata["crossref_doi"].lower() == doi.lower()
        for link in msg.get("link") or []:
            if "pdf" in (link.get("content-type") or "").lower():
                add_candidate(candidates, link.get("URL"), "crossref:publisher_pdf", "publishedVersion")
        # A no-key, public research index. It might return 429; treat that as provider throttling.
        s2 = "https://api.semanticscholar.org/graph/v1/paper/DOI:" + quote(doi, safe="/")
        s2 += "?" + urlencode({"fields": "title,year,abstract,externalIds,openAccessPdf,url,isOpenAccess"})
        sem = api(client, s2, errors, "SemanticScholar")
        if sem.get("title"):
            metadata["s2_title"] = sem.get("title")
            metadata["s2_similarity"] = similarity(title, sem.get("title"))
        if isinstance(sem.get("isOpenAccess"), bool):
            metadata["s2_isOpenAccess"] = sem["isOpenAccess"]
        metadata["s2_abstract"] = clean_abstract(sem.get("abstract") or "")
        loc = sem.get("openAccessPdf") or {}
        if loc.get("url"):
            add_candidate(candidates, loc["url"], "semanticscholar:openAccessPdf", host=host_name(loc["url"]))
        for u in publisher_patterns(doi):
            add_candidate(candidates, u, "publisher:probable_pdf", "publishedVersion")
    # Legitimate publisher PDF pattern when supplied source is an MDPI article URL.
    landing = record.get("source_url", "")
    if host_name(landing) in ("www.mdpi.com", "mdpi.com") and not likely_pdf(landing):
        add_candidate(candidates, landing.rstrip("/") + "/pdf", "publisher:mdpi_pdf", "publishedVersion")
    score = metadata.get("crossref_similarity")
    mismatch = bool(score is not None and metadata.get("crossref_title") and score < 0.74)
    mismatch = mismatch or not metadata.get("doi_match", True)
    if metadata.get("s2_title") and metadata.get("s2_similarity", 1) < 0.65:
        # Only use S2 conflicting item for a warning; Crossref controls DOI identity.
        errors.append("SemanticScholar:title mismatch - any PDF candidate requires strict QA")
    return candidates, metadata, errors, mismatch


def extract_pdf(path, text_output):
    try:
        from pypdf import PdfReader
    except ImportError:
        return "not_installed", None, ""
    try:
        reader = PdfReader(str(path), strict=False)
        n = len(reader.pages)
        if n <= 0:
            return "invalid", n, "zero pages"
        snippets = []
        for page_index, page in enumerate(reader.pages):
            # Limit text extraction to avoid runaway memory on malformed PDFs.
            t = (page.extract_text() or "")[:150_000]
            snippets.append(f"\n\n====== PAGE {page_index + 1} ======\n" + t)
        text_output.parent.mkdir(parents=True, exist_ok=True)
        text_output.write_text("".join(snippets), encoding="utf-8")
        return "extracted", n, ""
    except Exception as e:
        return "cannot_extract", None, f"{type(e).__name__}: {str(e)[:100]}"


def discover_alternatives(*_args, **_kwargs):
    """No quota-based services; Codex can document targeted supplements manually."""
    return []


def save_csv(path, data, headers):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.DictWriter(fp, fieldnames=headers, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(data)


def run(args):
    root = Path(args.project).resolve()
    records = json.loads((root / "catalog_34.json").read_text(encoding="utf-8"))
    if len(records) != 34 or [x["id"] for x in records] != list(range(1, 35)):
        raise RuntimeError("Fixed core manifest must contain exactly IDs 1..34")
    client = Client(timeout=args.timeout, delay=args.delay)
    if not getattr(args, "no_preflight", False):
        # Early exit instead of letting 34 items each run through disconnected APIs.
        prior_timeout = client.timeout
        client.timeout = min(8, prior_timeout)
        online = False
        diagnostic = []
        for endpoint in ("https://api.crossref.org/works?rows=0", "https://api.semanticscholar.org/graph/v1/paper/DOI:10.3390/machines10100937?fields=title"):
            try:
                client.json(endpoint)
                online = True
                break
            except Exception as exc:
                diagnostic.append(f"{type(exc).__name__}: {str(exc)[:90]}")
        client.timeout = prior_timeout
        if not online:
            raise RuntimeError("Cannot reach scholarly HTTPS APIs. Enable network for the Codex execution environment and retry. " + "; ".join(diagnostic))
    output_dir = root / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    previous = {}
    previous_path = output_dir / "STATUS_34.json"
    if previous_path.exists():
        try:
            previous = {r["id"]: r for r in json.loads(previous_path.read_text(encoding="utf-8"))}
        except Exception:
            previous = {}
    results = [{**r, "status": "NOT_RUN", "metadata_status": "NOT_CHECKED", "pdf_path": "",
                "failure_reason": "Codex has not processed this record yet", "manual_url": r.get("doi_url") or r.get("source_url") or ""}
               for r in records]
    for i, r in enumerate(results):
        if r["id"] in previous:
            results[i] = previous[r["id"]]
    rejected_urls = []
    alternative_rows = []
    (output_dir / "PDF_34_Core").mkdir(parents=True, exist_ok=True)
    (output_dir / "Extracted_Text").mkdir(parents=True, exist_ok=True)
    limited_records = records if not args.ids else [r for r in records if r["id"] in args.ids]
    for item in limited_records:
        idx = item["id"]
        doi = item["doi"]
        print(f"[{idx:02d}/34] {item['title'][:75]}", flush=True)
        result = {**item, "status": "UNAVAILABLE", "metadata_status": "NOT_CHECKED",
                  "source": "", "version": "", "license": "", "pdf_path": "", "sha256": "",
                  "bytes": "", "pages": "", "text_extraction": "", "url": "", "manual_url": "",
                  "checked_at": now(), "failure_reason": "", "notes": "", "abstract_text": "",
                  "abstract_source": "", "journal": "", "authors": "", "publisher": "",
                  "publication_year_verified": "", "access_evidence": "ACCESS_NOT_CONFIRMED"}
        path = output_dir / "PDF_34_Core" / f"A10_{idx:02d}.pdf"
        if path.exists() and not args.force:
            try:
                with path.open("rb") as fp:
                    head = fp.read(1024)
                    fp.seek(max(0, path.stat().st_size - 4096))
                    tail = fp.read()
                if b"%PDF-" in head and b"%%EOF" in tail:
                    result.update({k: v for k, v in previous.get(idx, {}).items() if k in result})
                    result.update(status="EXISTS_PREVIOUS_RUN", pdf_path=str(path.relative_to(root)), bytes=path.stat().st_size,
                                  sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                                  notes=str(result.get("notes", "")) + " | Previously downloaded; retaining recorded provenance")
                    results[idx-1] = result
                    persist(root, results, rejected_urls, alternative_rows)
                    continue
            except Exception:
                pass
        cands, md, errors, mismatch = collect(client, item)
        result["metadata_status"] = "TITLE_DOI_MISMATCH" if mismatch else ("VERIFIED" if md.get("crossref_title") else "NOT_CONFIRMED")
        result["abstract_text"] = md.get("crossref_abstract") or md.get("s2_abstract") or ""
        result["abstract_source"] = "Crossref" if md.get("crossref_abstract") else ("SemanticScholar" if md.get("s2_abstract") else "")
        result["journal"] = md.get("crossref_journal") or ""
        result["authors"] = "; ".join(", ".join(filter(None, [a.get("family"), a.get("given")])) or a.get("name", "") for a in md.get("crossref_authors", []))
        result["publisher"] = md.get("crossref_publisher") or ""
        result["publication_year_verified"] = md.get("crossref_year") or ""
        result["access_evidence"] = "S2_INDICATES_NON_OA_NOT_DEFINITIVE" if md.get("s2_isOpenAccess") is False else ("S2_INDICATES_OA" if md.get("s2_isOpenAccess") is True else "ACCESS_NOT_CONFIRMED")
        result["notes"] = json.dumps(md, ensure_ascii=False)
        if mismatch:
            result["status"] = "CHECK_METADATA"
            result["failure_reason"] = "Publisher DOI metadata/title mismatch; disabled automatic download"
            result["manual_url"] = item.get("doi_url") or item["source_url"]
            results[idx-1] = result
            persist(root, results, rejected_urls, alternative_rows)
            print("  => CHECK_METADATA (DOI/title conflict)")
            continue
        for c in cands:
            try:
                digest, size, actual_url = client.download_pdf(c["url"], path)
                text_state, pages, extract_err = extract_pdf(path, output_dir / "Extracted_Text" / f"A10_{idx:02d}.txt")
                if text_state == "invalid":
                    path.unlink(missing_ok=True)
                    raise ValueError("malformed PDF: zero pages")
                result.update(status="DOWNLOADED", source=c["source"], version=c["version"],
                              license=c["license"], pdf_path=str(path.relative_to(root)),
                              sha256=digest, bytes=size, pages=pages or "", text_extraction=text_state,
                              url=safe_public_url(actual_url), failure_reason="", manual_url="", checked_at=now())
                if extract_err:
                    result["notes"] += f" | PDF text warning: {extract_err}"
                if text_state != "extracted":
                    result["status"] = "DOWNLOADED_NEEDS_QA"
                    result["notes"] += " | Full-text identity not verified from PDF pages (pypdf unavailable or extraction failed)"
                if text_state == "extracted":
                    txt_path = output_dir / "Extracted_Text" / f"A10_{idx:02d}.txt"
                    body = txt_path.read_text(encoding="utf-8")[:25000]
                    title_tokens = [t for t in normalize_title(item["title"]).split() if len(t) > 3]
                    if title_tokens and body.strip():
                        overlap = sum(token in normalize_title(body) for token in title_tokens) / len(title_tokens)
                        if overlap < 0.35:
                            result["status"] = "DOWNLOADED_NEEDS_QA"
                            result["notes"] += " | Title terms weakly match PDF text; manually inspect file"
                print(f"  => DOWNLOADED ({size} bytes, {c['source']})", flush=True)
                break
            except (HTTPError, URLError, ValueError, RuntimeError, TimeoutError, OSError) as e:
                rejected_urls.append({"id": idx, "source": c["source"], "url": safe_public_url(c["url"]),
                                      "error": f"{type(e).__name__}: {str(e)[:250]}"})
        if result["status"] not in ("DOWNLOADED", "DOWNLOADED_NEEDS_QA"):
            # Missing an OA file does not prove the paper is definitively non-OA.
            # Keep the bibliography regardless: non-OA, inaccessible and unknown are all citable at the appropriate evidence level.
            result["status"] = "NO_FREE_PDF_FOUND" if cands else "NO_PDF_URL_FOUND"
            result["manual_url"] = item["doi_url"] or item["fulltext_hint_url"] or item["source_url"]
            result["failure_reason"] = "; ".join(errors[-6:]) or "Candidate PDF links blocked, not PDF, or inaccessible"
            print(f"  => {result['status']} (manual list)", flush=True)
        results[idx-1] = result
        # Save after every record, so interrupted jobs resume without losing the audit trail.
        persist(root, results, rejected_urls, alternative_rows)
    persist(root, results, rejected_urls, alternative_rows)
    build_deliverables(root, records, results)
    good = sum(x["status"] in ("DOWNLOADED", "EXISTS_PREVIOUS_RUN", "DOWNLOADED_NEEDS_QA") for x in results)
    checked = sum(x["status"] != "NOT_RUN" for x in results)
    print(f"\nChecked {checked}/34 | locally saved PDFs {good} | no local PDF yet {len(results)-good}")
    print("Review output/STATUS_34.csv and output/MANUAL_DOWNLOAD.csv; do not count suggestions as recovered papers.")


def persist(root, results, rejected, alternatives):
    out = root / "output"
    keys = ["id", "priority", "category", "title", "doi", "status", "metadata_status", "source", "version",
            "license", "pages", "bytes", "sha256", "url", "manual_url", "pdf_path", "text_extraction",
            "failure_reason", "notes", "checked_at", "authors", "journal", "publisher",
            "publication_year_verified", "abstract_source", "abstract_text", "access_evidence"]
    save_csv(out / "STATUS_34.csv", results, keys)
    save_csv(out / "MANUAL_DOWNLOAD.csv",
             [x for x in results if x["status"] not in ("DOWNLOADED", "EXISTS_PREVIOUS_RUN", "DOWNLOADED_NEEDS_QA")], keys)
    save_csv(out / "CANDIDATE_URL_FAILURES.csv", rejected, ["id", "source", "url", "error"])
    save_csv(out / "OA_补充候选_不替代原34篇.csv", alternatives,
             ["original_id", "original_title", "suggested_title", "suggested_doi", "suggested_year",
              "suggested_pdf", "suggested_oa_page", "license", "relation", "verification"])
    (out / "STATUS_34.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    create_reference_outputs(out, results)



def bibtex_escape(text_value):
    """Escape TeX-reserved tokens; keep UTF-8 article titles unchanged otherwise."""
    return str(text_value or "").replace("\\", "\\textbackslash ").replace("{", "\\{").replace("}", "\\}").replace("&", "\\&")


def create_reference_outputs(out, results):
    """All 34 remain in the citing ledger regardless of whether a PDF is present."""
    downloaded = {"DOWNLOADED", "DOWNLOADED_NEEDS_QA", "EXISTS_PREVIOUS_RUN"}
    citation_rows, nonoa_rows, bib_entries = [], [], []
    for r in results:
        is_local = r.get("status") in downloaded
        metadata_ok = r.get("metadata_status") == "VERIFIED"
        abstract_available = bool(r.get("abstract_text", "").strip())
        level = ("FULLTEXT_AVAILABLE_NEEDS_PAGE_QA" if is_local else
                 "ABSTRACT_ONLY" if abstract_available else "METADATA_ONLY")
        if r.get("metadata_status") == "TITLE_DOI_MISMATCH":
            level = "BIBLIOGRAPHY_NEEDS_CORRECTION"
        oa_access = ("PDF_LOCALLY_SAVED" if is_local else
                     "NOT_LOCATED_OR_ACCESS_RESTRICTED" if r.get("status") not in ("NOT_RUN", "CHECK_METADATA") else
                     "NOT_VERIFIED")
        row = {"id": r["id"], "title": r["title"], "doi": r["doi"],
               "year_catalog": r.get("year", ""), "year_verified": r.get("publication_year_verified", ""),
               "authors": r.get("authors", ""), "journal": r.get("journal", ""),
               "publisher": r.get("publisher", ""), "metadata_status": r.get("metadata_status", "NOT_CHECKED"),
               "pdf_status": r.get("status", "NOT_RUN"), "access_status": oa_access,
               "access_evidence": r.get("access_evidence", "ACCESS_NOT_CONFIRMED"),
               "citation_evidence_level": level, "abstract_source": r.get("abstract_source", ""),
               "abstract_text": r.get("abstract_text", ""),
               "citation_url": r.get("doi_url") or r.get("source_url") or "",
               "citation_key": f"A10_{r['id']:02d}", "notes": "Same original reference is retained; no full-text results may be invented"}
        citation_rows.append(row)
        if not is_local and r.get("status") != "NOT_RUN":
            nonoa_rows.append(row)
        entry_type = "article" if r.get("doi") else "techreport"
        # Minimal BibTeX records for unresolved metadata MUST be reviewed before manuscript submission.
        body = [f"  title = {{{bibtex_escape(r['title'])}}}", f"  year = {{{bibtex_escape(r.get('publication_year_verified') or r.get('year') or '')}}}"]
        if r.get("doi"):
            body.append(f"  doi = {{{r['doi']}}}")
        if r.get("doi_url") or r.get("source_url"):
            body.append(f"  url = {{{r.get('doi_url') or r.get('source_url')}}}")
        if r.get("authors"):
            # Author field entered as human-readable verified name; verify before submission.
            body.append(f"  author = {{{bibtex_escape(r['authors'].replace('; ', ' and '))}}}")
        if r.get("journal"):
            body.append(f"  journal = {{{bibtex_escape(r['journal'])}}}")
        if r.get("publisher"):
            body.append(f"  publisher = {{{bibtex_escape(r['publisher'])}}}")
        if not metadata_ok:
            body.append("  note = {Metadata requires verification before manuscript submission}")
        bib_entries.append(f"@{entry_type}{{A10_{r['id']:02d},\n" + ",\n".join(body) + "\n}\n")
    headers = ["id", "title", "doi", "year_catalog", "year_verified", "authors", "journal", "publisher",
               "metadata_status", "pdf_status", "access_status", "access_evidence", "citation_evidence_level",
               "abstract_source", "abstract_text", "citation_url", "citation_key", "notes"]
    save_csv(out / "CITATION_AUDIT_34.csv", citation_rows, headers)
    save_csv(out / "NON_OA_未获取全文但保留引用.csv", nonoa_rows, headers)
    (out / "A10_核心34篇_含非OA.bib").write_text("\n".join(bib_entries), encoding="utf-8")



def build_deliverables(root, records, results):
    """Create a verified-identity audit package and an evidence template, no invented findings."""
    out = root / "output"
    core = out / "PDF_34_Core"
    evidence_path = out / "EVIDENCE_MATRIX_34.csv"
    evidence_fields = ["id", "title", "doi", "priority", "category", "full_text_status", "pdf_file",
                       "version", "citation_evidence_level", "abstract_source", "evidence_page", "study_region_border", "data_source_sensor",
                       "period_and_sample", "spatial_temporal_resolution", "prediction_target",
                       "forecast_horizon", "queue_congestion_mechanisms", "fusion_method",
                       "baseline_models", "model_method", "evaluation_protocol", "MAE", "RMSE", "MAPE",
                       "key_findings", "limitations", "JB_Singapore_CIQ_relevance", "evidence_grade", "extractor_notes"]
    existing_matrix = {}
    if evidence_path.exists():
        try:
            with evidence_path.open("r", encoding="utf-8-sig", newline="") as fp:
                existing_matrix = {int(row["id"]): row for row in csv.DictReader(fp) if row.get("id", "").isdigit()}
        except Exception:
            existing_matrix = {}
    by_id = {r["id"]: r for r in results}
    evidence = []
    for r in records:
        state = by_id[r["id"]]
        row = {"id": r["id"], "title": r["title"], "doi": r["doi"], "priority": r["priority"],
               "category": r["category"], "full_text_status": state["status"],
               "pdf_file": state.get("pdf_path", ""), "version": state.get("version", ""),
               "citation_evidence_level": ("FULL_TEXT_CANDIDATE" if state.get("status") in ("DOWNLOADED", "DOWNLOADED_NEEDS_QA", "EXISTS_PREVIOUS_RUN") else
                                           "ABSTRACT_ONLY" if state.get("abstract_text") else "METADATA_ONLY"),
               "abstract_source": state.get("abstract_source", ""),
               "evidence_grade": "NOT_YET_EXTRACTED", "extractor_notes": "If no verified PDF, describe only abstract/metadata-supported claims"}
        row.update({k: v for k, v in existing_matrix.get(r["id"], {}).items()
                    if k not in ("id", "title", "doi", "priority", "category", "full_text_status", "pdf_file", "version", "citation_evidence_level", "abstract_source")})
        evidence.append(row)
    save_csv(evidence_path, evidence, evidence_fields)
    valid = []
    for r in results:
        pdf = core / f"A10_{r['id']:02d}.pdf"
        if r["status"] in ("DOWNLOADED", "DOWNLOADED_NEEDS_QA", "EXISTS_PREVIOUS_RUN") and pdf.is_file():
            with pdf.open("rb") as f:
                head = f.read(1024)
                f.seek(max(0, pdf.stat().st_size-4096))
                tail = f.read()
            if b"%PDF-" in head and b"%%EOF" in tail:
                valid.append((r, pdf))
    zip_path = out / "PDF_34_Core.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for r, pdf in valid:
            z.write(pdf, f"A10_{r['id']:02d}.pdf")
    counts = {status: sum(r["status"] == status for r in results) for status in sorted(set(r["status"] for r in results))}
    report = ["# A10｜34篇核心文献全文与非OA可引用记录", "",
              f"- Report generated (UTC): {now()}",
              "- Fixed core bibliography: 34 (31 with DOI, 3 technical reports without DOI)",
              f"- Records attempted: {sum(r['status'] != 'NOT_RUN' for r in results)}/34",
              f"- Actual local PDFs passing binary integrity checks: **{len(valid)}/34**",
              f"- Saved PDFs needing article-identity/page-level QA: {sum(r['status']=='DOWNLOADED_NEEDS_QA' for r in results)}",
              f"- Core records without local PDFs: {34-len(valid)}",
              f"- ZIP: `output/PDF_34_Core.zip` ({len(valid)} file(s))", "",
              "## Per-status breakdown", ""]
    report += [f"- {k}: {v}" for k,v in counts.items()]
    without_pdf = [r for r in results if r["status"] not in ("DOWNLOADED", "DOWNLOADED_NEEDS_QA", "EXISTS_PREVIOUS_RUN")]
    report += ["", "## Citation eligibility (independent of PDF acquisition)", "",
               f"- Unrecovered references with an indexed abstract: {sum(bool(r.get('abstract_text')) for r in without_pdf)}",
               f"- Unrecovered references without an indexed abstract: {sum(not bool(r.get('abstract_text')) for r in without_pdf)}",
               f"- Records flagged DOI/title mismatch: {sum(r.get('metadata_status') == 'TITLE_DOI_MISMATCH' for r in results)}",
               "- All original 34 bibliography rows are preserved in CITATION_AUDIT_34.csv and the BibTeX; verify incomplete metadata before journal submission."]
    report += ["", "## Integrity/interpretation", "",
               "A `DOWNLOADED` status means a local PDF passed basic byte checks, not that the scientific conclusions have been read and verified.",
               "`DOWNLOADED_NEEDS_QA` requires inspection before citation. Version/licensing might remain unknown.",
               "OA thematic supplements (if any) are not counted as recovered core articles.",
               "There was no paywall bypass or unauthorized institutional credential use.", "",
               "Non-OA/inaccessible works remain in `CITATION_AUDIT_34.csv` and `A10_核心34篇_含非OA.bib`.",
               "If only an abstract is available, cite only statements explicitly supported by it; no numerical/model claims based on unseen full texts.",
               "An API indicating non-OA or an unsuccessful PDF fetch is not proof that no legal OA copy exists.",
               "No OpenAlex, Unpaywall, paid quota, API key, or account is used; public endpoints still enforce fair-use rate limits.",
               "Manual follow-up: see `output/MANUAL_DOWNLOAD.csv`."]
    (out / "COVERAGE_SUMMARY.md").write_text("\n".join(report)+"\n", encoding="utf-8")

def parse_args():
    p = argparse.ArgumentParser(description="Download as many legally accessible OA PDFs from the frozen A10 34-paper corpus as possible")
    p.add_argument("--project", default=str(Path(__file__).resolve().parents[4]), help="Directory containing catalog_34.json")
    p.add_argument("--ids", type=int, nargs="*", default=[], help="Optional IDs to retry individually (otherwise all 34)")
    p.add_argument("--force", action="store_true", help="Re-download even if verified-looking file already exists")
    p.add_argument("--supplements", action="store_true", help="Write separate supplement candidates if Codex has verified them; no paid or key-based service used")
    p.add_argument("--supplement-limit", type=int, default=2, help="Max alternative suggestions per unresolved item")
    p.add_argument("--no-preflight", action="store_true", help="Skip initial scholarly API connectivity check (use only when necessary)")
    p.add_argument("--timeout", type=int, default=22)
    p.add_argument("--delay", type=float, default=1.2, help="Seconds between requests; avoid aggressive crawling")
    return p.parse_args()


if __name__ == "__main__":
    try:
        run(parse_args())
    except KeyboardInterrupt:
        print("Interrupted; previously completed records and PDFs remain on disk.", file=sys.stderr)
        sys.exit(130)
