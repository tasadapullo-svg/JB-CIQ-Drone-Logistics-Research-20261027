---
name: a10-oa-fulltext
description: Keyless no-account batch acquisition of lawful PDFs for the frozen 34-paper A10 CIQ review, preserving all non-OA papers as cited records with explicit abstract-only evidence labels.
---

# A10｜固定34篇文献免额度采集与非OA证据追踪

## Hard constraints

- Original `catalog_34.json` IDs 01–34 are FROZEN, including three reports without DOI. Never delete, replace or inflate original core counts.
- Do **not** call OpenAlex, Unpaywall, paid APIs, quota-account services, API keys or credit-based research providers. Do not request an email or registration from user. Free public endpoints are subject to throttling; respect 429 and exponential backoff.
- No Sci-Hub/LibGen, paywall circumvention, cookie theft, robots.txt bypass, CAPTCHAs, unauthorized subscriptions or invented access claims.
- **Non-OA or unlocatable originals remain in the manuscript citation set.** Lack of PDF != not scientifically citable, and lack of PDF != definitively non-OA. Classify evidence level independently from OA/access state.
- Full text available => methods/data/results must cite PDF page(s). No full text => use public metadata/abstract *only for what it explicitly supports*. If abstract is missing, bibliographic metadata alone cannot support substantive results or experiment comparisons. Do not invent numbers, metrics, dates, model details, sample sizes or evaluation outcomes.
- Preprint, accepted manuscript and published version of same paper are allowed only after DOI/title identity check. Distinct topical OA papers are **supplements**, not original-corpus replacements.

## Codex procedure (single bounded run)

1. Read manifest, verify 34 records (31 DOI + 3 reports), read `AGENTS.md` and this skill. Keep scope JB–Singapore CIQ (multi-source data, congestion, wait time, cross-border dynamics, spatiotemporal prediction).
2. Confirm network enabled in Codex and Python 3.10+ installed. Optional `python -m pip install pypdf` for page-level PDF extraction. Never buy or request an API key.
3. Run from project root: `python .agents/skills/a10-oa-fulltext/scripts/download_oa.py --project .`. The stdlib script queries only publicly available, no-account services (Crossref for DOI metadata, Semantic Scholar for available OA-PDF links), tests exact user-provided public URLs and several publisher PDF formats, follows fair-use throttling, and checks actual PDF bytes.
4. For unresolved IDs, Codex should **automatically research** the *same* original paper using publisher public pages, university repository, author accepted manuscripts, government/public reporting archives. No scraping or bypass of restricted sites. Record exact landing URL, version, matching identifier, license (if available), and either download to `output/PDF_34_Core/A10_XX.pdf` with the same binary QA or add reason to `MANUAL_DOWNLOAD.csv`. Code may be extended with *specific verified public links* for targeted retries. No per-paper questions to user.
5. Produce `output/STATUS_34.csv`, `CITATION_AUDIT_34.csv`, `NON_OA_未获取全文但保留引用.csv`, `MANUAL_DOWNLOAD.csv`, `PDF_34_Core.zip`, `A10_核心34篇_含非OA.bib`, `EVIDENCE_MATRIX_34.csv`, and `COVERAGE_SUMMARY.md`. Only actual on-disk PDFs count as downloaded. Populate evidence *only when actually supported* and distinguish FULL_TEXT, ABSTRACT_ONLY and METADATA_ONLY.
6. Where metadata DOI/title mismatch (`CHECK_METADATA`), flag and prevent silent citation until resolved. Where S2 says non-OA, label as evidence, not conclusive proof. Unsuccessful OA retrieval does not mean the original must be excluded from literature review.
7. The 3 reports without DOI use report title, official report URL, year and publisher when independently verified; do not invent DOI or author names. Their BibTeX must be checked before submission.
8. Other OA papers are optional, separate, few and tightly focused; do not inflate primary 34. Do not repeatedly expand ordinary traffic forecasting literature.
9. Final report should give original 34, confirmed metadata count, actually saved exact-PDF count, abstract-only count, metadata-only count, pending full-text/manual count, errors and distinct supplementary candidates. Audit facts, do not claim all PDFs acquired.

## Evidence eligibility in manuscript

- `FULL_TEXT_VERIFIED`: article-identity checked and claim verified against stated PDF page.
- `ABSTRACT_ONLY`: cite for broad scope/purpose or findings *explicitly in the indexed abstract*. Label provenance when building evidence matrix; no page references or numeric method comparisons.
- `METADATA_ONLY`: can support bibliographic/field context only, not methods or findings.
- `BIBLIOGRAPHY_NEEDS_CORRECTION`: do not submit citation until DOI/title/year conflict resolved.

## Official providers

- Crossref: https://www.crossref.org/documentation/retrieve-metadata/rest-api/access-and-authentication/ — public, no registration; rate-limited.
- Semantic Scholar: https://www.semanticscholar.org/product/api — many public unkeyed endpoints; rate-limited.
- Official publisher/author/university/government open pages, with full-text rights verified.
