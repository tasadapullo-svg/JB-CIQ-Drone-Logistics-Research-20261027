A10 Codex Skill｜固定34篇｜公开无Key获取 + 非OA照常引用

1. 解压整个项目文件夹，保留隐藏 `.agents` 目录。在 Codex 中打开项目文件夹。
2. 将 `RUN_CODEX_PROMPT.txt` 内容提交给 Codex，要求按 `$a10-oa-fulltext` 执行。
3. 不用 OpenAlex，不用 Unpaywall，不用收费服务，无需 API Key、邮箱或付费额度。
4. 使用公开的 Crossref 与 Semantic Scholar 查询，页面可能存在 HTTP 429 限频；脚本限制速度、会记录失败并可重试。限频不等于购买额度，不能承诺无限调用。
5. 可以先在联网电脑运行：`python .agents/skills/a10-oa-fulltext/scripts/download_oa.py --project .`
6. 可选安装 pypdf：`python -m pip install pypdf`，用于按页读取 PDF；不需要任何 API Token。
7. 输出目录 `output/` 包含 `PDF_34_Core.zip`、`STATUS_34.csv`、`MANUAL_DOWNLOAD.csv`、`CITATION_AUDIT_34.csv`、`NON_OA_未获取全文但保留引用.csv`、`A10_核心34篇_含非OA.bib`、`EVIDENCE_MATRIX_34.csv` 和覆盖率报告。
8. 非OA / 获取不到全文的文献也保留引用。仅有摘要时可依据摘要说明研究方向或公开结论，实验数据不能臆造；无摘要时仅可使用可靠出版元数据。绝对不要把“没找到OA”说成确定非OA。
9. 本压缩包是 Codex 工具，不是已经下载到手的34篇PDF。需要在允许访问互联网的本地 Codex 环境实际运行并确认成果。
