#!/usr/bin/env python3
"""JB-CIQ E01 source-preserving calendar repair and E02 geometry-only proxy audit.
Not a validated navigable GIS road network. Speed unit remains conditional.
Run from /mnt/data or set BASE via argument.
"""
import sys, pathlib, gzip, json, hashlib, re, math
import numpy as np
import pandas as pd
from pyproj import Geod
from collections import defaultdict
BASE=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path('/mnt/data')
OUT=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else BASE/'JB_CIQ_E01_E02_V4_3'
OUT.mkdir(exist_ok=True, parents=True)
REG=BASE/'JB_FCD_G1-G5_2026_05-09/Node_Registry_345_Grouped.csv'
r=pd.read_csv(REG, encoding='utf-8-sig'); r['node_id']=r['node_id'].astype(str)
assert len(r)==345 and r.node_id.is_unique
rd=r.set_index('node_id')
files=sorted(BASE.glob('PROVISIONAL_FCD_JB_2026_??_345NODE_ANALYSIS_V1.csv'))
assert len(files)==5,files
fix=OUT/'E01_traffic_calendar_corrected_345nodes_2026_05-09.csv.gz'
if fix.exists():fix.unlink()
written=False
mon=[]; sources=[]; grp=[]; correction=[]; all_g1=[]; unit_info=[]
for f in files:
  mo=int(re.search('2026_(\d\d)_',f.name).group(1))
  obs=0; valid=0; missing=0; bad=0; mism=0; dup=0; hourm=0; dobs=set()
  sha=hashlib.sha256()
  with open(f,'rb') as raw:
    for b in iter(lambda:raw.read(1024*1024),b''):sha.update(b)
  for chunk in pd.read_csv(f, chunksize=65000, low_memory=False, na_values=['\\N','', 'NULL']):
    n=len(chunk);obs+=n
    # Important: timestamp is trusted because local_date and weekday not independent in Sep
    ts=pd.to_datetime(chunk['hour_start_time'], errors='raise',utc=True).dt.tz_convert('Asia/Kuala_Lumpur')
    wk=ts.dt.dayofweek+1
    chk=pd.to_numeric(chunk['weekday'],errors='coerce')
    mm=wk.ne(chk)
    mism+=int(mm.sum())
    hh=ts.dt.hour
    hourm+=int(hh.ne(pd.to_numeric(chunk['local_hour'],errors='coerce')).sum())
    speed=pd.to_numeric(chunk['observed_hourly_speed'],errors='coerce')
    speedstate=np.select([speed.isna(),speed.le(0)],['MISSING','NONPOSITIVE'],default='POSITIVE')
    missing+=int(speed.isna().sum()); bad+=int(speed.notna().mul(speed.le(0)).sum()); valid+=int(speed.gt(0).sum())
    # build one record per node-hour, retaining raw values
    view=pd.DataFrame({
      'node_id':chunk['node_key'].astype(str),
      'timestamp_local':ts.dt.strftime('%Y-%m-%dT%H:%M:%S%z'),
      'local_date_derived':ts.dt.strftime('%Y-%m-%d'),
      'local_hour_derived':hh.astype('int8'),
      'weekday_derived_Mon1_Sun7':wk.astype('int8'),
      'is_weekend_derived':wk.ge(6),
      'weekday_source':chk,
      'weekday_source_mismatch':mm,
      'observed_speed_raw':speed,
      'speed_state':speedstate,
      'source_month':mo,
    })
    view=view.join(rd[['group_id','source_route_code','latitude','longitude','name_evidence_status']],on='node_id',how='left')
    assert view['group_id'].notna().all(), 'unmatched node'
    assert view['source_route_code'].notna().all()
    assert ts.dt.month.eq(mo).all()
    # Dedup exact node-hour using composite key and detect within/across chunks
    for row in zip(view['node_id'],view['timestamp_local']):
      if row in dobs:dup+=1
      else:dobs.add(row)
    if mo==9: correction.append(view.loc[view.weekday_source_mismatch,['node_id','timestamp_local','weekday_source','weekday_derived_Mon1_Sun7']].head(3))
    view.to_csv(fix, index=False, header=not written, mode='at' if written else 'wt',compression='gzip',float_format='%.9g')
    written=True
    if (view.group_id=='G1').any():all_g1.append(view.loc[view.group_id=='G1',['node_id','timestamp_local','observed_speed_raw']])
    sub=view.groupby('group_id',observed=True).agg(n=('node_id','size'),n_positive=('observed_speed_raw',lambda x: int((x>0).sum())), mean_positive=('observed_speed_raw',lambda x:float(x[x>0].mean()))).reset_index()
    for row in sub.itertuples(index=False):grp.append({'month':mo,'group':row.group_id,'records':int(row.n),'valid_positive':int(row.n_positive),'speed_mean_chunk':row.mean_positive})
  mon.append({'month':mo,'rows':obs,'valid_positive':valid,'missing':missing,'nonpositive':bad,'weekday_mismatch':mism,'local_hour_mismatch':hourm,'duplicate_node_hours':dup,'unique_node_hours':len(dobs),'raw_columns':len(pd.read_csv(f,nrows=0).columns)})
  sources.append({'file':f.name,'sha256':sha.hexdigest(),'byte_size':f.stat().st_size})
  print('processed',f.name,obs,valid,missing,bad,mism,flush=True)
assert sum(a['rows'] for a in mon)==1266840
pd.DataFrame(mon).to_csv(OUT/'E01_monthly_QA.csv',index=False)
pd.DataFrame(sources).to_csv(OUT/'E01_source_SHA256.csv',index=False)
# revalidate derived from immutable sources source speed hash per month per chunks at transport precision retained
# Check complete calendar and all expected 345 node IDs & calendar records
assert all(a['rows']==345*({5:31,6:30,7:31,8:31,9:30}[a['month']])*24 for a in mon)
assert all(a['duplicate_node_hours']==0 and a['local_hour_mismatch']==0 for a in mon)
assert sum(a['weekday_mismatch'] for a in mon)==215280
# Corrected calendar recompute totals by group; avoid means of means: derived file audit
records=[]
for ch in pd.read_csv(fix,compression='gzip',chunksize=75000):
  ch['month']=ch['source_month']
  for (month,g),part in ch.groupby(['month','group_id']):
    v=part.observed_speed_raw
    records.append((month,g,len(part),int(v.gt(0).sum()),float(v[v>0].sum())))
agg=defaultdict(lambda:[0,0,0.0])
for m,g,n,k,s in records:
 x=agg[(int(m),g)];x[0]+=n;x[1]+=k;x[2]+=s
out=[]
for (m,g),(n,k,s) in sorted(agg.items()):out.append({'month':m,'group':g,'rows':n,'valid_positive':k,'mean_speed_assuming_source_unit':round(s/k,6) if k else None})
pd.DataFrame(out).to_csv(OUT/'E01_final_GroupMonth.csv',index=False)

# Geometry-only path audit: sampled corridors have positions but NO sourced navigable edges, routing direction, or turns.
# Separate A/B point chains, a topology that must NOT be mistaken for verified OSM roads.
g1=pd.concat(all_g1,ignore_index=True)
g1['timestamp_local']=pd.to_datetime(g1['timestamp_local'])
sel=r[r.group_id=='G1'].copy()
def branch(nid):
  m=re.match(r'^(R[12])([AB])(\d+)$',nid)
  if m:return m.group(1),m.group(2),int(m.group(3))
  return None
sel['branch']=sel.node_id.map(branch)
extras=sel[sel.branch.isna()][['node_id','source_route_code','latitude','longitude','name_evidence_status']].copy()
extras['audit']='NOT_LINKED_TO_SAMPLED_BRANCH_UNVERIFIED_TOPOLOGY'
extras.to_csv(OUT/'E02_isolated_node_audit.csv',index=False)
geo=Geod(ellps='WGS84')
chains={}; links=[]
for corridor in ['R1','R2']:
 for branchcode in ['A','B']:
  b=sel[sel.branch.apply(lambda v:v is not None and v[0]==corridor and v[1]==branchcode)].copy()
  b['index']=b.branch.map(lambda v:v[2]);b=b.sort_values('index')
  chains[corridor+branchcode]=b.node_id.tolist()
  for i in range(len(b)-1):
    p,q=b.iloc[i],b.iloc[i+1]
    _,_,dist=geo.inv(float(p.longitude),float(p.latitude),float(q.longitude),float(q.latitude))
    state='PROXY_ONLY_NOT_NETWORK_EDGE'
    flag='REJECTED_OR_UNMATCHED' if p.name_evidence_status in ['REJECTED','UNMATCHED'] or q.name_evidence_status in ['REJECTED','UNMATCHED'] else 'NON_REJECTED_BUT_UNVERIFIED'
    links.append({'corridor':corridor,'sample_branch':branchcode,'from_sample':p.node_id,'to_sample':q.node_id,
        'from_lat':float(p.latitude),'from_lon':float(p.longitude),'to_lat':float(q.latitude),'to_lon':float(q.longitude),
        'beeline_m':round(float(dist),3),'geometry_basis':'WGS84 geodesic from consecutive sample points',
        'direction_verification':'UNKNOWN','road_geometry_verified':False,'legal_turns_verified':False,
        'name_evidence_flag':flag,'route_status':state,'cross_border_clipping_verified':False})
pd.DataFrame(links).to_csv(OUT/'E02_sample_chain_geometry_NOT_OSM_edges.csv',index=False)
# timeseries: only observed positive speeds; harmonic mean at consecutive query points -> no claim actual road TT
speedmat=g1.pivot(index='timestamp_local',columns='node_id',values='observed_speed_raw').sort_index()
assert len(speedmat)==3672 and speedmat.columns.nunique()==46
all_t=[]; sampled=[]
for route,ids in chains.items():
  seg=[a for a in links if a['corridor']+a['sample_branch']==route]
  dt=np.empty((len(speedmat),len(seg)),float)
  for j,a in enumerate(seg):
    si=speedmat[a['from_sample']].to_numpy(float)
    sj=speedmat[a['to_sample']].to_numpy(float)
    km=float(a['beeline_m'])/1000
    ok=np.isfinite(si)&np.isfinite(sj)&(si>0)&(sj>0)
    dt[:,j]=np.where(ok,(km/2)*(1/np.where(si>0,si,np.nan)+1/np.where(sj>0,sj,np.nan))*60,np.nan)
  nvalid=np.isfinite(dt).sum(axis=1)
  full=nvalid==len(seg)
  times=np.where(full,np.nansum(dt,axis=1),np.nan)
  out=pd.DataFrame({'timestamp_local':speedmat.index.strftime('%Y-%m-%dT%H:%M:%S%z'),
      'corridor_branch':route,'sample_first':ids[0],'sample_last':ids[-1],
      'geometric_polyline_km':round(sum(a['beeline_m'] for a in seg)/1000,6),
      'adjacent_sample_links':len(seg),'links_with_positive_end_speeds':nvalid,
      'full_path_speed_data_present':full,
      'geometric_proxy_travel_min_if_unit_kmph':times,
      'routing_validated':False,
      'result_class':'UNCERTIFIED_POINT_CHAIN_PROXY_NOT_REAL_OD'})
  all_t.append(out)
  # sample OD matrix at frozen 08 12 17 20; list contiguous on one branch only, no road intersections
  subs=np.where(speedmat.index.hour.isin([8,12,17,20]))[0]
  for k in subs:
    tt=dt[k,:]
    for i in range(len(ids)-1):
      subtotal=0.
      for j in range(i+1,len(ids)):
        edge=tt[j-1]
        if np.isnan(subtotal) or not np.isfinite(edge):subtotal=np.nan
        else: subtotal+=edge
        sampled.append({'timestamp_local':str(speedmat.index[k]),'corridor_branch':route,
          'origin_sample_id':ids[i],'destination_sample_id':ids[j],
          'proxy_trip_min_if_kmph':round(float(subtotal),6) if np.isfinite(subtotal) else None,
          'data_complete_on_chain':bool(np.isfinite(subtotal)),
          'result_class':'UNCERTIFIED_POINT_CHAIN_PROXY_NOT_REAL_OD'})
tt=pd.concat(all_t,ignore_index=True)
tt.to_csv(OUT/'E02_4_point_chains_hourly_PROXY.csv',index=False)
pd.DataFrame(sampled).to_csv(OUT/'E02_08_12_17_20_sample_pairs_PROXY.csv.gz',compression='gzip',index=False)
summary=tt.groupby('corridor_branch').agg(hours=('timestamp_local','size'),hours_valid=('full_path_speed_data_present','sum'),length_km=('geometric_polyline_km','first'),geometric_proxy_p50_min=('geometric_proxy_travel_min_if_unit_kmph','median'),geometric_proxy_p95_min=('geometric_proxy_travel_min_if_unit_kmph',lambda x:x.quantile(.95))).reset_index()
summary.to_csv(OUT/'E02_branch_QA_summary.csv',index=False)
# prohibit output called REAL OD: inventory and gating
rules=[
 ('E01 node IDs', 'PASS', '345 exactly, unmodified speed values, derived weekday only'),
 ('E01 time', 'PASS', 'UTC+08 input timestamps, no duplicate node-hour, corrected weekday'),
 ('E01 September weekday', 'DERIVED_CORRECTION', 'Source error present, corrected derivative; source untouched'),
 ('E01 source regime equivalence', 'UNVERIFIED', 'Sep 19 columns, 100% non-null speeds, long constant speed runs; audit collector'),
 ('E01 speed unit', 'CONDITIONAL_KMPH', 'TomTom default kmph per official docs; exact acquisition call not archived'),
 ('E02 coordinate sampled points', 'PASS', '46 G1 points from frozen registry'),
 ('E02 sample-to-sample geometry', 'GEOMETRIC_ONLY', 'geodesic successive sample chord; not road geometry'),
 ('E02 OSM/topological road edges', 'MISSING', 'No turn restrictions, lane direction, road connections or street lengths supplied'),
 ('E02 land-side jurisdiction', 'UNVERIFIED', 'Cross-border R1/R2 registry includes segments potentially beyond Malaysia'),
 ('E02 true delivery OD', 'MISSING', 'No verified depot/consumer points and last-meter entry handling'),
 ('E02 real door-to-door TT', 'BLOCKED', 'Cannot truthfully label proxy path travel times as real'),
]
pd.DataFrame(rules,columns=['check','state','evidence']).to_csv(OUT/'QA_Gates_and_Blocked_Claims.csv',index=False)
# machine audit
report={'E01_records':sum(a['rows'] for a in mon),'E01_345_nodes':len(r),'E01_months':mon,
 'speed_totals':{'positive':sum(a['valid_positive'] for a in mon),'missing':sum(a['missing'] for a in mon),'nonpositive':sum(a['nonpositive'] for a in mon)},
 'speed_unit_source':'TomTom API default kmph; acquisition unit NOT directly proven',
 'E02_sample_chains':{k:len(v) for k,v in chains.items()},'E02_line_count':len(links),'E02_isolated_G1_nodes':extras.node_id.tolist(),
 'E02_end_to_end_hourly_proxy_rows':len(tt),'E02_sample_pair_proxy_rows':len(sampled),
 'E02_QA_summary':summary.to_dict(orient='records'),
 'status':'E01 derived weekday fix complete; speed-source consistency not passed; E02 not completed as true routed OD'}
(OUT/'machine_audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print('RESULT',json.dumps({k:report[k] for k in ['speed_totals','E02_sample_chains','E02_line_count','E02_end_to_end_hourly_proxy_rows','E02_sample_pair_proxy_rows']},ensure_ascii=False))
