import pathlib,csv,json,hashlib,zipfile,math
import pandas as pd
from artifact_tool import Workbook,SpreadsheetFile
from pyproj import Geod
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=pathlib.Path('/mnt/data/JB_CIQ_E01_E02_V4_3');B=pathlib.Path('/mnt/data')
raw=json.loads((D/'machine_audit.json').read_text()); qa=json.loads((D/'independent_logic_QA.json').read_text())
months=pd.read_csv(D/'E01_monthly_QA.csv')
groups=pd.read_csv(D/'E01_final_GroupMonth.csv')
branches=pd.read_csv(D/'E02_branch_QA_summary.csv')
gates=pd.read_csv(D/'QA_Gates_and_Blocked_Claims.csv')
links=pd.read_csv(D/'E02_sample_chain_geometry_NOT_OSM_edges.csv')
# GIS layer for investigating point sequences. It is not a navigable road network.
features=[]
for r in links.itertuples(index=False):
 features.append({'type':'Feature','properties':{'corridor':r.corridor,'sample_branch':r.sample_branch,'from_sample':r.from_sample,'to_sample':r.to_sample,'geodesic_m':r.beeline_m,'mapping_evidence':r.name_evidence_flag,'physical_road_edge':False,'direction_legality_verified':False,'status':'GEOMETRIC_OBSERVATION_CHAIN_ONLY'},'geometry':{'type':'LineString','coordinates':[[r.from_lon,r.from_lat],[r.to_lon,r.to_lat]]}})
(D/'E02_GIS_POINT_CHAIN_NOT_ROAD_NETWORK.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False,indent=2))
# Static geometry QA map
fig,axs=plt.subplots(1,2,figsize=(13,6))
for ax,route in zip(axs,['R1','R2']):
 for branch,df in links[links.corridor==route].groupby('sample_branch'):
  x=[df.iloc[0].from_lon]+df.to_lon.tolist();y=[df.iloc[0].from_lat]+df.to_lat.tolist()
  ax.plot(x,y,marker='o',markersize=4,label=f'{branch} sampling sequence')
  for row in df.itertuples():
   if row.name_evidence_flag=='REJECTED_OR_UNMATCHED':ax.scatter([row.to_lon],[row.to_lat],marker='x',s=35)
 ax.set_title(f'{route} – sampled location chain (NOT verified road edges)')
 ax.set_xlabel('Longitude (WGS84)');ax.set_ylabel('Latitude (WGS84)');ax.legend(loc='best',fontsize=8);ax.grid(alpha=.2);ax.set_aspect('equal',adjustable='datalim')
fig.suptitle('E02 diagnostic map: geodesic chords between FCD points, not road topology',fontsize=12)
fig.tight_layout();fig.savefig(D/'E02_sampled_geometry_QA.png',dpi=175,bbox_inches='tight');plt.close(fig)

# Workbook: create small structured audit sheets, not a 1.26M-row Excel dump.
w=Workbook.create()
for name, frame in [
 ('E01_Months',months),('E01_GroupMonth',groups),('E02_ChainSummary',branches),
 ('E02_ChainLinks',links[['corridor','sample_branch','from_sample','to_sample','beeline_m','name_evidence_flag','road_geometry_verified','direction_verification']]),
 ('QA_Gates',gates),('Independent_QA',pd.read_csv(D/'independent_logic_QA.csv')),
 ('Source_Hashes',pd.read_csv(D/'E01_source_SHA256.csv'))]:
 sheet=w.worksheets.add(name)
 arr=[frame.columns.tolist()]+frame.astype(object).where(pd.notna(frame),None).values.tolist()
 # bool/numpy => native values
 arr=[[x.item() if hasattr(x,'item') else x for x in row] for row in arr]
 sheet.get_range_by_indexes(0,0,len(arr),len(arr[0])).values=arr
 sheet.get_range_by_indexes(0,0,1,len(arr[0])).format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF'},'row_height':28}
 sheet.freeze_panes.freeze_rows(1)
 sheet.get_range_by_indexes(0,0,len(arr),len(arr[0])).format.row_height=21
 for col in range(len(arr[0])):
  sh=sheet.get_range_by_indexes(0,col,len(arr),1)
  sh.format.column_width=33 if name=='QA_Gates' and col==2 else (45 if col==0 and name=='Source_Hashes' else (21 if col else 18))
# overview matrix
s=w.worksheets.add('00_Overview')
over=[['Project','JB CIQ E01/E02 independent traffic validation V4.3'],
 ['Period','2026-05-01 to 2026-09-30 | MYT UTC+08'],
 ['Unit', 'TomTom default kmph, ORIGINAL ACQUISITION PARAMETER UNVERIFIED'],
 ['E01 corrected derivative','PASS: row, speed, group, clock check; raw files immutable'],
 ['E01 collection comparability','HOLD: September 100% non-null and long constants require provenance audit'],
 ['E02 exploratory sampled chains','4 chains, 41 beeline links (NO verified road edges)'],
 ['E02 true directional road network','BLOCKED: routable OSM geometry, turn/direction constraints missing'],
 ['E02 real door-to-door OD','BLOCKED: verified depot, customers, road access and routing missing'],
 ['Calendar mismatch repaired',215280],
 ['Positive speed observations',1141555],
 ['No-speed observations',125230],
 ['Nonpositive speed observations',55],
 ['September provenance','source has 19 columns vs 28 in May-Aug; no documented regeneration method'],
 ['Scope note','E02 durations in separate files are geometry-only proxy, not truck OD estimates'],
 ['Reproducibility','rebuild_and_verify.py + independent_second_pass.py; SHA256 supplied']]
s.get_range_by_indexes(0,0,len(over),2).values=over
s.get_range('A1:A15').format={'fill':'#EBF2F9','font':{'bold':True}}
s.get_range('A1:A15').format.column_width=37
s.get_range('B1:B15').format.column_width=105
SpreadsheetFile.export_xlsx(w).save(str(D/'JB_CIQ_E01_E02_交通校核与路网阻塞台账_V4.3.xlsx'))

text='''# JB–CIQ E01–E02 数据处理与独立逻辑核验报告 V4.3

## 结论（不得越级解释）

- **E01：按数据处理技术口径完成。** 已生成未插补、保留速度数值、修正星期/周末派生字段的 345 节点 × 153 天数据表；独立逐行对账通过。
- **E01 数据来源同质性：尚未通过正式冻结。** 2026-09 共有 19 列，5–8月为28列；9月100%速度字段非空，存在跨多日连续恒速现象，必须审查9月生成规则。
- **速度单位：仅能暂定 km/h，不能宣称已经从原始采集脚本验证。** TomTom Traffic Flow Segment Data 默认 `kmph`，但原 CSV 未保存 `unit` 参数。原始采集请求日志/API 参数记录仍需核对；校验前不能把 E02 代理时间作为正式定量结果。
- **E02：仅完成可复算的交通观测点几何代理计算，真实路网/真实 OD 不满足验收门槛。** 当前文件没有连通的、具备道路单行线与转向限制的**有向道路边拓扑**；也没有已验证的仓库/交接站/客户门到门 OD。不存在科学依据直接宣称已经生成真实车辆 OD 矩阵。

## E01 已执行的更正

1. 从 `hour_start_time` 解析 UTC+08:00 时间；**不采用原始 `weekday` 作为可靠字段**。
2. 生成 `weekday_derived_Mon1_Sun7`（周一=1，周日=7）和 `is_weekend_derived`；9月共 215,280 条与原字段不一致的记录得到派生更正，其他月份无不一致。
3. 速度原始数值保留；非空正速度、空缺、非正速度分别标记，不插补、不平滑、不因恒速异常自动删除。
4. 通过正式冻结的 `Node_Registry_345_Grouped.csv` 精确匹配所有345节点与 G1–G5；5个月共1,266,840条，无丢失/重复。
5. 原始五个月 CSV **未被覆盖**；所有处理结果另存，并保留各文件SHA256。

## 复算结果

| 月份 | 总行数 | 正速度 | 空缺 | 非正速度 | 星期不一致 |
|---|---:|---:|---:|---:|---:|
'''
for x in raw['E01_months']:
 text+=f"| 2026-{x['month']:02d} | {x['rows']:,} | {x['valid_positive']:,} | {x['missing']:,} | {x['nonpositive']:,} | {x['weekday_mismatch']:,} |\n"
text+='''
## E02 几何代理如何计算（不可写成真实路网）

1. 仅将G1中可由ID解析的观测链分成R1A、R1B、R2A、R2B四个顺序。R2中`RA206`无法可靠归入任一A/B序列，单列在未连通清单中，不强行插入。
2. 观测点相邻距离是WGS84大地线距离；这只为真实道路路径长度提供几何参考，**不是实际道路边长**。
3. 仅当两个端点有正观测速度时计算相邻段代理耗时（暂假定 km/h）：

   `t_proxy_minutes = 60 × (distance_km / 2) × (1/v_start + 1/v_end)`

   此法使用端点速度的调和平均数。结果是**代理估计**，并非真实耗时的严格上下界，因为观测段长、速度代表性和通关等待时间均未知。
4. 每条样本链计算3672个小时的端点到端点代理结果；另外针对预设08:00、12:00、17:00和20:00输出点对代理矩阵。不可将跨链或跨国点对当成已知连通。
5. 路段实际单行/双行、路口转弯、桥梁匝道、CIQ等待、道路拓扑、国境位置均**尚未验证**。所以不得用于RQ2门到门节时结论，也不得用于碳排放/车辆里程比较。

| 点序列 | 节点数 | 相邻直线段数 | 抽样折线长 km | 3672小时中可计算小时 | 代理耗时中位数 min |
|---|---:|---:|---:|---:|---:|
'''
for a,vr in zip(['R1A','R1B','R2A','R2B'],branches.to_dict(orient='records')):
 text+=f"| {vr['corridor_branch']} | {len(raw['E02_sample_chains'] and []) if False else raw['E02_sample_chains'][vr['corridor_branch']]} | {raw['E02_sample_chains'][vr['corridor_branch']]-1} | {vr['length_km']:.3f} | {int(vr['hours_valid'])} | {vr['geometric_proxy_p50_min']:.2f} |\n"
text+='''
## 第二轮独立核验（不是沿用第一次汇总）

独立复读五份原始CSV，逐行比对修正版的节点ID、原始速度（绝对误差≤1e-6）、来源冻结分组及从时间戳推算的星期：

- **1,266,840条全量逐行比对：关键字段不一致数全部为0。**
- **全部41个相邻样本点几何段长度>0。**
- **全部14,688条点序列小时代理记录符合正值、缺失传播规则。**
- 41条连接中**14条涉及至少一端道路名称匹配证据`REJECTED`/`UNMATCHED`**，故不能视为可信、合法的可通行道路边。
- 这些成功项只证明**数据处理和计算程序的逻辑一致**，不证明外部道路拓扑、真实路段旅行时间或商业交通产品准确性。

## 正式E02的必要补充资料与验收条件

1. 取得带 `way_id / directed_from / directed_to / line_geometry / length_m / highway / oneway / access / turn_restriction` 的 Johor 地区可路由道路矢量层（例如经归档的OpenStreetMap PBF），注明采集日期、许可证及版本。
2. 将345个FCD查询点匹配至道路边，保存匹配距离、路名、方向及不确定性；对曾被列为 `REJECTED/UNMATCHED` 的点逐项处理，不能默默放行。
3. 只使用经证实位于马来西亚侧的候选仓储、微型站点和实际配送接收点；每个OD应具备 `origin_id, destination_id, location, access_point, task_type, release_time`。
4. 在同一小时的有向路网计算最短行车时间，保留道路长度、每条边使用的交通速度来源、未观测边的处理方法、行程时间与等待/停车/清关时间的独立成分。
5. 以可独立查证的历史导航旅行时间或现场样本复核模型误差；未经校准的GIS估算需标注为基于观测驱动的估计，不得称现场实测。
6. 冻结输入后一次性生成5个月OD时间矩阵与交通逻辑检查表，再进入RQ2无人机比较。不得依据想要的节时结果改变OD或接入边。

## 气象与无人机实验接口

E01修正后的 `node_id / timestamp_local / group_id / observed_speed_raw` 可直接按时间戳与已冻结的12个 GPM网格、ERA5风点映射连接。**E02未达标之前，不进入门到门无人机节时、净碳排放和经济收益实验**。

## 来源与边界

- 用户上传：5份2026年5—9月 `PROVISIONAL_FCD` CSV；345节点正式冻结表、道路分组和对应文稿。
- TomTom 官方文档（API默认单位；并非采集参数直接证据）：https://docs.tomtom.com/traffic-api/documentation/tomtom-maps/v1/traffic-flow/flow-segment-data
- 路网后续可选获取源：Geofabrik OSM https://download.geofabrik.de/asia/malaysia-singapore-brunei.html （本轮**没有成功取得可路由道路数据**，不能将其归入已处理输入）。
'''
(D/'README_交通审查结论_V4.3.md').write_text(text,encoding='utf-8')
# Sources + derived output manifest (self manifest not included)
rows=[]
for file in sorted(D.rglob('*')):
 if file.is_file() and file.name not in ['SHA256_manifest.csv']:
  h=hashlib.sha256(file.read_bytes()).hexdigest()
  rows.append([file.name,file.stat().st_size,h])
with open(D/'SHA256_manifest.csv','w',newline='',encoding='utf-8') as f:
 o=csv.writer(f);o.writerow(['filename','bytes','sha256']);o.writerows(rows)
arc=B/'JB_CIQ_E01_E02_交通校核与路网可用性审查_V4.3_完整归档.zip'
with zipfile.ZipFile(arc,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for file in sorted(D.rglob('*')):
  if file.is_file():z.write(file,arcname='JB_CIQ_E01_E02_V4_3/'+file.name)
with zipfile.ZipFile(arc) as z:
 bad=z.testzip(); assert bad is None,bad
print('EXPORTED',arc,arc.stat().st_size)
print('README',D/'README_交通审查结论_V4.3.md')
print('XLSX',D/'JB_CIQ_E01_E02_交通校核与路网阻塞台账_V4.3.xlsx')
