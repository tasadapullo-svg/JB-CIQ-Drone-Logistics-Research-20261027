import pathlib,pandas as pd,numpy as np,json,hashlib
D=pathlib.Path('/mnt/data/JB_CIQ_E01_E02_V4_3');B=pathlib.Path('/mnt/data')
p=D/'E01_traffic_calendar_corrected_345nodes_2026_05-09.csv.gz'
results=[]; n=0; speederr=0; keyerr=0; calerr=0; groperr=0
reg=pd.read_csv(B/'JB_FCD_G1-G5_2026_05-09/Node_Registry_345_Grouped.csv',encoding='utf-8-sig').set_index('node_id')
# Each source month is ordered, exactly as in corrected file. independent chunk comparisons.
generator=pd.read_csv(p,compression='gzip',chunksize=30000)
buffer=pd.DataFrame()
for m in range(5,10):
    raw=B/f'PROVISIONAL_FCD_JB_2026_{m:02d}_345NODE_ANALYSIS_V1.csv'
    for original in pd.read_csv(raw,chunksize=30000,low_memory=False):
        while len(buffer)<len(original):
            buffer=pd.concat([buffer,next(generator)],ignore_index=True)
        v=buffer.iloc[:len(original)].copy()
        buffer=buffer.iloc[len(original):].reset_index(drop=True)
        ts=pd.to_datetime(original.hour_start_time,utc=True).dt.tz_convert('Asia/Kuala_Lumpur')
        a=pd.to_numeric(original.observed_hourly_speed,errors='coerce').to_numpy(float)
        b=pd.to_numeric(v.observed_speed_raw,errors='coerce').to_numpy(float)
        ok=(np.isnan(a)&np.isnan(b)) | np.isclose(a,b,rtol=0,atol=1e-6,equal_nan=True)
        speederr+=int((~ok).sum())
        keyerr+=int((original.node_key.to_numpy()!=v.node_id.to_numpy()).sum())
        calerr+=int((ts.dt.dayofweek.to_numpy()+1!=v.weekday_derived_Mon1_Sun7.to_numpy()).sum())
        groperr+=int((v.group_id.to_numpy()!=v.node_id.map(reg.group_id).to_numpy()).sum())
        n+=len(v)
try:
    next(generator)
    extra=True
except StopIteration:
    extra=(len(buffer)>0)
ln=pd.read_csv(D/'E02_sample_chain_geometry_NOT_OSM_edges.csv')
tt=pd.read_csv(D/'E02_4_point_chains_hourly_PROXY.csv')
valid=tt['full_path_speed_data_present'].astype(bool)
probs={
 'E01_rowcount_matches':n==1266840,
 'E01_no_extra_rows':not extra,
 'E01_node_key_integrity':keyerr==0,
 'E01_speed_numeric_equality_at_1e_minus_6':speederr==0,
 'E01_derived_calendar_all_rows':calerr==0,
 'E01_group_consistency':groperr==0,
 'E02_geodesic_positive_length':bool(ln.beeline_m.gt(0).all()),
 'E02_hourly_proxy_rowcount':len(tt)==4*3672,
 'E02_proxy_nonnegative_on_complete_rows':bool(tt.loc[valid,'geometric_proxy_travel_min_if_unit_kmph'].gt(0).all()),
 'E02_proxy_missing_on_incomplete_rows':bool(tt.loc[~valid,'geometric_proxy_travel_min_if_unit_kmph'].isna().all()),
 'E02_directed_road_network_source_present':False,
 'E02_true_real_delivery_OD_present':False,
}
obj={'audit_version':'independent E01/E02 second-pass','rowcount':n,'key_mismatch':keyerr,'speed_mismatch':speederr,'calendar_mismatch':calerr,'group_mismatch':groperr,'checks':probs,'e02_links_flagged_mapping':int(ln.name_evidence_flag.eq('REJECTED_OR_UNMATCHED').sum()),'note':'The E02 proxy cannot pass real network/OD acceptance without routable geometry and delivery OD.'}
(D/'independent_logic_QA.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
pd.DataFrame([{'check':k,'passed':v} for k,v in probs.items()]).to_csv(D/'independent_logic_QA.csv',index=False)
assert all(list(probs.values())[:10]),obj
print(json.dumps(obj,ensure_ascii=False,indent=2))
