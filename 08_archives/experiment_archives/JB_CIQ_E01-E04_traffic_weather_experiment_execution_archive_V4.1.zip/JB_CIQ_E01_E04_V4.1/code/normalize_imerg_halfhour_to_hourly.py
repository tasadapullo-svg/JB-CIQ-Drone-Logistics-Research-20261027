#!/usr/bin/env python3
"""Convert an authentic, version-frozen NASA IMERG 12-grid V07B Late extraction.
Input data must already be downloaded from official NASA and sampled at frozen grid centroids.
No NASA product is downloaded by this script. It refuses missing/duplicate half-hours.
"""
import csv,collections,datetime,pathlib,sys,math
ROOT=pathlib.Path(__file__).resolve().parents[1]
W=ROOT/'weather';DIR=W/'source_raw_IMERG';DIR.mkdir(exist_ok=True)
source=DIR/'NASA_IMERG_LateV07B_12grid_halfhour_raw.csv'
out=DIR/'NASA_IMERG_LateV07B_12grid_hourly_verified.csv'
if not source.exists():sys.exit('STOP: authentic IMERG 12-grid 30min source CSV is missing. No fake rain generated.')
ids={r['gpm_grid_id'] for r in csv.DictReader((W/'02_12_GPM_grid_centroids_FCD_occupied.csv').open(encoding='utf-8-sig'))}
seen=set(); groups=collections.defaultdict(list)
loc=datetime.timezone(datetime.timedelta(hours=8))
with source.open(encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):
  gid=r['gpm_grid_id'];prod=r['source_product_run'];t=datetime.datetime.fromisoformat(r['timestamp_utc'].replace('Z','+00:00'))
  if gid not in ids or prod!='NASA_IMERG_V07B_LATE' or t.utcoffset()!=datetime.timedelta(0):sys.exit('STOP: unknown grid/run/tz')
  tt=t.astimezone(loc)
  if tt.minute not in (0,30) or tt.second!=0:sys.exit('STOP: not a 30-minute granule at hour boundary')
  rate=float(r['precipitation_rate_mm_h'])
  if not math.isfinite(rate) or rate<0:sys.exit('STOP: invalid precipitation rate (no auto-fill)')
  localhour=tt.replace(minute=0,second=0,microsecond=0)
  key=(gid,localhour.isoformat()); slot=(key,tt.minute)
  if slot in seen:sys.exit('STOP: duplicate half-hour grid record')
  seen.add(slot);groups[key].append(rate)
if len(seen)!=12*3672*2:sys.exit(f'STOP: need 88,128 30min observations, only {len(seen)}')
if len(groups)!=12*3672 or any(len(v)!=2 for v in groups.values()):sys.exit('STOP: grid-hour missing one half-hour')
with out.open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.writer(f);writer.writerow(['gpm_grid_id','timestamp_local','rain_hour_mm','source_product_run'])
 for (gid,ts),rates in sorted(groups.items()):
  if not ('2026-05-01T00:00:00+08:00'<=ts<='2026-09-30T23:00:00+08:00'):sys.exit('STOP: out of local study window')
  writer.writerow([gid,ts,round(sum(x*0.5 for x in rates),6),'NASA_IMERG_V07B_LATE'])
print('PASS: 44,064 grid-local-hour rainfall values; authentic 30min source validated')
