import pathlib,hashlib,csv,zipfile,json,datetime
P=pathlib.Path('/mnt/data/JB_CIQ_E01_E04_V4_1')
P.mkdir(exist_ok=True)
files=sorted([p for p in P.rglob('*') if p.is_file() and p.name not in ('test_container','99_generated_file_SHA256_manifest.csv')])
with (P/'protocol/99_generated_file_SHA256_manifest.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['relative_path','size_bytes','sha256','status'])
 for p in files:
  h=hashlib.sha256()
  with p.open('rb') as inp:
   for c in iter(lambda:inp.read(2**20),b''):h.update(c)
  w.writerow([str(p.relative_to(P)),p.stat().st_size,h.hexdigest(),'GENERATED_OR_ARCHIVED'])
F=pathlib.Path('/mnt/data/JB_CIQ_E01_E04_交通气象实验执行与留档_V4.1.zip')
with zipfile.ZipFile(F,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(P.rglob('*')):
  if p.is_file() and p.name!='test_container':z.write(p,arcname='JB_CIQ_E01_E04_V4.1/'+str(p.relative_to(P)))
 prior=pathlib.Path('/mnt/data/JB_FCD_345nodes_G1-G5_Grouped_2026_05-09.zip')
 if prior.exists():z.write(prior,arcname='JB_CIQ_E01_E04_V4.1/reference_prior_grouped_source/JB_FCD_345nodes_G1-G5_Grouped_2026_05-09.zip',compress_type=zipfile.ZIP_STORED)
with zipfile.ZipFile(F) as z:
 status=z.testzip()
 print('zip',F,'MB',round(F.stat().st_size/1024**2,2),'numfiles',len(z.namelist()),'integrity',status)
 print('sizes',[(p.name,p.stat().st_size) for p in files if p.suffix in ('.xlsx','.png')])
