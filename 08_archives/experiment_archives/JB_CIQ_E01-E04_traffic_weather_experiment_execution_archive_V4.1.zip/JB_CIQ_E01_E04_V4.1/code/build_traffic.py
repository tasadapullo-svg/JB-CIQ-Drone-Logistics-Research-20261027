#!/usr/bin/env python3
"""Speed/time/location-only, exact frozen 345-node FCD pipeline, 2026-05..09.
No imputation; no inference of segment travel times; no QC columns relied on.
"""
import csv, os, math, json, hashlib, collections, datetime, statistics
from pathlib import Path
ROOT=Path(os.environ.get('CIQ_INPUT_DIR','/mnt/data'))
OUT=Path(__file__).resolve().parents[1]/'traffic'; OUT.mkdir(parents=True,exist_ok=True)
REG=ROOT/'JB_FCD_G1-G5_2026_05-09'/'Node_Registry_345_Grouped.csv'
MONTHS=range(5,10)
FILES=[ROOT/f'PROVISIONAL_FCD_JB_2026_{m:02}_345NODE_ANALYSIS_V1.csv' for m in MONTHS]

def save(name, header, rows):
  with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(header);w.writerows(rows)
def acc():return [0,0,0.0,0.0,float('inf'),float('-inf')]
def add(a,spd):
  a[0]+=1
  if spd is not None:
    a[1]+=1;a[2]+=spd;a[3]+=spd*spd;a[4]=min(a[4],spd);a[5]=max(a[5],spd)
def calc(a):return (a[0],a[1],a[0]-a[1],round(a[1]/a[0],6) if a[0] else None,round(a[2]/a[1],4) if a[1] else None,round(math.sqrt(max(0.,a[3]/a[1]-(a[2]/a[1])**2)),4) if a[1] else None,round(a[4],3) if a[1] else None,round(a[5],3) if a[1] else None)
REGISTRY={r['node_id']:r for r in csv.DictReader(REG.open(encoding='utf-8-sig',newline=''))}
assert len(REGISTRY)==345
node_speeds=collections.defaultdict(list)
node_counts=collections.defaultdict(acc)
gm=collections.defaultdict(acc); rm=collections.defaultdict(acc); rmh=collections.defaultdict(acc); rh=collections.defaultdict(acc); rt=collections.defaultdict(acc); rd=collections.defaultdict(acc)
error_records=collections.Counter(); seen=set(); sources=[]
for mon,file in zip(MONTHS,FILES):
  hashv=hashlib.sha256()
  with file.open('rb') as fh:
    for b in iter(lambda:fh.read(2**20),b''):hashv.update(b)
  n=0
  with file.open(encoding='utf-8-sig',newline='') as fh:
    reader=csv.DictReader(fh); columns=list(reader.fieldnames)
    for r in reader:
      n+=1
      node=r['node_key']; group=REGISTRY.get(node)
      if group is None: error_records['unmatched_node']+=1;continue
      if (r.get('route_code')!=group['source_route_code'] and not (group['source_route_code'] in ('RA','RB') and r.get('route_code')==node and node.startswith(group['source_route_code']))): error_records['route_code_conflict']+=1
      ts=r['hour_start_time'];key=(node,ts)
      if key in seen:error_records['duplicate_node_hour']+=1
      seen.add(key)
      if ts[:7]!=f'2026-{mon:02}':error_records['timestamp_month_mismatch']+=1
      if not ts.endswith('+08:00'): error_records['timezone_mismatch']+=1
      if ts[11:13]!=str(int(r['local_hour'])).zfill(2):error_records['hour_mismatch']+=1
      raw=r.get('observed_hourly_speed','')
      spd=None
      if raw.strip() not in ('','\\N','NaN','nan','null','NULL'):
        try:
          val=float(raw)
          if math.isfinite(val) and val>0: spd=val
          else:error_records['nonpositive_or_nonfinite_speed']+=1
        except ValueError:error_records['unparseable_speed']+=1
      else:error_records['empty_speed']+=1
      k=group['group_id'];route=group['source_route_code']; m=f'2026-{mon:02}';hr=int(ts[11:13]);date=ts[:10]
      add(node_counts[node],spd);add(gm[(k,m)],spd)
      if k=='G1' and route in ('R1','R2'):
        add(rm[(route,m)],spd);add(rmh[(route,m,hr)],spd);add(rh[(route,hr)],spd);add(rt[(route,ts)],spd);add(rd[(route,date)],spd)
      if spd is not None:node_speeds[node].append(spd)
  sources.append([file.name,mon,n,len(columns),hashv.hexdigest(),','.join(columns)])
expected=153*24
assert len(seen)==len(REGISTRY)*expected,(len(seen),len(REGISTRY)*expected)
assert not error_records.get('unmatched_node') and not error_records.get('duplicate_node_hour')
node_p90={}
for id,vals in node_speeds.items():
  if len(vals):
    vals.sort();index=0.9*(len(vals)-1);lo=int(index); hi=min(lo+1,len(vals)-1)
    node_p90[id]=vals[lo]+(vals[hi]-vals[lo])*(index-lo)

save('00_original_input_SHA256.csv',['source_filename','month','rows','columns','sha256','original_column_names'],sources)
save('01_frozen_node_registry_345.csv',['node_id','G_group','source_route_code','road_name','latitude','longitude','n_hour','n_nonnull','n_null','speed_nonnull_fraction','mean_speed_raw','std_speed_raw','p90_node_reference_raw'],
 ([id,r['group_id'],r['source_route_code'],r['formal_road_or_segment_name'],r['latitude'],r['longitude'],calc(node_counts[id])[0],calc(node_counts[id])[1],calc(node_counts[id])[2],calc(node_counts[id])[3],calc(node_counts[id])[4],calc(node_counts[id])[5],round(node_p90.get(id,0),4) if id in node_p90 else None] for id,r in sorted(REGISTRY.items())))
hdr=['segment','month','n_node_hours','n_speed','n_missing','nonmissing_fraction','mean_speed_raw','std_speed_raw','min_speed_raw','max_speed_raw']
save('02_G1_G5_monthly_speed.csv',['G_group']+hdr[1:],([g,m,*calc(a)] for (g,m),a in sorted(gm.items())))
save('03_G1_R1_R2_monthly_speed.csv',hdr,([route,m,*calc(a)] for (route,m),a in sorted(rm.items())))
save('04_G1_R1_R2_month_hour.csv',['route','month','hour_local',*hdr[2:]],([route,m,h,*calc(a)] for (route,m,h),a in sorted(rmh.items())))
save('05_G1_R1_R2_hour_of_day.csv',['route','hour_local',*hdr[2:]],([route,h,*calc(a)] for (route,h),a in sorted(rh.items())))
save('06_G1_R1_R2_hourly_timeseries.csv',['route','timestamp_local',*hdr[2:]],([route,ts,*calc(a)] for (route,ts),a in sorted(rt.items())))
save('07_G1_R1_R2_daily_speed.csv',['route','date_local',*hdr[2:]],([route,day,*calc(a)] for (route,day),a in sorted(rd.items())))
# Empirical speed index, node-normalized to its own observed 90th percentile: NOT free-flow or route travel time.
norm=collections.defaultdict(acc)
for mon,file in zip(MONTHS,FILES):
  with file.open(encoding='utf-8-sig',newline='') as fh:
    for r in csv.DictReader(fh):
      node=r['node_key']; rec=REGISTRY[node]; route=rec['source_route_code']
      if rec['group_id']!='G1' or route not in ('R1','R2'):continue
      ts=r['hour_start_time'];raw=r.get('observed_hourly_speed','')
      spd=None
      if raw.strip() not in ('','\\N','NaN','nan','null','NULL'):
        try:
          v=float(raw); ref=node_p90.get(node)
          if math.isfinite(v) and v>0 and ref and ref>0:spd=v/ref
        except ValueError:pass
      add(norm[(route,ts[:7],int(ts[11:13]))],spd)
save('08_R1_R2_month_hour_empirical_speed_index.csv',['route','month','hour_local','n_node_hours','n_valid_index','n_missing_index','valid_fraction','mean_ratio_to_node_observed_P90','std_ratio','min_ratio','max_ratio'],
 ([route,m,h,*calc(a)] for (route,m,h),a in sorted(norm.items())))
save('09_G1_CIQ_point_geography_review.csv',['node_id','route','latitude','longitude','jurisdiction_verified','use_for_MY_air_network','review_reason'],
 ([id,r['source_route_code'],r['latitude'],r['longitude'],'NO','NO','Route includes border interface; coastline/jurisdiction spatial overlay required'] for id,r in REGISTRY.items() if r['group_id']=='G1'))
checks=[('expected_nodes',len(REGISTRY),'345'),('calendar_hourly_slots',expected,'3672'),('expected_node_hour_records',len(REGISTRY)*expected,'1266840'),('actual_unique_node_hour_records',len(seen),'1266840'),('G1_R1_nodes',sum(r['source_route_code']=='R1' for r in REGISTRY.values()),'24'),('G1_R2_nodes',sum(r['source_route_code']=='R2' for r in REGISTRY.values()),'22'),('speed_units','UNVERIFIED','TomTom parameter audit required'),('9_sep_speed_nonnull',calc(gm[('G1','2026-09')])[3],'Potentially different aggregation/provisional; no QC used per scope')]
checks +=[(key,num,'review') for key,num in sorted(error_records.items())]
save('10_audit_checks.csv',['item','value','expectation_or_note'],checks)
report={'study_start':'2026-05-01','study_end':'2026-09-30','n_nodes':len(REGISTRY),'n_unique_node_hour':len(seen),'errors':dict(error_records),'source_list':sources,'group_month':{f'{g}/{m}':calc(a) for (g,m),a in gm.items()},'G1_route_month':{f'{r}/{m}':calc(a) for (r,m),a in rm.items()},'G1_route_hour_minmax':{r:{'min_mean_hour':min(((h,calc(a)[4]) for (rr,h),a in rh.items() if rr==r and calc(a)[4] is not None),key=lambda x:x[1]),'max_mean_hour':max(((h,calc(a)[4]) for (rr,h),a in rh.items() if rr==r and calc(a)[4] is not None),key=lambda x:x[1])} for r in ('R1','R2')},'missing_speed_counts':{f'{g}/{m}':calc(a)[2] for (g,m),a in gm.items()},'cautions':['FCD sampled-point speed is not route travel-time','Raw speed unit provenance not proved from CSV alone','Data are provisional; September all non-null speed must be distinguished from collection reliability','No MY-SG jurisdiction clipping has been done','P90 ratio is empirical within-node benchmark, not true free-flow speed']}
(OUT/'11_traffic_audit_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'n':len(seen),'error_records':report['errors'],'hour_minmax':report['G1_route_hour_minmax'],'group5_month':report['group_month']},ensure_ascii=False)[:1600])
