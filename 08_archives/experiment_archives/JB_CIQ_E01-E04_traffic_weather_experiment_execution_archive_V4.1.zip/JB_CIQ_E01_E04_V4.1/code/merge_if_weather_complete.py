#!/usr/bin/env python3
"""E04 gatekeeper. Aborts without full 6-anchor ERA5 & 12-grid NASA hourly rainfall.
Does NOT treat missing weather as dry or safe. Outputs node-hour matched CSV only after both pass.
The normalized NASA input must be a separate authentic export verified by its source manifest.
"""
import csv,json,pathlib,datetime,collections,math,sys,os
ROOT=pathlib.Path(__file__).resolve().parents[1]
W=ROOT/'weather'; T=ROOT/'traffic'
raw=W/'source_raw_era5_openmeteo'
manifest=W/'06_weather_download_attempt_manifest.json'
if not manifest.exists():sys.exit('STOP_E03: No audited model weather collection manifest.')
items=json.loads(manifest.read_text(encoding='utf-8'))
if len(items)!=6 or any(x['status']!='OK' for x in items):
  sys.exit('STOP_E03: Six hourly ERA5 model source files are not all acquired. No joint observations were generated.')
rain=W/'source_raw_IMERG'/'NASA_IMERG_LateV07B_12grid_hourly_verified.csv'
if not rain.exists():sys.exit('STOP_E03: Missing verified 12-grid NASA IMERG V07B Late hourly rainfall. No joint observations were generated.')
# Accept only verified NASA hourly accumulation: 12*3672 records.
gmap={}
for r in csv.DictReader((W/'01_345node_to_12GPM_6wind_anchor_mapping.csv').open(encoding='utf-8-sig',newline='')):gmap[r['node_id']]=r
rain_by_grid={}; expected_grids=set(r['gpm_grid_id'] for r in gmap.values())
with rain.open(encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):
  if r.get('source_product_run')!='NASA_IMERG_V07B_LATE':sys.exit('STOP: Mixed/unknown rainfall product/version')
  key=(r['gpm_grid_id'],r['timestamp_local'])
  if key in rain_by_grid:sys.exit('STOP: Duplicate grid-local-hour in NASA rainfall file.')
  if r['gpm_grid_id'] not in expected_grids:sys.exit('STOP: Unexpected GPM grid ID.')
  rain_by_grid[key]=float(r['rain_hour_mm'])
if len(rain_by_grid)!=12*3672:sys.exit(f'STOP: Expected 44,064 rainfall grid-hours, got {len(rain_by_grid)}')
wind_by_id={}
for x in items:
  data=json.loads((raw/x['raw_filename']).read_text(encoding='utf-8'))['hourly']
  for i,ts in enumerate(data['time']):
    k=(x['weather_id'],ts+':00+08:00')
    wind_by_id[k]={var:data.get(var,[None]*3672)[i] for var in ['wind_speed_10m','wind_gusts_10m','wind_direction_10m','temperature_2m','relative_humidity_2m']}
if len(wind_by_id)!=6*3672:sys.exit('STOP: Missing 6×3672 model-hour records')
head=['node_id','G_group','source_route_code','timestamp_local','observed_speed_raw','rain_hour_mm_IMERG','rain_bin','wind_speed_10m_ms_ERA5','gust_10m_ms_ERA5','wind_dir_deg_ERA5','grid_id','wind_anchor_id','weather_source_state']
output=ROOT/'E04_all_nodes_traffic_weather_matched.csv'
n=0;missing=0
with output.open('w',encoding='utf-8-sig',newline='') as w:
 writer=csv.writer(w);writer.writerow(head)
 for k in range(1,6):
  f=pathlib.Path(os.environ.get('CIQ_INPUT_DIR','/mnt/data'))/'JB_FCD_G1-G5_2026_05-09'/f'G{k}_Traffic_Node_Hour_2026_05-09.csv'
  for r in csv.DictReader(f.open(encoding='utf-8-sig',newline='')):
    m=gmap[r['node_id']];ts=r['timestamp_local']; ra=rain_by_grid.get((m['gpm_grid_id'],ts));wi=wind_by_id.get((m['nearest_wind_anchor_id'],ts))
    if ra is None or wi is None:missing+=1;continue
    bin='R0' if ra<0.1 else 'R1' if ra<1 else 'R2' if ra<5 else 'R3'
    writer.writerow([r['node_id'],r['group_id'],r['source_route_code'],ts,r['observed_speed'],ra,bin,wi['wind_speed_10m'],wi['wind_gusts_10m'],wi['wind_direction_10m'],m['gpm_grid_id'],m['nearest_wind_anchor_id'],'ACTUAL_SOURCE_JOIN_NOT_CERTIFIED_FLIGHT_SAFE'])
    n+=1
if missing or n!=1266840: output.unlink(missing_ok=True);sys.exit(f'STOP_E04: Joined {n} records but {missing} missing. No incomplete joint database will be released.')
print('SUCCESS: E04 matched node-hour rows',n)
