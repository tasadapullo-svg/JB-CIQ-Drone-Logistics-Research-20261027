#!/usr/bin/env python3
"""Freeze 12 0.1-degree grid centroids and six wind-model anchor references.
This produces sampling plan, NOT observations or NASA-derived rainfall.
"""
import csv,collections,math,urllib.parse,hashlib,json,os
from pathlib import Path
ROOT=Path('/mnt/data/JB_CIQ_E01_E04_V4_1')
DATA=Path(os.environ.get('CIQ_INPUT_DIR','/mnt/data'))
REG=DATA/'JB_FCD_G1-G5_2026_05-09/Node_Registry_345_Grouped.csv'
WX=DATA/'JB_CIQ_实验设计_V4_0/04_气象采集参考坐标_冻结FCD节点.csv'
rows=list(csv.DictReader(REG.open(encoding='utf-8-sig',newline='')))
anchors=list(csv.DictReader(WX.open(encoding='utf-8-sig',newline='')))
def hav(lat1,lon1,lat2,lon2):
  R=6371.0088
  p1,p2=math.radians(lat1),math.radians(lat2)
  a=math.sin((p2-p1)/2)**2+math.cos(p1)*math.cos(p2)*math.sin(math.radians(lon2-lon1)/2)**2
  return 2*R*math.asin(min(1,math.sqrt(a)))
def wr(name,hd,rs):
  with (ROOT/'weather'/name).open('w',newline='',encoding='utf-8-sig') as f:w=csv.writer(f);w.writerow(hd);w.writerows(rs)
map_rows=[];gcount=collections.Counter();gridmeta={}
for r in rows:
  lat,lon=float(r['latitude']),float(r['longitude'])
  g_lat=round(math.floor(lat*10)/10+0.05,3);g_lon=round(math.floor(lon*10)/10+0.05,3)
  gid=f'GPM_{g_lat:.2f}_{g_lon:.2f}'
  gcount[gid]+=1;gridmeta[gid]=(g_lat,g_lon)
  nearest=min(anchors,key=lambda a:hav(lat,lon,float(a['latitude']),float(a['longitude'])))
  dk=hav(lat,lon,float(nearest['latitude']),float(nearest['longitude']))
  map_rows.append([r['node_id'],r['group_id'],r['source_route_code'],f'{lat:.9f}',f'{lon:.9f}',gid,g_lat,g_lon,nearest['weather_id'],round(dk,3),'INDEX_ONLY_NO_OBSERVED_WEATHER'])
assert len(gridmeta)==12, ('Expected 12 occupied 0.1-degree cells',len(gridmeta))
wr('01_345node_to_12GPM_6wind_anchor_mapping.csv',['node_id','G_group','source_route_code','latitude','longitude','gpm_grid_id','grid_center_lat','grid_center_lon','nearest_wind_anchor_id','nearest_anchor_km','weather_data_state'],map_rows)
wr('02_12_GPM_grid_centroids_FCD_occupied.csv',['gpm_grid_id','center_lat','center_lon','n_FCD_nodes','rain_source','resolution','note'],
  [[gid,*gridmeta[gid],gcount[gid],'NASA GPM IMERG V07B Late','0.1 degree, 30 minute','Grid geometry derived from node coordinates; verify grid convention against NASA source'] for gid in sorted(gridmeta)])
wr('03_6_wind_model_anchors.csv',['weather_id','FCD_ref','latitude','longitude','role','type'],[[a['weather_id'],a['fcd_id'],a['latitude'],a['longitude'],a['role'],'REANALYSIS_POINT_NOT_GROUND_STATION'] for a in anchors])
urls=[]
for a in anchors:
  params={'latitude':a['latitude'],'longitude':a['longitude'],'start_date':'2026-05-01','end_date':'2026-09-30','hourly':'precipitation,rain,wind_speed_10m,wind_gusts_10m,wind_direction_10m,temperature_2m,relative_humidity_2m','models':'era5','wind_speed_unit':'ms','precipitation_unit':'mm','timezone':'Asia/Kuala_Lumpur'}
  url='https://archive-api.open-meteo.com/v1/archive?'+urllib.parse.urlencode(params)
  urls.append([a['weather_id'],url,'ERA5 through Open-Meteo','NO_DOWNLOAD_YET',3672])
wr('04_requested_archive_API_urls.csv',['wind_anchor_id','request_url','model','actual_data_status','expected_hours'],urls)
meta={'grid_count':len(gridmeta),'node_count':len(rows),'wind_anchor_count':len(anchors),'study_hours':153*24,'timestamp':'Asia/Kuala_Lumpur','rain_grid_source':'NASA IMERG V07B Late (planned, not downloaded)','wind_source':'ERA5 through Open-Meteo (planned, not downloaded)','important':'No weather data appear in this package unless separate sources are obtained and validated'}
(ROOT/'weather'/'05_sampling_design.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False),encoding='utf-8')
print(meta)
