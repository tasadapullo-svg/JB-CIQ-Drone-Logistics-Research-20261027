#!/usr/bin/env python3
"""Acquire SIX anchored hourly modeled/reanalysis weather files, with exact provenance.
Requires permitted internet connection. No silent substitution or fabricated data.
Usage: python fetch_era5_openmeteo.py --run
Without --run performs dry-run. May report FAILED if network restricted.
"""
import argparse,csv,json,pathlib,urllib.request,datetime,hashlib,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
P=ROOT/'weather'
urls=list(csv.DictReader((P/'04_requested_archive_API_urls.csv').open(encoding='utf-8-sig',newline='')))
parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true');args=parser.parse_args()
D=P/'source_raw_era5_openmeteo';D.mkdir(exist_ok=True)
manifest=[]
for row in urls:
  rec={'weather_id':row['wind_anchor_id'],'url':row['request_url'],'product':'ERA5 through Open-Meteo Historical Archive API','retrieved_at_utc':None,'sha256':None,'status':'NOT_ATTEMPTED','expected_hour_count':3672}
  if args.run:
    try:
      req=urllib.request.Request(row['request_url'],headers={'User-Agent':'CIQ-research-data-audit/1.0'})
      with urllib.request.urlopen(req,timeout=20) as resp:data=resp.read()
      obj=json.loads(data)
      if obj.get('error'):raise ValueError(obj.get('reason','API error'))
      h=obj.get('hourly',{});times=h.get('time',[])
      assert len(times)==3672,f'Expected 3672 observations got {len(times)}'
      assert times[0]=='2026-05-01T00:00' and times[-1]=='2026-09-30T23:00',(times[0],times[-1])
      for var in ['precipitation','wind_speed_10m','wind_gusts_10m','wind_direction_10m']:
        assert len(h.get(var,[]))==3672,(var,len(h.get(var,[])))
      out=D/(row['wind_anchor_id']+'.json');out.write_bytes(data)
      rec.update(status='OK',hour_count=3672,sha256=hashlib.sha256(data).hexdigest(),retrieved_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),raw_filename=out.name)
    except Exception as e:rec.update(status='FAILED',error=str(e))
  manifest.append(rec)
  (P/'06_weather_download_attempt_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
print('OK',sum(x['status']=='OK' for x in manifest),'FAILED',sum(x['status']=='FAILED' for x in manifest),'NOT_ATTEMPTED',sum(x['status']=='NOT_ATTEMPTED' for x in manifest))
