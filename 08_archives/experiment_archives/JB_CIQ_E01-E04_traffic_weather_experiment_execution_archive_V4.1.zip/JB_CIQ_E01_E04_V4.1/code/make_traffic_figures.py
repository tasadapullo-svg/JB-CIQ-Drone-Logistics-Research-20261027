import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path('/mnt/data/JB_CIQ_E01_E04_V4_1')
with (P/'traffic/05_G1_R1_R2_hour_of_day.csv').open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
plt.figure(figsize=(8.8,4.5))
for route in ['R1','R2']:
 vals=sorted([r for r in rows if r['route']==route],key=lambda x:int(x['hour_local']))
 plt.plot([int(r['hour_local']) for r in vals],[float(r['mean_speed_raw']) for r in vals],marker='o',markersize=3,label=route)
plt.xlabel('Local hour (MYT, UTC+08)');plt.ylabel('Mean sampled FCD speed (original units)');plt.title('G1 route-family hourly FCD speed profile, May-Sep 2026');plt.xticks(range(0,24,2));plt.grid(alpha=.25);plt.legend();plt.tight_layout()
plt.savefig(P/'charts/01_G1_R1_R2_hourly_speed.png',dpi=190);plt.close()
with (P/'traffic/02_G1_G5_monthly_speed.csv').open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
plt.figure(figsize=(8.8,4.5))
for g in ['G1','G2','G3','G4','G5']:
 vals=[r for r in rows if r['G_group']==g]
 plt.plot([r['month'][-2:] for r in vals],[100*float(r['nonmissing_fraction']) for r in vals],marker='o',markersize=4,label=g)
plt.ylim(75,102);plt.xlabel('2026 month');plt.ylabel('Share with positive finite speed (%)');plt.title('Monthly usable speed-field ratio by frozen road group');plt.grid(alpha=.25);plt.legend(ncol=5);plt.tight_layout()
plt.savefig(P/'charts/02_G1_G5_monthly_speed_field_completeness.png',dpi=190);plt.close()
