import csv,json,statistics,collections,math,datetime,os,zipfile,hashlib
R=json.load(open('/mnt/data/weather_analysis_data.json'))
rows=R['data'];qc=R['qc'];meta=R['meta'];nea=R['nea30'];status=R['status']
points=sorted({r['point_id'] for r in rows}); bypt={p:{r['timestamp_hour_start_sgt']:r for r in rows if r['point_id']==p} for p in points}
byptmonth=collections.defaultdict(list)
for r in rows:byptmonth[(r['month'],r['point_id'])].append(r)
numcols=['era5_wind10_ms','era5_wind100_ms','era5_dir10_deg','era5_dir100_deg','era5_gust10_ms','era5_precip_1h_mm','nasa_precip_mm_per_hour','nasa_wind10_ms']
qa=[]
for (mo,p),rr in sorted(byptmonth.items()):
 hr=31*24 if mo in ('05','07','08') else 30*24
 times=[datetime.datetime.strptime(r['timestamp_hour_start_sgt'][:19],'%Y-%m-%d %H:%M:%S') for r in rr]
 valid={k:[r.get(k) for r in rr if isinstance(r.get(k),(int,float))] for k in numcols}
 eq=all(times[i+1]-times[i]==datetime.timedelta(hours=1) for i in range(len(times)-1))
 era5p=valid['era5_precip_1h_mm']; nasa=valid['nasa_precip_mm_per_hour']; w10=valid['era5_wind10_ms'];wg=valid['era5_gust10_ms']
 qa.append({'month':mo,'point_id':p,'expected_hours':hr,'actual_rows':len(rr),'unique_timestamps':len(set(times)),'consecutive_hours':eq,'era5_rain_complete':len(era5p),'nasa_rain_complete':len(nasa),'era5_total_rain_mm_raw_label':round(sum(era5p),2),'nasa_total_rain_mm_raw_label':round(sum(nasa),2),'rain_total_ratio_nasa_to_era5':round(sum(nasa)/sum(era5p),2) if sum(era5p)>0 else None,'era5_rainy_hours_0_1mm':sum(x>=0.1 for x in era5p),'nasa_rainy_hours_0_1mm':sum(x>=0.1 for x in nasa),'era5_max_hourly_mm':round(max(era5p),2),'nasa_max_hourly_mm':round(max(nasa),2),'era5_avg_10m_wind_ms':round(statistics.mean(w10),3),'era5_max_10m_wind_ms':max(w10),'era5_max_gust_10m_ms':max(wg),'nasa_bigger_than_era5_20mm_h':sum((na-e)>20 for na,e in zip(nasa,era5p))})
# point every 4 same NASA, ERA5 same except SL_MY, count unique times
same={k:0 for k in numcols}; allhours=sorted(set(bypt[points[0]]))
for k in numcols:
 for t in allhours:
  v=[bypt[p][t].get(k) for p in points]
  if len(set(v))==1:same[k]+=1
# per point weather source classes & fields
intervalQA=[]
for r in rows:
 time=datetime.datetime.strptime(r['timestamp_hour_start_sgt'][:19],'%Y-%m-%d %H:%M:%S')
 if r['precip_interval']!=None:
  if len(intervalQA)<3:intervalQA.append({'time':r['timestamp_hour_start_sgt'],'interval':r['precip_interval'],'era5_rain':r['era5_precip_1h_mm'],'nasa':r['nasa_precip_mm_per_hour']})

# check qc csv against sheet and cross-source all physical constraints
flg=[]
for x in qa:
 if x['actual_rows']!=x['expected_hours'] or x['unique_timestamps']!=x['expected_hours'] or not x['consecutive_hours']:flg.append(('timestamp',x['month'],x['point_id']))
 if x['nasa_total_rain_mm_raw_label']>2000:flg.append(('nasa_rain',x['month'],x['point_id']))
qcfilematch=[]
for mon in ('05','06','07','08','09'):
 qq=list(csv.DictReader(open('/mnt/data/JB_SG_Weather_2026_'+mon+'.qc.csv',encoding='utf-8-sig')))
 keys=lambda d:(d['point_id'],d['source'],d['variable'])
 csvdict={keys(q):q for q in qq}; sheetdict={keys(q):q for q in qc if q['month']==mon}
 dis=[]
 for k,x in csvdict.items():
  y=sheetdict.get(k)
  if not y:dis.append((k,'missing'))
  elif any(str(x[a])!=str(y[a]) for a in ['status']):dis.append((k,x['status'],y['status']))
 qcfilematch.append({'month':mon,'qc_csv_rows':len(qq),'qc_workbook_rows':len(sheetdict),'key_diff':len(set(csvdict)^set(sheetdict)),'status_mismatch':len(dis)})
# NEA days incomplete and 5-minute coverage
pagination=collections.Counter()
for r in status:
 if r.get('pagination_complete')!=1:pagination[(r['month'],r['kind'])]+=1
# NEA wide percent rows
neastats=[]
for mon in ('05','06','07','08','09'):
 for pt in ['CW_SG','SL_SG']:
  v=[r for r in nea if r['month']==mon and r['point_id']==pt]
  h=(31 if mon in ('05','07','08') else 30)*48
  neastats.append({'month':mon,'point_id':pt,'num_half_hours':len(v),'expected_half_hours':h,'rain_complete_sample_6':sum((r.get('rainfall_samples') or 0)>=6 for r in v),'wind_sample_30':sum((r.get('wind_speed_samples') or 0)>=30 for r in v),'rain_non_null':sum(r.get('rain_30min_mm') is not None for r in v),'wind_non_null':sum(r.get('wind_10min_mean_samples_avg_ms') is not None for r in v)})
# 2 MY points weather only aligned precipitation to actual start hour using following labelled hour ERA5
aligned=[]
for p in points:
 ts=sorted(bypt[p].keys())
 for i,t in enumerate(ts):
  rr=bypt[p][t]
  ea=bypt[p][ts[i+1]]['era5_precip_1h_mm'] if i<len(ts)-1 and datetime.datetime.strptime(ts[i+1][:19],'%Y-%m-%d %H:%M:%S')-datetime.datetime.strptime(t[:19],'%Y-%m-%d %H:%M:%S')==datetime.timedelta(hours=1) else None
  aligned.append({'point_id':p,'country':rr['country'],'corridor':rr['corridor'],'timestamp_hour_start_sgt':t,'era5_precip_interval_start_mm':ea,'era5_wind10_ms_instant':rr['era5_wind10_ms'],'era5_wind100_ms_instant':rr['era5_wind100_ms'],'era5_gust10_ms_model':rr['era5_gust10_ms'],'era5_dir10_deg_instant':rr['era5_dir10_deg'],'rain_time_alignment':'ERA5_ORIGINAL_LABEL_PLUS_1H_FOR_START_INTERVAL','source':'OPENMETEO_ERA5_REANALYSIS','nasa_rain_status':'QUARANTINED_VALUE_ANOMALY'})
# But last hour, can access 10/1 guard from ERA5_Hourly sheet for last row, do later
obj={'monthly':qa,'same_across_four_hour_counts':same,'cross_point_common_hours':len(allhours),'precip_interval_samples':intervalQA,'qc_csv_comparison':qcfilematch,'pagination_incomplete_day_counts':{str(k):v for k,v in pagination.items()},'nea_completeness':neastats,'flags':flg,'all_rows':len(rows)}
with open('/mnt/data/weather_metrics.json','w',encoding='utf8') as f:json.dump(obj,f,ensure_ascii=False,indent=2)
for name,data in [('E03_month_point_audit.csv',qa),('E03_nea_30min_coverage.csv',neastats),('E03_QC_crosscheck.csv',qcfilematch)]:
 with open('/mnt/data/'+name,'w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,data[0].keys());w.writeheader();w.writerows(data)
with open('/mnt/data/E03_ERA5_four_points_hourstart_aligned_PRELIMINARY.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,aligned[0].keys());w.writeheader();w.writerows(aligned)
print('all_rows',len(rows),'same across 4pts',same,'QC',qcfilematch,'pagination problems',pagination)
print('monthly first',qa[:6]);print('NEA',neastats[:5]);print('samples',intervalQA)
