import csv,gzip,collections,datetime,hashlib,json,os
E03='/mnt/data/E03_ERA5_JB_TWO_CIQ_WEATHER_HOURLY.csv'
FCD='/mnt/data/JB_CIQ_E01_E02_V4_3/E01_traffic_calendar_corrected_345nodes_2026_05-09.csv.gz'
OUT='/mnt/data/E04_G1_CIQ_Traffic_ERA5_PILOT_2026_05_09.csv.gz'
weather={}
with open(E03,encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):
  weather[(r['point_id'],r['timestamp_hour_start_sgt'])]=r
metrics=collections.Counter();seen=set(); missing=[]
cols=['node_id','timestamp_local','source_route_code','group_id','fcd_speed_raw','speed_state','weather_reference_point','weather_data_class','ERA5_precip_hour_start_mm','ERA5_wind10_ms','ERA5_wind100_ms','ERA5_gust10_ms','ERA5_wind_direction10_deg','weather_spatial_status','calculation_stage']
with gzip.open(OUT,'wt',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,cols);writer.writeheader()
 with gzip.open(FCD,'rt',encoding='utf-8-sig',newline='') as fcd:
  for r in csv.DictReader(fcd):
   if r['group_id']!='G1':continue
   p={'R1':'CW_MY','R2':'SL_MY'}.get(r['source_route_code'])
   w=weather.get((p,r['timestamp_local'].replace('T',' '))) if p else None
   if w is None:missing.append((r['node_id'],r['timestamp_local'],p));continue
   key=(r['node_id'],r['timestamp_local'])
   if key in seen:raise Exception(('duplicate',key))
   seen.add(key)
   rec={'node_id':r['node_id'],'timestamp_local':r['timestamp_local'],'source_route_code':r['source_route_code'],'group_id':r['group_id'],'fcd_speed_raw':r['observed_speed_raw'],'speed_state':r['speed_state'],'weather_reference_point':p,'weather_data_class':'ERA5_COARSE_REANALYSIS_GRID','ERA5_precip_hour_start_mm':w['ERA5_hour_start_precip_mm'],'ERA5_wind10_ms':w['ERA5_wind_10m_ms'],'ERA5_wind100_ms':w['ERA5_wind_100m_ms'],'ERA5_gust10_ms':w['ERA5_gust_10m_ms'],'ERA5_wind_direction10_deg':w['ERA5_wind_direction_10m_deg'],'weather_spatial_status':'REFERENCE_POINT_PROXY_NOT_LOCAL_OBSERVATION','calculation_stage':'E04_PILOT_NOT_FINAL_ROAD_OD'}
   writer.writerow(rec)
   metrics['rows']+=1; metrics[r['source_route_code']]+=1
   if r['speed_state']=='POSITIVE':metrics['positive_traffic_speed']+=1
   else:metrics['nonpositive_or_missing_traffic_speed']+=1
   for v in ['ERA5_precip_hour_start_mm','ERA5_wind10_ms','ERA5_wind100_ms','ERA5_gust10_ms']:
    if rec[v]=='':metrics[v+'_MISSING']+=1
print('G1 pilot',metrics,'misses',len(missing),'unique',len(seen),'expected',46*3672,'path',OUT,os.stat(OUT).st_size)
if metrics['rows']!=46*3672 or missing or len(seen)!=metrics['rows']:raise Exception('PILOT QA FAILED')
with open('/mnt/data/E04_PILOT_QA.json','w',encoding='utf8') as f:json.dump({'counts':metrics,'missing_join':len(missing),'note':'G1 reference-road traffic/weather JOIN ONLY; weather is coarse ERA5 reanalysis not local measured; is not vehicle OD time nor UAV flyability'},f,indent=2)
