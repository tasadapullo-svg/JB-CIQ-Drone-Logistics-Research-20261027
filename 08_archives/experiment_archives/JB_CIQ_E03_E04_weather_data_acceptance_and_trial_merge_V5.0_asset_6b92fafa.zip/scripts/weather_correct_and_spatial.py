import csv,json,os,re,math,collections,datetime,gzip,glob,zipfile,xml.etree.ElementTree as ET,statistics,hashlib
M='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
J=json.load(open('/mnt/data/weather_analysis_data.json'))
rows=J['data'];metas=J['meta'];ptmeta={x['point_id']:x for x in metas if x['month']=='05'}
def load_sheet(z,n):
 ss=[]
 with z.open('xl/sharedStrings.xml') as f:
  for _,e in ET.iterparse(f,events=('end',)):
   if e.tag==M+'si':ss.append(''.join(t.text or '' for t in e.iter(M+'t')));e.clear()
 with z.open(f'xl/worksheets/sheet{n}.xml') as f:
  h=None
  for _,e in ET.iterparse(f,events=('end',)):
   if e.tag!=M+'row':continue
   vals={}
   for c in e.findall(M+'c'):
    ref=c.get('r'); col=re.match(r'^[A-Z]+',ref)
    if not col:continue
    j=0
    for x in col.group():j=j*26+ord(x)-64
    t=c.find(M+'v');v=t.text if t is not None else None
    if c.get('t')=='s' and v:v=ss[int(v)]
    vals[j-1]=v
   line=[vals.get(k) for k in range(max(vals)+1)] if vals else []
   if h is None:h=line
   elif line:yield dict(zip(h,line))
   e.clear()
raw={};grid={};guard=collections.Counter();raw_count=0
for f in sorted(glob.glob('/mnt/data/JB_SG_Weather_2026_*.xlsx')):
 month=os.path.basename(f)[-7:-5];print('ERA5 source',month,flush=True)
 with zipfile.ZipFile(f) as z:
  for r in load_sheet(z,4):
   raw_count+=1
   pid=r['point_id']; st=r['rain_period_start_sgt']; key=(pid,st)
   if key in raw and float(raw[key]['precipitation'])!=float(r['precipitation']):raise Exception(('duplicate disagree',key))
   raw[key]=r
   grid[pid]=(r['latitude_returned'],r['longitude_returned'])
   if st[:7] != f'2026-{month}':guard[month]+=1
out=[];notfound=[];diff=collections.Counter()
for r in rows:
 pid=r['point_id'];t=r['timestamp_hour_start_sgt'];ra=raw.get((pid,t))
 if not ra:notfound.append((pid,t));prec=''
 else:prec=float(ra['precipitation'])
 instantprec=r['era5_precip_1h_mm']
 if isinstance(prec,(int,float)) and prec!=instantprec:diff[pid]+=1
 line={'point_id':pid,'corridor':r['corridor'],'country':r['country'],'timestamp_hour_start_sgt':t,'timestamp_hour_end_sgt':(datetime.datetime.strptime(t[:19],'%Y-%m-%d %H:%M:%S')+datetime.timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S+0800'),'ERA5_hour_start_precip_mm':prec,'ERA5_hour_start_rain_mm':float(ra['rain']) if ra else '', 'ERA5_wind_10m_ms':r['era5_wind10_ms'],'ERA5_wind_100m_ms':r['era5_wind100_ms'],'ERA5_wind_direction_10m_deg':r['era5_dir10_deg'],'ERA5_wind_direction_100m_deg':r['era5_dir100_deg'],'ERA5_gust_10m_ms':r['era5_gust10_ms'],'ERA5_temp_C':r['era5_temp_c'],'ERA5_relative_humidity_pct':r['era5_rh_pct'],'ERA5_grid_lat':float(grid[pid][0]),'ERA5_grid_lon':float(grid[pid][1]),'source':'Open-Meteo ERA5 0.25deg','data_class':'REANALYSIS','rain_interval_semantics':'hour_start_inclusive_to_hour_end_exclusive','wind_interval_semantics':'instantaneous_model_at_hour_start','nasa_precip_use':'EXCLUDED_PENDING_SOURCE_VERIFICATION'}
 out.append(line)
print('RAW',raw_count,'unique',len(raw),'guard',guard,'grids',grid,'matched',len(out)-len(notfound),'miss',len(notfound),'rain value shifted',dict(diff))
path='/mnt/data/E03_ERA5_CORRECTED_2026_05_09_FOUR_POINTS.csv'
with open(path,'w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,out[0].keys());w.writeheader();w.writerows(out)
my=[x for x in out if x['country']=='MY']
with open('/mnt/data/E03_ERA5_JB_TWO_CIQ_WEATHER_HOURLY.csv','w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,out[0].keys());w.writeheader();w.writerows(my)
# FCD node nearest of two weather reference sites - proximity not approval
nodegeo={};fp='/mnt/data/JB_CIQ_E01_E02_V4_3/E01_traffic_calendar_corrected_345nodes_2026_05-09.csv.gz'
with gzip.open(fp,'rt',encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):
  key=r['node_id'];
  if key not in nodegeo:
   nodegeo[key]={'node_id':key,'group_id':r['group_id'],'source_route_code':r['source_route_code'],'latitude':float(r['latitude']),'longitude':float(r['longitude'])}
  if len(nodegeo)==345:break

def hav(la1,lo1,la2,lo2):
 r1,r2=math.radians(la1),math.radians(la2)
 x=math.sin((r2-r1)/2)**2+math.cos(r1)*math.cos(r2)*math.sin(math.radians(lo2-lo1)/2)**2
 return 12742*math.asin(math.sqrt(x))
ref={k:ptmeta[k] for k in ['CW_MY','SL_MY']}
xs=[]
for n in nodegeo.values():
 ds={p:hav(n['latitude'],n['longitude'],float(m['latitude']),float(m['longitude'])) for p,m in ref.items()}
 p=min(ds,key=ds.get);dd=ds[p]
 xs.append({**n,'nearest_CIQ_weather_ref':p,'distance_to_nearest_reference_km':round(dd,3),'crosswalk_status':'PROXIMITY_ONLY_NOT_APPROVED','coarse_proximity_screen_le_10km':dd<=10,'coarse_proximity_screen_le_20km':dd<=20})
with open('/mnt/data/E04_FCD_345node_weather_proximity_SCREEN_ONLY.csv','w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,xs[0].keys());w.writeheader();w.writerows(xs)
print('345 proximity',[(k,sum(float(x['distance_to_nearest_reference_km'])<=k for x in xs)) for k in [5,10,15,20,25,30,50]],'max',max(float(x['distance_to_nearest_reference_km']) for x in xs))
print('G1',[(k,sum(x['group_id']=='G1' and float(x['distance_to_nearest_reference_km'])<=k for x in xs)) for k in [5,10,20]])
print('MY corrected monthly aggregates')
for m in ['05','06','07','08','09']:
 for p in ['CW_MY','SL_MY']:
  v=[r for r in my if r['timestamp_hour_start_sgt'][5:7]==m and r['point_id']==p]
  print(m,p,len(v),round(sum(r['ERA5_hour_start_precip_mm'] for r in v),2),'wind max',max(r['ERA5_gust_10m_ms'] for r in v))
json.dump({'raw_era5_rows':raw_count,'unique_period_records':len(raw),'matched':len(out)-len(notfound),'missing':notfound[:15],'shifted_rain_changed_count':dict(diff),'grid_coordinates':grid,'nodes_distance_screen':{str(k):sum(float(x['distance_to_nearest_reference_km'])<=k for x in xs) for k in [5,10,15,20,25,30,50]}},open('/mnt/data/E03_timing_alignment_log.json','w'),ensure_ascii=False,indent=2)
