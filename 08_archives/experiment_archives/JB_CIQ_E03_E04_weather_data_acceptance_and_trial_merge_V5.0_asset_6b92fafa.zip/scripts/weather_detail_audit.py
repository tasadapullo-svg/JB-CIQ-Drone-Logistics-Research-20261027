import zipfile,xml.etree.ElementTree as ET,glob,csv,collections,statistics,datetime,os,re,math,json,hashlib,sys
M='http://schemas.openxmlformats.org/spreadsheetml/2006/main'

def ss_load(z):
 arr=[]
 with z.open('xl/sharedStrings.xml') as f:
  for ev,x in ET.iterparse(f,events=('end',)):
   if x.tag==f'{{{M}}}si':
    arr.append(''.join(t.text or '' for t in x.iter(f'{{{M}}}t')))
    x.clear()
 return arr

def iter_rows(z,n,ss):
 with z.open(f'xl/worksheets/sheet{n}.xml') as f:
  for event, x in ET.iterparse(f,events=('end',)):
   if x.tag != f'{{{M}}}row':continue
   cells={}
   for c in x.findall(f'{{{M}}}c'):
    a=c.attrib.get('r','');letters=re.match(r'[A-Z]+',a)
    if not letters:continue
    j=0
    for q in letters.group():j=j*26+ord(q)-64
    v=c.find(f'{{{M}}}v');val=v.text if v is not None else None
    if c.attrib.get('t')=='s' and val is not None: val=ss[int(val)]
    elif val is not None and c.attrib.get('t') not in ('str','e'):
     try: val=float(val)
     except:pass
    cells[j-1]=val
   if cells:yield [cells.get(i) for i in range(max(cells)+1)]
   x.clear()

def table(z,n,ss):
 it=iter_rows(z,n,ss); header=next(it)
 for row in it:yield dict(zip(header,row))

def tofloat(v):
 try:return float(v)
 except:return None

def iso(t):return datetime.datetime.strptime(t[:19],'%Y-%m-%d %H:%M:%S')

rows=[]; monthqc=[]; pointmeta=[]; monthstatus=[]; stations=[]; neawide=[]; sources=[]; issues=[]; daily=[]
for p in sorted(glob.glob('/mnt/data/JB_SG_Weather_2026_*.xlsx')):
 mon=os.path.basename(p)[-7:-5]
 print('Processing',mon,flush=True)
 with zipfile.ZipFile(p) as z:
  ss=ss_load(z)
  data=list(table(z,3,ss)); xmeta=list(table(z,2,ss)); qc=list(table(z,14,ss)); ssreg=list(table(z,15,ss)); stat=list(table(z,11,ss)); select=list(table(z,9,ss))
  pointmeta += [{**x, 'month':mon} for x in xmeta]
  monthqc += [{**x, 'month':mon} for x in qc]
  monthstatus += [{**x,'month':mon} for x in stat]
  stations += [{**x,'month':mon} for x in select]
  sources += [{**x,'month':mon} for x in ssreg]
  # NEA 30-min summary full month ~ 2880 records only
  nw=list(table(z,6,ss));neawide += [{**x,'month':mon} for x in nw]
  for x in data: x['month']=mon; rows.append(x)
 print('  weather',len(data),'NEA30',len(nw),'GEO',len(xmeta),'QC',len(qc),flush=True)
output='/mnt/data/weather_analysis_data.json'
with open(output,'w',encoding='utf8') as f:json.dump({'data':rows,'meta':pointmeta,'qc':monthqc,'status':monthstatus,'stations':stations,'nea30':neawide,'sources':sources},f,ensure_ascii=False)
print('Saved',output,os.stat(output).st_size)
for p in sorted({r['point_id'] for r in rows}):
 subset=[r for r in rows if r['point_id']==p]
 print('POINT',p,'n',len(subset),'nunique timestamps',len(set(r['timestamp_hour_start_sgt'] for r in subset)))
 for k in ['era5_precip_1h_mm','nasa_precip_mm_per_hour','era5_wind10_ms','era5_wind100_ms','era5_gust10_ms','nasa_wind10_ms']:
  v=[tofloat(r[k]) for r in subset];v=[x for x in v if x is not None]
  print(' ',k, 'n',len(v),'min',min(v) if v else '', 'median',round(statistics.median(v),3) if v else '', 'mean',round(statistics.mean(v),3) if v else '', 'max',max(v) if v else '', 'sum',round(sum(v),1) if 'precip' in k else '', 'pct_nonzero',round(sum(x>0 for x in v)/len(v),3) if v else '')
print('META')
for m in pointmeta[:4]:print(m)
print('STATION')
for x in stations[:6]:print(x)
print('QC_NEAREST_AND_FLAGS')
for x in monthqc:
 if x['source']=='NEA' and x['variable'] in ('rainfall','wind-speed'):print(x['month'],x['point_id'],x['variable'],x['coverage_pct'],x['status'])
