"""Geometry-only truck-to-candidate-hub-to-destination screening for the illustrative OD fixture.
This does not certify a pad, airspace, legal route, or driving distance.
"""
from pathlib import Path
import pandas as pd, numpy as np, math, gzip
p=Path(__file__).resolve().parent
s=pd.read_csv(p/'POI_reference_sites_INPUT.csv',encoding='utf-8-sig').set_index('site_id')
o=pd.read_csv(p/'E05_ILLUSTRATIVE_2026_05_09_SYNTHETIC_ORDERS.csv.gz')
def km(s1,s2):
 a,b=s.loc[s1],s.loc[s2]
 ra=6371.0088; x1,x2=math.radians(a.latitude),math.radians(b.latitude)
 dl=x2-x1; dp=math.radians(b.longitude-a.longitude)
 c=math.sin(dl/2)**2+math.cos(x1)*math.cos(x2)*math.sin(dp/2)**2
 return 2*ra*math.asin(min(1,math.sqrt(c)))
hubs={'A':['A01','A02','A03'],'B':['B01','B02']}
# This only computes best candidate transfer centre for a given destination.
lookup={(h,d):km(h,d) for area,hids in hubs.items() for h in hids for d in s[s.area==area].index}
rows=[]
for row in o.itertuples(index=False):
 choices=[(h,lookup[(h,row.destination_site_id)]) for h in hubs[row.study_area]]
 hub,d=min(choices,key=lambda x:(x[1],x[0]))
 truck_geo=km(row.origin_site_id,hub)
 rows.append({'order_id':row.order_id,'study_area':row.study_area,'demand_class':row.scenario_demand_class,
              'truck_leg_origin_site':row.origin_site_id,'candidate_transfer_site':hub,
              'truck_origin_to_transfer_STRAIGHT_KM_NOT_DRIVING':round(truck_geo,5),
              'transfer_to_destination_STRAIGHT_KM':round(d,5),
              'air_leg_candidate_3km_GEOMETRIC':int(d<=3),
              'air_leg_candidate_4km_GEOMETRIC':int(d<=4),
              'site_legal_status':'NOT_VERIFIED', 'air_route_3d_weather_energy':'NOT_VERIFIED',
              'road_OD_travel_time':'NOT_YET_VALIDATED',
              'candidate_multimodal_interpretation':'GROUND_TRUNK_AND_AIR_GEOMETRY_ONLY' if d<=4 else 'GROUND_ONLY_OR_NEW_TRANSFER_REQUIRED'})
x=pd.DataFrame(rows)
x.to_csv(p/'E05_candidate_truck_hub_air_legs_GEOMETRY_ONLY.csv.gz',index=False,compression={'method':'gzip','mtime':0})
summary=x.groupby(['study_area','demand_class'],as_index=False).agg(orders=('order_id','size'),potential_geom_3km=('air_leg_candidate_3km_GEOMETRIC','sum'),potential_geom_4km=('air_leg_candidate_4km_GEOMETRIC','sum'))
summary.to_csv(p/'E05_multimodal_geometry_screen_summary.csv',index=False)
assert len(x)==len(o)
assert x['order_id'].is_unique
assert (x.air_leg_candidate_3km_GEOMETRIC<=x.air_leg_candidate_4km_GEOMETRIC).all()
print(summary.to_string(index=False))
