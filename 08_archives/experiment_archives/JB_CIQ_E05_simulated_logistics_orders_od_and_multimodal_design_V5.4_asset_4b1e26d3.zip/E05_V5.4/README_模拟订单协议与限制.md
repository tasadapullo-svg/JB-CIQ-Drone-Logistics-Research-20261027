# E05 Synthetic OD Engineering Fixture · V5.4 · 2026-10-27

**Status: engineering-only / demonstration, NOT scientific demand-calibrated, NOT real logistics orders and NOT approved routes.**

## Purpose
- Validate downstream CSV formats, synthetic D1/D2 order IDs, date-time joining to the 24-hour 2026-05–09 observed FCD+ERA5 data, and 3/4-km *geometric* multimodal screening.
- Do **not** use these artificial counts to report real demand, economic ROI, actual carbon savings, empirical drone feasibility, or statistical population estimates.

## Evidence hierarchy
1. **Observed/verified source:** 19 real-world POI/location/search-centre reference entries and coordinates from the frozen V3 GIS register; 2026 May–September FCD traffic and ERA5 weather are separate, observed/reanalysis inputs and ARE NOT fabricated by this tool.
2. **Engineering assumptions for code testing:** 40 D1 + 60 D2 orders per area per day (100/area/day), 153 days, areas A/B, all 24 hours, load ranges D1 0.20–2.00 kg and D2 0.20–1.50 kg, deadlines D1 120 min and D2 45 min, categorical origin/destination roles, synthetic time-of-day weights; all are deliberately illustrative and lack empirical validation.
3. **Model-derived:** straight-line WGS84 great-circle distances and 3/4-km proximity flags; not verified road, air, legal or energy distances.
4. **Unknown:** licensed flight sites, actual cargo flows, route restrictions, wind limits for each craft, customer walking time, fleet/handling costs, true local logistics demand, fuel/charging consumption.

## The two order cohorts (same IDs across every comparison)
- D1 = modelled CIQ-associated small parcels; labels do **not** prove real CIQ shipping volume, clearance or cross-border drone service. The customs crossing, where applicable, must remain with a compliant **ground** leg in the S1 scenario.
- D2 = modelled local merchant–community same-day/food-delivery demand. D2 is optional shared usage, not measured GrabFood transactions.
- D1-only uses just D1 IDs; D1+D2 uses **the identical D1 IDs** plus D2. Compare D1 service performance on the matched cohort, and full-network costs/emissions under consistent system boundaries.

## Geographic multimodal test
- A: hypothetical fixed-hub choices A01/A02/A03; local customer nodes A04/A06/A07 and parcel demand sites. These are commercial/community landmark centroids, NOT verified rooftops/pads.
- B: hypothetical transfer search centres B01/B02; goods originate at B08 PTP or B06/B07 retail precinct proxies; final destinations B03/B04/B05/B06/B09. These are not necessarily valid vehicle stops or UAV pads.
- For each order, choose the transfer centre with the shortest geodesic distance to its destination, and separately list origin-to-transfer geodesic proxy (NOT driving distance).
- Order-to-customer direct flight and truck+UAV feeder are separate concepts. For every candidate feeder, the **entire 3D route**, round-trip/recovery, airspace, payload, weather, energy and site/land-use permissions remain `UNVERIFIED`.
- B >4-km original OD pairs are **not discarded**. They stay in the ground trunk and are checked for a possible 3/4-km UAV final leg.

## Statistical design rules
- All days and hours present; May–July = development; Aug–Sep = evaluation; random seed = 20261027.
- Only one demonstration demand rate was created. It is NOT a final SCI demand assumption. To publish, first justify/sensitivity-bound the volume and time-profile assumptions from literature, public population/POI proxies or independent experts; freeze before computing benefits.
- Use precisely the 16 core structural experimental configurations and up to 8 predeclared craft comparisons, not additional configurations selected after inspecting outcomes.
- Vehicle baseline must deliver EXACTLY THE SAME synthetic orders as the comparable mixed system. UAV scenarios must have a fallback for unserviceable/night/rain/wind/no-permit orders; otherwise compare completed order quantities and service level explicitly.
- A fallback produces real or modelled time/emissions only after a properly audited ground OD routing model is available; current V5.3 91-OD speed-adjusted times are MODEL PROXIES.

## Reproduce
```
python generate_synthetic_od.py --sites POI_reference_sites_INPUT.csv --out .
python build_transfer_legs.py
```

## Main files
- `E05_ILLUSTRATIVE_2026_05_09_SYNTHETIC_ORDERS.csv.gz` contains 30,600 explicitly synthetic example orders.
- `E05_candidate_truck_hub_air_legs_GEOMETRY_ONLY.csv.gz` contains 30,600 geometric feeder assignments; **no flight certification**.
- `E05_demo_summary_by_area_class.csv` and `E05_multimodal_geometry_screen_summary.csv` contain descriptive audit counts.
- `E05_QA.json` contains structural quality checks.
- `SHA256_manifest.csv` hashes all static deliverables; run scripts to reproduce the same output.

## Next gate to scientific simulations
1. Publish/review justification of simulation order-rate / OD role / weights; fix the pilot assumptions or replace them with documented synthetic benchmark assumptions.
2. Verify legal/physical takeoff/receiving footprints, route restrictions, aircraft weather & energy constraints, and implement the fixed fallback.
3. Validate ground route time estimates against independent travel-time samples; assign any remaining uncovered road speeds as imputed and report sensitivity.
4. Only then run the existing finite matrix and report time, emission, costs (all as **scenario/model-based estimates**, not actual delivered orders).
