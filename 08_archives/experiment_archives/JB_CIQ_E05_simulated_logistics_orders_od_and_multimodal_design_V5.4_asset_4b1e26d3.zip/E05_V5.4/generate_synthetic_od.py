#!/usr/bin/env python3
"""Reproducible illustrative OD *test fixture*, NOT an empirically validated demand model.
Run: python generate_synthetic_od.py --sites PATH --out OUTPUT_DIR
No Internet is required. Input POI site coordinates are reference locations, not permitted UAV pads.
"""
import argparse
import hashlib
import json
from pathlib import Path
from datetime import date, datetime, timedelta
import math
import numpy as np
import pandas as pd

SEED=20261027
# ENGINEERING TEST VALUES ONLY; NOT FROM REAL ORDER COUNTS
D1_PER_AREA_PER_DAY=40
D2_PER_AREA_PER_DAY=60
D1_DEADLINE_MIN=120
D2_DEADLINE_MIN=45
D1_PAYLOAD_KG=(0.20, 2.00)
D2_PAYLOAD_KG=(0.20, 1.50)
START=date(2026,5,1)
END=date(2026,9,30)
# Role inference for a TEST INSTANCE. Not evidence of actual merchants, orders, or pad access.
OD_CONFIG={
    'A': {
       'D1': {'origins':['A08','A05'], 'destinations':['A01','A02','A03','A04','A06','A07']},
       'D2': {'origins':['A01','A02','A03'], 'destinations':['A04','A06','A07']}
    },
    'B': {
       'D1': {'origins':['B08'], 'destinations':['B03','B04','B05','B06','B07','B09']},
       'D2': {'origins':['B07','B06'], 'destinations':['B03','B04','B05','B06','B09']}
    }
}

def haversine_km(lat1, lon1, lat2, lon2):
    rr=6371.0088
    a1,a2=math.radians(lat1),math.radians(lat2)
    dlat=a2-a1; dlon=math.radians(lon2-lon1)
    a=math.sin(dlat/2)**2 + math.cos(a1)*math.cos(a2)*math.sin(dlon/2)**2
    return rr*2*math.asin(min(1,math.sqrt(a)))


def generate(sites, out_dir):
    out_dir.mkdir(parents=True,exist_ok=True)
    points=pd.read_csv(sites,encoding='utf-8-sig')
    required={'site_id','area','place_name','latitude','longitude'}
    if not required.issubset(points.columns):
        raise ValueError(f'Missing POI columns: {required - set(points.columns)}')
    lookup=points.set_index('site_id').to_dict('index')
    rng=np.random.default_rng(SEED)
    days=pd.date_range(START,END,freq='D')
    records=[]
    count=0
    # Explicit 24h illustrative time weights. Not empirical Grab or customs order rates.
    d1_weights=np.array([1 if h<6 else (3 if h<18 else (2 if h<23 else 1)) for h in range(24)],float)
    d2_weights=np.array([1 if h<6 else (3 if h<11 else (6 if h<15 else (4 if h<17 else (7 if h<22 else 2)))) for h in range(24)],float)
    for day in days:
      for area in ('A','B'):
        for cls,n in (('D1',D1_PER_AREA_PER_DAY),('D2',D2_PER_AREA_PER_DAY)):
          cfg=OD_CONFIG[area][cls]
          hour_weights=d1_weights if cls=='D1' else d2_weights
          hours=rng.choice(np.arange(24),size=n,p=hour_weights/hour_weights.sum())
          minutes=rng.integers(0,60,n)
          origins=rng.choice(cfg['origins'],size=n)
          destinations=rng.choice(cfg['destinations'],size=n)
          for j in range(n):
            origin=str(origins[j]); dest=str(destinations[j])
            if origin==dest:  # no self-delivery
                alt=[x for x in cfg['destinations'] if x!=origin]
                dest=str(rng.choice(alt))
            so,sd=lookup[origin],lookup[dest]
            ts=day.to_pydatetime().replace(hour=int(hours[j]), minute=int(minutes[j]))
            deadline=ts+timedelta(minutes=D1_DEADLINE_MIN if cls=='D1' else D2_DEADLINE_MIN)
            low,high=D1_PAYLOAD_KG if cls=='D1' else D2_PAYLOAD_KG
            kg=round(float(rng.uniform(low,high)),2)
            dist=haversine_km(float(so['latitude']),float(so['longitude']),float(sd['latitude']),float(sd['longitude']))
            count+=1
            records.append({
                'order_id':f'SIM{count:07d}',
                'scenario_demand_class':cls,
                'study_area':area,
                'release_time_local':ts.strftime('%Y-%m-%d %H:%M:%S'),
                'release_hour_local':int(hours[j]),
                'day_type':'weekend' if ts.weekday()>=5 else 'weekday',
                'dataset_partition':'model_development' if day.month<=7 else 'out_of_sample_evaluation',
                'origin_site_id':origin,'origin_label':so['place_name'],
                'origin_lat':float(so['latitude']),'origin_lon':float(so['longitude']),
                'destination_site_id':dest,'destination_label':sd['place_name'],
                'destination_lat':float(sd['latitude']),'destination_lon':float(sd['longitude']),
                'parcel_kg':kg,
                'deadline_local':deadline.strftime('%Y-%m-%d %H:%M:%S'),
                'straight_line_km':round(dist,5),
                'within_3km_geometric':int(dist<=3),
                'within_4km_geometric':int(dist<=4),
                'direct_flight_route_feasible':'UNVERIFIED',
                'uav_site_airspace_permission':'UNVERIFIED',
                'uav_weather_flight_allowed':'UNVERIFIED',
                'vehicular_leg_needed_for_gt4km':'YES' if dist>4 else 'TO_BE_EVALUATED',
                'traffic_weather_24h_input':'MATCH_BY_AREA_AND_HOUR_SEPARATELY',
                'data_origin':'SYNTHETIC_ENGINEERING_TEST_NOT_OBSERVED',
                'scenario_spec':'V5.4_ILLUSTRATIVE_NON_EMPIRICAL'
            })
    df=pd.DataFrame.from_records(records)
    path=out_dir/'E05_ILLUSTRATIVE_2026_05_09_SYNTHETIC_ORDERS.csv.gz'
    df.to_csv(path,index=False,compression={'method':'gzip','mtime':0},encoding='utf-8')
    counts=df.groupby(['study_area','scenario_demand_class'],as_index=False).agg(orders=('order_id','count'),mean_straight_line_km=('straight_line_km','mean'),pct_geometric_4km=('within_4km_geometric','mean'))
    counts.to_csv(out_dir/'E05_demo_summary_by_area_class.csv',index=False)
    # D1 IDs are unchanged in both D1-only and D1+D2 settings; no second sample generated.
    scenario=pd.DataFrame([
        {'experiment_demand':'D1_only','included_classes':'D1','note':'Contains EXACT SAME D1 orders as shared scenario'},
        {'experiment_demand':'D1_plus_D2','included_classes':'D1,D2','note':'Additive D2 orders; D1 identity remains fixed'}
    ])
    scenario.to_csv(out_dir/'E05_scenario_interpretation.csv',index=False)
    assert len(df)==2*len(days)*(D1_PER_AREA_PER_DAY+D2_PER_AREA_PER_DAY)
    assert df.order_id.is_unique and (df.origin_site_id!=df.destination_site_id).all()
    assert (df.parcel_kg>0).all() and df.release_hour_local.between(0,23).all()
    assert df.groupby(['study_area','scenario_demand_class']).size().to_dict()=={('A','D1'):6120,('A','D2'):9180,('B','D1'):6120,('B','D2'):9180}
    assert df['release_hour_local'].nunique()==24
    assert set(df['origin_site_id']).union(df['destination_site_id']).issubset(set(points['site_id']))
    assert (df.within_3km_geometric<=df.within_4km_geometric).all()
    qa={'generated_order_count':len(df), 'unique_order_ids':int(df.order_id.nunique()),'days':len(days),'areas':['A','B'],
        'hours_observed_in_synthetic_test':sorted(map(int,df.release_hour_local.unique())),
        'd1_only_orders':int((df.scenario_demand_class=='D1').sum()),
        'shared_d1_plus_d2_orders':len(df),'seed':SEED,
        'physical_and_regulatory_feasibility':'NOT_ASSESSED',
        'sci_claims_allowed':'ONLY METHODOLOGICAL TEST; NO ACTUAL DEMAND OR EMPIRICAL SAVINGS',
        'inputs':{'sites':sites.name},
        'parameter_status':'UNVALIDATED_ENGINEERING_DEMONSTRATION'}
    (out_dir/'E05_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(qa,ensure_ascii=False,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--sites',type=Path,default=Path('/mnt/data/JB_CIQ_MultiNode_V3/01_真实POI及候选区域清单.csv'))
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
    a=p.parse_args()
    generate(a.sites,a.out)
