#!/usr/bin/env python3
"""V5.3 reproducible smoke test, NOT a validated freight or UAS simulation.
All variables and model assumptions documented in 00_README.md.
Uses only archived E04 regional-hour traffic+ERA5 and E02 OSM reference paths.
No post-hoc scenario expansion, no fabricated demand, no legal flight assertions.
"""
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict
import csv, io, gzip, json, zipfile, hashlib, math, statistics

ROOT = Path('/mnt/data')
OUT = ROOT / 'JB_CIQ_Dispatch_Preflight_V5_3'
E04 = ROOT / 'JB_CIQ_E04_V5_2' / '01_AB_24h_hourly_joint.csv'
E02 = ROOT / 'JB_CIQ_E02_roadnet_V4_6_REAL_OSM_20261026.zip'


def readcsv(path):
    with open(path,'r',encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def csvsave(path, fields, rows):
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); w.writeheader();w.writerows(rows)

def flt(x):
    try: return float(x) if x is not None and str(x).strip() else None
    except (ValueError,TypeError): return None

# Source E04: 24-hour weather and area traffic status
hours=readcsv(E04)
assert len(hours)==7344, len(hours)
assert {r['area'] for r in hours}=={'A','B'}
assert all(r['timestamp_local_hour'].startswith('2026-') for r in hours)
assert len({(r['area'],r['timestamp_local_hour']) for r in hours})==len(hours)
assert {r['timestamp_local_hour'] for r in hours if r['area']=='A'} == {r['timestamp_local_hour'] for r in hours if r['area']=='B'}

hour_rows=[]; H={}
for r in hours:
    h=int(r['hour_local']); area=r['area']
    obs=int(r['n_positive_speeds'])
    coverage=flt(r['fcd_positive_speed_coverage'])
    ratio=flt(r['median_ratio_to_dev_P90'])
    rain=flt(r['ERA5_precip_mm_hour']); gust=flt(r['ERA5_gust10_ms'])
    wind=flt(r['ERA5_wind10_ms']); wind100=flt(r['ERA5_wind100_ms'])
    assert all(x is not None for x in (rain,gust,wind,wind100))
    assert rain>=0 and gust>=0 and wind>=0
    valid=(coverage is not None and coverage>=.70 and obs>0 and ratio is not None and ratio>0)
    # 19:00-05:59 is an ANALYSIS PROXY, not astronomical sunset or a legal airspace classification
    night_proxy= (h>=19 or h<6)
    rec={
      'area':area,'timestamp_local_hour':r['timestamp_local_hour'],'date_local':r['date_local'],'hour_local':h,
      'is_weekend':r['is_weekend'],'data_split':r['data_split'],
      'fcd_nodes':int(r['n_fcd_nodes']),'fcd_valid_nodes':obs,'fcd_coverage':coverage,
      'road_regional_median_ratio_to_dev_P90':ratio,'road_mean_deficit':flt(r['mean_node_speed_deficit']),
      'ground_proxy_input_ok':int(valid),
      'era5_rain_mm_hour':rain,'era5_wind10_ms':wind,'era5_wind100_ms':wind100,'era5_gust10_ms':gust,
      'rain_ge_0p1mm':int(rain>=.1),'heavy_rain_ge_5mm':int(rain>=5),
      'gust_ge_10ms_DESCRIPTIVE_ONLY':int(gust>=10),
      'night_window_19_to_05_PROXY':int(night_proxy),
      'uav_site_airspace_approval':'NOT_VERIFIED',
      'uav_cargo_bvlos_approval':'NOT_VERIFIED',
      'uav_night_approval':'NOT_VERIFIED',
      'uav_weather_limits_per_aircraft':'NOT_VERIFIED',
      'uav_dispatch_verdict':'NOT_RELEASED_PENDING_APPROVAL',
      'fallback_policy':'GROUND_WHEN_LEGAL_AND_ROUTE_IS_VERIFIED',
      'fallback_actual_time':'UNAVAILABLE_UNTIL_GROUND_OD_VALIDATION',
      'weather_data_type':'ERA5_REANALYSIS_NOT_FLIGHT_MEASUREMENT',
      'traffic_data_type':'FCD_REGION_AGGREGATE_NOT_DIRECTED_EDGE_SPEED',
    }
    hour_rows.append(rec);H[area,r['timestamp_local_hour']]=rec

csvsave(OUT/'01_AB_24h_weather_traffic_operation_gates.csv',list(hour_rows[0]),hour_rows)

# Reference OD contains modeled OSM road paths but NO real delivery demand
ods=[]
with zipfile.ZipFile(E02) as z:
    for a in 'AB':
        names=[n for n in z.namelist() if '/outputs/' in n and n.endswith(f'/E02_{a}_OD_OSM_MODEL_NOT_OBSERVED.csv')]
        assert len(names)==1
        f=io.StringIO(z.read(names[0]).decode('utf-8-sig'))
        ods.extend(csv.DictReader(f))
assert len(ods)==128
assert len([r for r in ods if flt(r['OSM_only_minutes_MODEL']) is not None])==91

static=[]
for r in ods:
    t=flt(r['OSM_only_minutes_MODEL']);cir=flt(r['circuity_ratio']);length=flt(r['route_length_km']);
    assert t is None or (t>0 and length>0)
    static.append({
      'area':r['area'],'origin_id':r['origin_id'],'destination_id':r['destination_id'],
      'straight_line_km':r['beeline_km'],'OSM_route_km_NOT_VERIFIED':length,
      'OSM_model_base_min_NOT_OBSERVED':t,
      'route_status':'MODEL_ROUTE_REQUIRES_QA' if t else r['status'],
      'circuity_ratio':cir,
      'circuity_over_3_REVIEW':int(cir>3) if cir is not None else '',
      'turn_restrictions':r['turn_restrictions'],'boundary':r['country_boundary'],
      'reference_OD_is_real_order':0,
      'independent_navigation_validation':0,
      'is_formal_RQ2_travel_time':0,
    })
csvsave(OUT/'02_static_128_reference_OD_NOT_ORDERS.csv',list(static[0]),static)

# A mathematical interface/sensitivity smoke test only; not route-specific FCD.
# T_proxy = T_OSM_model / r_area_hour (regional ratio to DEV-period node P90)
# This assumes an OSM model baseline comparable to P90, NOT verified.
fields=['area','timestamp_local_hour','origin_id','destination_id',
        'OSM_reference_route_km','OSM_assumption_time_min',
        'region_FCD_ratio_to_node_P90','FCD_hour_coverage',
        'model_scaled_time_min_NOT_VALIDATED','model_relative_increase_pct',
        'ground_result_class','uav_dispatch_verdict','fallback_time_status',
        'note']
count=Counter();min_proxy=1e9;max_proxy=0; allstat=defaultdict(list)
with gzip.open(OUT/'03_hourly_91_reference_OD_MODEL_PROXY_NOT_REAL.csv.gz','wt',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    od_valid=[r for r in static if r['OSM_model_base_min_NOT_OBSERVED'] is not None]
    for x in hour_rows:
        area=x['area']; valid=bool(x['ground_proxy_input_ok']); ratio=x['road_regional_median_ratio_to_dev_P90']
        for d in od_valid:
            if d['area'] != area: continue
            base=d['OSM_model_base_min_NOT_OBSERVED']
            proxy=round(base/ratio,5) if valid else ''
            percent=round(100*(1/ratio-1),5) if valid else ''
            q='MODEL_SENSITIVITY_PROXY_ONLY' if valid else 'MISSING_FCD_HOUR_NO_PROXY'
            w.writerow({
             'area':area,'timestamp_local_hour':x['timestamp_local_hour'],
             'origin_id':d['origin_id'],'destination_id':d['destination_id'],
             'OSM_reference_route_km':d['OSM_route_km_NOT_VERIFIED'],
             'OSM_assumption_time_min':base,
             'region_FCD_ratio_to_node_P90':ratio or '',
             'FCD_hour_coverage':x['fcd_coverage'],
             'model_scaled_time_min_NOT_VALIDATED':proxy,
             'model_relative_increase_pct':percent,'ground_result_class':q,
             'uav_dispatch_verdict':x['uav_dispatch_verdict'],
             'fallback_time_status':x['fallback_actual_time'],
             'note':'REFERENCE_OD_NOT_FREIGHT;NO_DIRECTIONAL_MATCH;NO_REAL_TRAVEL_TIME;NOT_RQ2_RESULT'
            })
            count[(area,'total')]+=1
            count[(area,'with_proxy' if valid else 'without_proxy')]+=1
            if valid:
                min_proxy=min(min_proxy,proxy);max_proxy=max(max_proxy,proxy)
                allstat[area].append(percent)
assert sum(count[(a,'total')] for a in 'AB')==91*3672
assert count['A','with_proxy']==49*3220 and count['B','with_proxy']==42*3248, dict(count)

# summarise full time index and offline model proxy (no benefit claims)
summary=[]
for a in 'AB':
    ss=[x for x in hour_rows if x['area']==a]
    summary.append({
        'area':a,'region_hours':len(ss),'fcd_hour_coverage_ge_70pct':sum(x['ground_proxy_input_ok'] for x in ss),
        'fcd_hour_coverage_below_70pct':sum(not x['ground_proxy_input_ok'] for x in ss),
        'rain_ge_0p1_mm_hours':sum(x['rain_ge_0p1mm'] for x in ss),
        'rain_ge_5_mm_hours':sum(x['heavy_rain_ge_5mm'] for x in ss),
        'gust_ge_10ms_hours_CONTEXT_NOT_UAS_THRESHOLD':sum(x['gust_ge_10ms_DESCRIPTIVE_ONLY'] for x in ss),
        'night_window_proxy_hours':sum(x['night_window_19_to_05_PROXY'] for x in ss),
        'aircraft_operationally_released_hours':0,
        'reference_model_OD_pairs':sum(d['area']==a and d['OSM_model_base_min_NOT_OBSERVED'] is not None for d in static),
        'reference_unroutable_OD_pairs':sum(d['area']==a and d['OSM_model_base_min_NOT_OBSERVED'] is None for d in static),
        'hour_OD_proxy_rows':count[a,'total'],
        'hour_OD_proxy_rows_with_FCD_context':count[a,'with_proxy'],
        'hour_OD_proxy_rows_no_FCD_context':count[a,'without_proxy'],
        'mean_model_multiplier_excess_pct_NOT_REAL':round(statistics.fmean(allstat[a]),3),
        'ground_door_to_door_real_OD_rows':0,'uav_delivery_time_results':0,'co2_savings_results':0,
    })
csvsave(OUT/'04_execution_and_coverage_summary.csv',list(summary[0]),summary)

# data availability and analytical gates
readiness=[
 ('E01','FCD raw hours; G1-G5', 'PASS_WITH_RECORDED_LIMITATIONS','Do not reopen September QC'),
 ('E02','OSM directed road network','BUILT_NOT_FORMALLY_VALIDATED','No turn restrictions, verified borders, independent navigation times, or verified delivery OD'),
 ('E02','Real door-to-door hourly time matrix','NOT_READY','Only reference routes and unvalidated sensitivity proxies are available'),
 ('E03','ERA5 two-MY-CIQ hourly weather','PASS_FOR_COARSE_CLIMATE_CONTEXT','ERA5 grid NOT route-height/field measurement; NASA POWER anomalous rain excluded'),
 ('E04','24h joint FCD–ERA5 A/B','PASS_FOR_DESCRIPTIVE_ANALYSIS','Regional FCD not directed-edge speed; 70% FCD-hour coverage flag'),
 ('E05','D1/D2 verified demand and site plot','NOT_READY','19 POIs are references, not approved pads or real orders'),
 ('E06','Flight airspace/site/cargo/BVLOS permissions','NOT_READY','No positive flight authorization assumed'),
 ('E06','Aircraft-specific wind/rain/night operating envelopes','NOT_READY','No arbitrary wind/rain threshold treated as safe'),
 ('E07','Weather-responsive dispatch engine smoke test','PASS_FOR_DATA_FLOW_ONLY','Operational UAV release is blocked; ground response time unavailable'),
 ('E07','Comparative truck-vs-UAV time trials','NOT_READY','Requires E02 OD, E05 orders and E06 legal/technical flight feasibility'),
 ('E08','Cost/CO2 emission model','NOT_READY','Need completed tasks, vehicle fuel/electricity and marginal VKT'),
]
csvsave(OUT/'05_RQ_evidence_and_release_gates.csv',['stage','evidence','status','reason'],
        [dict(zip(['stage','evidence','status','reason'],v)) for v in readiness])

policy={
 'release':'V5.3_SMOKE_TEST_NOT_FORMAL_SCI_RESULT',
 'frozen_study_period_local':'2026-05-01T00:00:00 to 2026-09-30T23:59:59 Asia/Kuala_Lumpur',
 'study_areas':['A_Causeway_MY','B_Second_Link_MY'],
 'source_weather':'ERA5 two MY CIQ grid reference points; no NASA POWER rainfall',
 'source_traffic':'V5.2 region-hour FCD statistics (A=145,B=69 candidate FCD nodes)',
 'traffic_hour_min_valid_fraction':0.70,
 'dispatch_decision_order':['land_and_airspace_authorization','cargo_BVLOS_authorization','night_permission_if_relevant', 'site_and_route_evidence','aircraft_specific_weather_limits', 'energy_and_payload', 'ground_fallback'],
 'authorization_defaults':'ALL_UNKNOWN -> NO_UAV_RELEASE',
 'night_window_analytical_proxy':'19:00-05:59 only a grouping flag, not sun calculation nor regulatory statement',
 'rain_exposure_threshold_mm_hour':[0.1,5.0],
 'gust_exposure_threshold_ms':[10.0],
 'exposure_thresholds_note':'descriptive, NOT manufacturer weather operating limits or weather flight-ban thresholds',
 'aircraft_comparison':['Matternet M2','Matternet M3','DJI FlyCart 30'],
 'aircraft_operating_limits':'NOT_VALIDATED; leave blank until manufacturer/operator evidence documented',
 'vehicle_model':'OSM static reference time / area-hour median FCD-to-development-P90 ratio',
 'vehicle_model_status':'MATHEMATICAL_SENSITIVITY_PROXY; NOT DIRECTED EDGE FCD, NOT OBSERVED REAL OD',
 'night_no_authorization_action':'NO_UAV_RELEASE -> GROUND_ONLY_IF_LEGAL_ROUTE_AND_OD_VALIDATED',
 'time_outputs':'No validated freight door-to-door time or UAV time until required inputs verified',
 'blocked_claims':['no UAV time savings','no vehicle km reductions','no carbon savings','no economic ROI','no authorized site/flight corridor'],
 'scenarios':'Previously frozen 16 core + max 8 aircraft comparison; none operationally run here',
 'source_paths':[str(E02),str(E04)],
}
(OUT/'06_operating_policy_frozen.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2),encoding='utf-8')

for f in [E02,E04]:
    assert f.exists()
sha=[]
for f in [E02,E04]+[x for x in sorted(OUT.iterdir()) if x.is_file() and x.name not in ('07_SHA256_manifest.csv','08_independent_QA.json')]:
    sha.append({'file':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
csvsave(OUT/'07_SHA256_manifest.csv',['file','bytes','sha256'],sha)
qa={
 'area_hours':len(hour_rows),'reference_OD_rows':len(static),
 'model_OD_rows':sum(count[(a,'total')] for a in 'AB'),
 'model_OD_rows_with_FCD':sum(count[(a,'with_proxy')] for a in 'AB'),
 'model_OD_rows_without_FCD':sum(count[(a,'without_proxy')] for a in 'AB'),
 'two_area_timestamp_grid_matched':True,
 'one_unique_area_hour':True,
 'no_weather_missing':True,
 'operational_UAV_flights_released':0,
 'verified_real_freight_OD':0,
 'no_fabricated_night_licence':True,
 'route_time_simulation_proxy_not_validated':True,
 'reference_OD_sum':91,'active_core_simulation_combinations':0,
 'summary':summary
}
(OUT/'08_independent_QA.json').write_text(json.dumps(qa,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(qa,ensure_ascii=False,indent=2))
