from pathlib import Path
import csv,json,hashlib,zipfile,datetime
from artifact_tool import Workbook,SpreadsheetFile
root=Path('/mnt/data/JB_CIQ_剩余实验进度_V4_5'); root.mkdir(exist_ok=True)
status=[
['E01','交通基础清洗与统计','已完成基础处理（带既有保留意见）','无新增数据需求；冻结原交通版本','不复核9月；既有质量限制留在附录','G1–G5 / 345节点 / 153天','RQ2','FROZEN_WITH_LIMITATIONS'],
['E02','真实有向道路网、FCD边匹配、车辆OD','未完成，最关键阻塞','OSM有向边、通行方向/转弯、边长、边ID；固定D1/D2 OD；导航抽样','有向图可路由；FCD匹配误差表；OD时间矩阵；时间外部校验','路网GeoPackage/GraphML、edge_node_join、OD_time_matrix','RQ2','BLOCKED'],
['E03','5–9月历史降雨与风资料','外部已报告下载，等待文件验收','实际ERA5/NASA原始数据文件、四点坐标、产品与时区/单位/来源；NEA可选','153天3672小时；四点空间覆盖需核验；降雨强度与累计值需区分','气象原始档案、数据字典、数据质量报告','RQ3','PENDING_INGEST'],
['E04','交通天气时空联合数据库','未完成，依赖E03','E03标准化时序+345节点天气映射+E01冻结交通','按Kuala Lumpur小时一对一连接；不重复天气修正速度；缺失不得记为零','node_hour_weather_join、coverage_QA','RQ2/RQ3','BLOCKED'],
['E05','真实站点与订单OD冻结','仅地点与几何候选初筛','明确地块/接收点坐标及可用性；D1主任务、D2共享订单、重量、时间窗','每个站点有坐标来源、货源、交付能力、道路接入、许可状态；OD固定','site_registry、OD_registry、site_exclusion_log','RQ1/RQ2','BLOCKED'],
['E06','合法三维航段、三机型任务模型','未执行','CAAM现行空域/许可、障碍高度、机型速度/能耗/天气约束、返航/回收','3/4km是初筛；路线高度、绕飞、机型负载、储备与天气都可行','feasible_edges、UAV_mission_energy','RQ1/RQ3','BLOCKED'],
['E07','16+8组同OD地空物流仿真','24组配置冻结未执行','E02+E04+E05+E06','两CIQ两模式两半径两需求、同OD同时间对比地面基准；不追加组合','results_service_time、delivery_rate、vehicle_km','RQ2','BLOCKED'],
['E08','碳排放与经济学验收','未执行','车辆燃油/电耗、无人机电耗、站点CapEx/OpEx、电网因子、E07结果','相同订单完成口径；CO2e/单、RM/单、场景对照与不确定性','results_co2_cost、sensitivity','RQ3','BLOCKED'],
]
weather=[
['W01','空间覆盖','外部下载报告为4点；原方案6风场锚点/12降雨格点','取得4点经纬度，计算站点和345节点距离，核对是否包含A/B及12格点；说明缩减范围','不可凭小时100%判断JB整个路网空间完整','BLOCK'],
['W02','时间完整性','2026-05-01至2026-09-30，Asia/Kuala_Lumpur','May744 Jun720 Jul744 Aug744 Sep720；每空间ID应3672小时且时间无重复','4点长表预期4×3672=14688行（仅在逐点逐时格式时）','PASS_WHEN_VERIFIED'],
['W03','NASA降雨量纲','IMERG原半小时降雨通常mm/h','两段30分钟强度r1,r2：每小时累计降雨mm=0.5*r1+0.5*r2','不得将两次mm/h相加为mm；区分API已有小时累计值','BLOCK'],
['W04','ERA5风速风向','风速m/s, 风向0–360°, 时间标记','确认风速10m/阵风变量、风向from/to约定、时区、单位','10m模式风不等于无人机航高实测风','BLOCK'],
['W05','ERA5阵风','核实是瞬时还是前处理期最大阵风','检查字段定义与时间代表性，阵风与平均风不强行一一比较','不得凭10m阵风直接批准低空飞行','BLOCK'],
['W06','数据版本与来源','ERA5 / IMERG实际产品版本、run、下载时间','保留原响应文件、请求、哈希、来源、产品说明；不同产品不混用未注明','不能用来源不明XLSX声称官方历史观测','BLOCK'],
['W07','极值与缺失','降雨≥0、风速≥0、方向[0,360)、异常保留标记','非空率、重复、长恒值、极端值、负值及站点异常统计','缺失不是无雨/无风；无需伪造数据','BLOCK'],
['W08','独立交叉核验','NEA 429；站点样本不足','NEA归为可选验证；有条件使用METMalaysia站点记录','NEA缺失不阻断JB主研究；不得称其完整','NON_BLOCKING'],
['W09','季风分类','2026年5—9月主要是西南季风研究窗口','记录METMalaysia公告起止和事件日，不把每小时模型值标成官方季风观测','不宣称东北/西南季风实证对比','PASS_WHEN_DOCUMENTED'],
['W10','E04时空映射','逐交通节点×同一小时','每条FCD记录最多一条映射气象，不扩行；保留网格ID、采样距与来源','最终联合行数仍应=1,266,840（左连接时）','BLOCK'],
]
road=[
['R01','正式研究范围','A/B两个口岸及境内道路，多节点OD','将真实候选站点、指定道路及支路投影至同一坐标系','研究范围与路网边界GeoJSON','P0'],
['R02','道路数据获取','OSM PBF可路由拓扑优先；固定快照日期','Geofabrik完整地区数据取得后裁切到A/B研究区','PBF文件/下载SHA/版本记录','P0'],
['R03','有向网络','单行、逆行、道路分类、转向','构建含oneway和Turn restrictions的机动车有向图','road_edges + road_nodes + restrictions','P0'],
['R04','道路长度与坐标','米/公里一致，WGS84与投影计算分开','边长来自几何坐标投影；排除0长度及跳跃边','geometry_length_QA.csv','P0'],
['R05','马来西亚域约束','不将新加坡境内无人机链路引入','边境道路仅用于合规地面过境背景；境内OD仅路由MY侧','MY_boundary_and_edge_cut.csv','P0'],
['R06','FCD道路边匹配','Node_ID + 对应路名与方向','按同名路+最近可通行边+匹配距离+方向规则，无法匹配留空','node_to_edge_audit.csv','P0'],
['R07','时变边速度','FCD小时速度用于有证据匹配边','未知边速不得使用G组均速直接声称为实测；默认值另设假设标记','edge_hour_speed.csv','P1'],
['R08','订单起终点','D1 CIQ相关快件主任务、D2即时配送扩展','确认真实设施点/模拟需求分布并标注类型；道路接入点固定','OD_registry.csv','P1'],
['R09','路径和旅行时间','分时间窗口、实际道路长和速度','最短合法路径/最短时间路线，额外装卸和等待独立核算','OD_hour_time.csv','P1'],
['R10','独立校核','导航或现场行程时间样本','地理连通、不可达比例、往返差、速度合理性、路程和ETA误差','OD_external_validation.csv','P1'],
]
phases=[
['1','立刻','接受交通E01冻结结果，停止9月循环核验','E01保留质量说明，不消耗新实验工时','E01保持FROZEN_WITH_LIMITATIONS'],
['2','并行轨A','取得OSM路网数据，裁剪双CIQ，生成有向图','E02真实路网+匹配框架','R01–R06完成'],
['3','并行轨B','你完成气象下载，本轮审计其4点实际坐标与小时数据','E03原始档案、数据质量报告','W01–W09通过；NEA可选'],
['4','双轨对齐','E02真实路线+E03合格天气合成E04','345节点逐小时交通—天气联合库','W10+E02路径质量验收'],
['5','运营网络','E05补土地/物流OD，E06加入空域与机型物理约束','可执行的多节点车-机网络','GATE A–F逐项满足'],
['6','正式实验','严格执行既定16+8配置，B0对照，输出E07 E08','RQ1–RQ3最终证据','不增加实验情景'],
]
sources=[
['Geofabrik道路数据','https://download.geofabrik.de/asia/malaysia-singapore-brunei.html','路网PBF/GeoPackage下载门户；需按日期固定版本','网页验证，原始数据未在本地下载'],
['NASA IMERG说明','https://gpm.nasa.gov/resources/faq/how-intensity-precipitation-distributed-within-given-data-value-imerg','半小时降雨强度mm/h及小时累计量纲换算','官方说明已核实'],
['ECMWF ERA5资料','https://cds.climate.copernicus.eu/datasets/reanalysis-era5-single-levels-timeseries?tab=download','10米风与阵风、时间字段和产品说明','官方资料已核实'],
['上一版交通E01留档','/mnt/data/JB_CIQ_E01_E02_V4_3/E01_traffic_calendar_corrected_345nodes_2026_05-09.csv.gz','345节点153天修正交通数据库','本地文件存在'],
['上一版空间映射','/mnt/data/JB_CIQ_E01_E04_V4_1/weather/01_345node_to_12GPM_6wind_anchor_mapping.csv','12个IMERG网格及6个风速锚点映射','本地文件存在'],
['最新气象下载截图','/mnt/data/image.png','本地Codex五个月下载完成声明和NEA HTTP429','只有截图；未收到原始XLSX/CSV'],
]
def write(name,header,rows):
 p=root/name
 with p.open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.writer(f);w.writerow(header);w.writerows(rows)
 return p
write('01_实验总进度.csv',['阶段','内容','状态','需要补充','验收条件','产出','RQ','状态码'],status)
write('02_气象验收规则.csv',['编号','门槛','现状','需核查','易犯错误','结果'],weather)
write('03_E02道路数据补齐.csv',['编号','模块','输入','计算或校核动作','输出','优先级'],road)
write('04_最短执行路径.csv',['序号','阶段','执行任务','交付物','停止或放行条件'],phases)
write('05_证据来源.csv',['名称','URL或已存在文件路径','用途','状态'],sources)
# template only, intentionally no fake values
write('06_气象标准化数据模板_仅表头.csv',['site_id','timestamp_local','source','source_product','source_run','latitude','longitude','rain_mm_hour','wind_speed_10m_ms','wind_gust_10m_ms','wind_direction_10m_deg','source_quality_flag','raw_source_file'],[])
readme='''# JB–CIQ E02–E08进度与气象数据验收 V4.5\n\n审查日期：2026-10-26。研究边界：2026-05-01至09-30、345 FCD节点、Causeway/Second Link、RQ1–RQ3、冻结16+8组。\n\n## 判定\n- E01不重新检查9月数据；保留此前已知限制，作为固定版本输入。\n- 当前环境中存在原始交通数据和E01修正派生库，但没有你本地Codex刚下载的ERA5/NASA源文件。下载完成是**截图中的外部声明**，不等于已独立验收。\n- 截图显示4个气象点，而此前的E03空间计划配置为12个NASA网格+6个风场锚点。这不是自动失败：先读取4点坐标、格点归属和与A/B真实站点的距离，再判定代表性。若只涵盖局部，缩小气象结论的空间适用范围；不得声称覆盖整个345节点网络。\n- NEA受到HTTP 429限制，作为补充验证源，不阻塞JB主论文；数据完整性不足必须如实记录。\n- E02缺的是有向道路路网（不是345个速度点），当前的FCD点链几何代理不能用作真实货车OD时间。\n\n## 理论检查数量（只用于验收，不是观测值）\n- 153天：五月744小时，六月720，七月744，八月744，九月720；合计每点3672小时。\n- 四个气象点完整的“逐点逐小时长表”预期为14688条；6点应为22032条。具体仍依文件实际布局验收。\n- 如果要覆盖已冻结的12个GPM网格，每格每小时均有降雨，小时长表理论条数应为44064；源半小时序列应为88128条。不能拿4点小时完整率代替12网格空间完整率。\n- NASA IMERG若原值为每半小时的mm/h强度，应以0.5×rate_t1+0.5×rate_t2计算小时降雨量mm；先核实你的新文件是否已经聚合为mm。\n- E04左连接目标：不因合并新增/删除交通行，共1266840条，另记录实际有雨风匹配的数据比例与未知状态。\n\n## 现在的最短行动\n1. 用户电脑：保留ERA5/NASA原始CSV/XLSX、接口返回值、下载脚本、产品版本、点位经纬度及SHA256；NEA保留429与部分采样声明即可。\n2. 同时取得Johor研究区域的有向OSM道路快照，优先PBF；检查合法单向规则与转向限制，再关联345个FCD查询点。Geofabrik下载地址见05来源表。\n3. 先形成路网准入检查和实际OD登记，不将现有4条几何代理线变成真实OD。\n4. 气象实际文件到位后逐项通过02验收表，再执行E04，不继续增加月份或机型。\n\n## 文件说明\n- 01 实验总进度；02 气象验收规则；03 E02道路补齐；04 最短执行路径；05 数据证据来源；06 气象标准化模板；Excel工作簿为相同内容的结构化留档。\n\n注意：本轮没有获取真实OSM路网或用户本机的气象时序，也没有运行E04及无人机仿真。\n'''
(root/'00_审查结论与执行顺序.md').write_text(readme,encoding='utf-8')
# artifact_tool workbook
wb=Workbook.create()
data=[('总进度', ['阶段','内容','状态','需补充','验收条件','产出','RQ','状态码'],status),('气象验收',['编号','门槛','现状','需核查','禁止错误','结果'],weather),('E02路网',['编号','模块','必要输入','计算/校核','输出','优先级'],road),('执行路径',['序号','阶段','任务','交付物','放行条件'],phases),('来源登记',['名称','URL/路径','用途','当前状态'],sources)]
for tab,header,rows in data:
 s=wb.worksheets.add(tab)
 cols=len(header); n=1+len(rows)
 s.get_range_by_indexes(0,0,1,cols).values=[header]
 if rows:s.get_range_by_indexes(1,0,len(rows),cols).values=rows
 from artifact_tool import RangeFormatConfig
 s.get_range_by_indexes(0,0,1,cols).format={'fill':'#17324C','font':{'bold':True,'color':'#FFFFFF'},'row_height':30,'vertical_alignment':'center'}
 s.get_range_by_indexes(1,0,max(1,len(rows)),cols).format.row_height=29
 s.get_range_by_indexes(1,0,max(1,len(rows)),cols).format.wrap_text=True
 for j in range(cols):
  col=s.get_range_by_indexes(0,j,n,1)
  col.format.column_width= 14 if j==0 else (20 if j==cols-1 else 32)
 s.freeze_panes.freeze_rows(1)
# cover
s=wb.worksheets.add('说明')
s.get_range('A1:D1').merge_cells() if False else None
s.get_range('A1').values=[['JB–CIQ E02–E08实验剩余任务审核｜V4.5']]
s.get_range('A1').format={'font':{'bold':True,'size':18,'color':'#17324C'},'row_height':35}
s.get_range('A3:B9').values=[['审查日期','2026-10-26'],['本轮约束','不再重复检验9月交通异常'],['E01','基础数据冻结且保留已知局限'],['E02','优先补有向路网、FCD边匹配和OD'],['E03','外部报告ERA5/NASA完成；待原始文件验收'],['E04','气象与交通统一时间戳匹配未运行'],['实验矩阵','16核心+8机型补充，不新增']]
s.get_range('A3:A9').format={'fill':'#EDF2F7','font':{'bold':True,'color':'#17324C'}}
s.get_range('A:A').format.column_width=26;s.get_range('B:B').format.column_width=70
# Export and basic check
out=root/'JB_CIQ_剩余实验与气象验收追踪_V4.5.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(out))
print('workbook',out, out.stat().st_size)
print(wb.inspect({'kind':'table','range':'总进度!A1:C5','include':'values','table_max_rows':5,'table_max_cols':3}).ndjson[:800])
print('files',len(list(root.iterdir())))
# ZIP all except source script / zip; include reproducible script itself
manifest=[]
for p in sorted(root.iterdir()):
 if p.is_file() and not p.name.endswith('.zip') and p.name!='07_SHA256_manifest.csv':
  manifest.append([p.name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()])
write('07_SHA256_manifest.csv',['filename','bytes','sha256'],manifest)
zipname=Path('/mnt/data/JB_CIQ_E02-E08_剩余任务与气象验收_V4.5.zip')
with zipfile.ZipFile(zipname,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(root.iterdir()):
  if p.is_file():z.write(p,p.name)
with zipfile.ZipFile(zipname) as z: print('ZIP',zipname,zipname.stat().st_size,len(z.namelist()),z.testzip())
