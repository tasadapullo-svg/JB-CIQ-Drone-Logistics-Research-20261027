import csv,json,os
from pathlib import Path
from artifact_tool import Workbook,SpreadsheetFile
D=Path('/mnt/data/JB_CIQ_E04_V5_2')
def rows(n):
 with (D/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
met=json.loads((D/'10_metrics_and_freeze.json').read_text())
wb=Workbook.create()
headfmt={'fill':'#16324F','font':{'bold':True,'color':'#FFFFFF'},'row_height':24,'horizontal_alignment':'center'}
def sheet(name, headers, data, widths=None, title=None):
 s=wb.worksheets.add(name)
 col=len(headers)
 s.get_range_by_indexes(0,0,1,col).values=[headers]
 if data:
  s.get_range_by_indexes(1,0,len(data),col).values=data
 s.get_range_by_indexes(0,0,1,col).format=headfmt
 s.freeze_panes.freeze_rows(1)
 for j in range(col):
  letter=chr(65+j) if j<26 else None
  if letter:
   s.get_range(f'{letter}:{letter}').format.column_width=(widths[j] if widths else min(34,max(12,len(str(headers[j]))+2)))
 return s

# Dashboard with no unsupported claims.
DASH=wb.worksheets.add('00_Dashboard')
summary=[['JB–CIQ E04 · 24小时交通×ERA5联合实验 V5.2',''],
 ['实验周期','2026-05-01 to 2026-09-30'],['固定区域','A Causeway (145 FCD); B Second Link (69 FCD)'],
 ['全天小时范围','00:00–23:59 UTC+08:00'],['研究天数',153],['每区小时数',3672],['A+B区域小时数',7344],
 ['A+B节点—小时记录数',785808],['A区有效速度节点—小时',met['by_area']['A']['valid_speed_node_hours']],
 ['B区有效速度节点—小时',met['by_area']['B']['valid_speed_node_hours']],
 ['A区≥70%节点覆盖小时',met['by_area']['A']['traffic_eligible_hours_ge70pct']],
 ['B区≥70%节点覆盖小时',met['by_area']['B']['traffic_eligible_hours_ge70pct']],
 ['全24小时ERA5天气缺失','0（区域小时）'],
 ['E02真实车辆OD','尚未验收；E04速度不等于行程时间'],
 ['无人机夜航许可','未知：24h观测不代表24h可飞'],
 ['雨量源','ERA5网格；NASA POWER异常数据隔离'],
 ['速度基准','5–7月各FCD节点P90；8–9月保留评价期'],
 ['小时准入','每区固定FCD节点≥70%具有效正速度'],
 ['日准入','全天24小时中至少18个小时达到上述门槛'],
 ['E04结论','仅限道路速度缺损与天气关联；不推断因果/节时/减排']]
DASH.get_range(f'A1:B{len(summary)}').values=summary
DASH.get_range('A1:B1').format={'fill':'#16324F','font':{'bold':True,'color':'#FFFFFF','size':14},'row_height':32}
DASH.get_range('A2:A20').format={'font':{'bold':True}}
DASH.get_range('A:A').format.column_width=31
DASH.get_range('B:B').format.column_width=73
DASH.freeze_panes.freeze_rows(1)

byh=rows('02_AB_hour_of_day_24h.csv')
dictby={(x['area'],int(x['hour_local'])):x for x in byh}
arr=[]
for h in range(24):
 a=dictby['A',h];b=dictby['B',h]
 arr.append([h,float(a['mean_node_speed_deficit_eligible']),float(b['mean_node_speed_deficit_eligible']),None,None,
 float(a['traffic_hour_eligible_fraction']),float(b['traffic_hour_eligible_fraction']),
 float(a['rainy_hour_fraction']),float(b['rainy_hour_fraction'])])
s=sheet('01_24h_by_hour',['Hour','A deficit (fraction)','B deficit (fraction)','A deficit (%)','B deficit (%)','A pass fraction','B pass fraction','A wet fraction','B wet fraction'],arr,[10,23,23,19,19,19,19,18,18])
s.get_range('D2').formulas=[['=B2*100']];s.get_range('D2:D25').fill_down()
s.get_range('E2').formulas=[['=C2*100']];s.get_range('E2:E25').fill_down()
try:
 chart=s.charts.add('line',{'title':'24h speed deficit (%), area A vs B','has_legend':True})
 for label,idx in [('A Causeway','D'),('B Second Link','E')]:
  ser=chart.series.add(label)
  ser.category_formula="'01_24h_by_hour'!$A$2:$A$25"
  ser.formula=f"'01_24h_by_hour'!${idx}$2:${idx}$25"
 chart.set_position('K2','S18')
except Exception as exc:print('Workbook chart skipped:',type(exc).__name__,str(exc)[:300])

def simplify(src, dest, fields, casts={}, widths=None):
 rr=rows(src);m=[]
 for r in rr:
  o=[]
  for k in fields:
   x=r[k]
   if x=='':x=None
   elif k in casts:x=casts[k](x)
   o.append(x)
  m.append(o)
 sheet(dest,fields,m,widths)

simplify('05_AB_month_all_day.csv','02_Month_summary',list(rows('05_AB_month_all_day.csv')[0]),casts={'month':int,'n_corridor_hours':int,'n_traffic_eligible_hours':int,'traffic_hour_eligible_fraction':float,'mean_fcd_node_coverage':float,'mean_node_speed_deficit_eligible':float,'mean_rain_mm_h':float,'rainy_hour_fraction':float,'high_gust_fraction':float})
simplify('04_AB_month_daypart_24h.csv','03_Month_daypart',list(rows('04_AB_month_daypart_24h.csv')[0]),casts={'month':int,'n_corridor_hours':int,'n_traffic_eligible_hours':int,'traffic_hour_eligible_fraction':float,'mean_fcd_node_coverage':float,'mean_node_speed_deficit_eligible':float,'mean_rain_mm_h':float,'rainy_hour_fraction':float,'high_gust_fraction':float})
simplify('11_weather_traffic_adjusted_24h.csv','04_Weather_Stats',list(rows('11_weather_traffic_adjusted_24h.csv')[0]))
simplify('13_daypart_bootstrap_effects_24h.csv','05_Daypart_comparisons',list(rows('13_daypart_bootstrap_effects_24h.csv')[0]))
simplify('09_independent_structural_QA.csv','06_Structure_QA',list(rows('09_independent_structural_QA.csv')[0]))
notes=[
 ['版本','E04 V5.2 24h 全时段; 替代V5.1 3窗口主分析'],
 ['A/B范围','E02冻结研究窗口，145+69 FCD节点；不向345全市外推'],
 ['时间单位','GMT+08:00；每小时起始到下一小时（左闭右开）'],
 ['数据来源','FCD原始节点速度 + ERA5两处马来西亚格点再分析'],
 ['有效速度','正数且有限；缺失保留，未填补'],
 ['阈值','主要统计按≥70%节点可用的区域小时；全部小时记录照常留存'],
 ['夜间','只作为道路与气象统计，不代表获得UAV夜航许可'],
 ['高阵风','5-7月P75统计分类，不是厂商适飞阈值'],
 ['雨天','ERA5雨量≥0.1mm/h，为降雨代理，不证明无雨=晴天'],
 ['强雨','ERA5雨量≥5mm/h，仅描述性分层'],
 ['回归','月、24小时、星期固定效应 + 按日期聚类标准误；非因果'],
 ['单元','道路观察是区域小时而非一个节点一个独立样本'],
 ['P90','2026年5-7月开发期节点基线，8-9月评价期未参与拟合'],
 ['关键禁止推断','不支持真实OD旅行时间、无人机可飞率、实际节时、碳减排、因果影响'],
 ['异常源','NASA POWER降雨异常，未加入本次E04'],
 ['存档','主压缩包附脚本、完整小时联合表和源文件SHA256'],
 ['ERA5来源','https://cds.climate.copernicus.eu/'],
 ['E04输入','/mnt/data/JB_CIQ_E04_V5_1/E04_FCD214_ERA5_2026_05_09_FULL.csv.gz'],
 ['ERA5参考','/mnt/data/E03_ERA5_JB_TWO_CIQ_WEATHER_HOURLY.csv']]
sheet('07_Freeze_and_sources',['审查类别','决定/来源'],notes,[25,92])
check=wb.inspect({'kind':'table','range':'01_24h_by_hour!A1:E5','include':'values,formulas','table_max_rows':5,'table_max_cols':5})
print('EXCEL_INSPECT',check.ndjson[:1500])
error=wb.inspect({'kind':'match','search_term':'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A','options':{'use_regex':True,'max_results':40},'summary':'error check'})
print('FORMULA_ERROR_SCAN',error.ndjson[:350])
out=D/'E04_24小时_交通天气全时段分析与验收_V5.2.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(out))
print('Saved',out,out.stat().st_size)
