"""E04 v5.2: all-day 24h A/B traffic-weather analysis, source-driven, reproducible.
No change to frozen nodes, speed values or ERA5; no road-edge or UAV results.
"""
import csv,gzip,os,json,math,statistics,collections,datetime,hashlib,random
from pathlib import Path
import numpy as np
OUT=Path('/mnt/data/JB_CIQ_E04_V5_2');OUT.mkdir(parents=True,exist_ok=True)
SRC=Path('/mnt/data/JB_CIQ_E04_V5_1/E04_FCD214_ERA5_2026_05_09_FULL.csv.gz')
WXSRC=Path('/mnt/data/E03_ERA5_JB_TWO_CIQ_WEATHER_HOURLY.csv')
DAYS=(datetime.date(2026,9,30)-datetime.date(2026,5,1)).days+1
NODES={'A':145,'B':69}
PARTS={'Night':set(range(0,6)),'Morning':set(range(6,12)),'Afternoon':set(range(12,18)),'Evening':set(range(18,24))}
HOUR_MIN_COVERAGE=.70;DAY_MIN_ELIGIBLE_HOURS=18

def daypart(h): return next(k for k,v in PARTS.items() if h in v)
def num(x):
 try:
  y=float(x);return y if math.isfinite(y) else None
 except (TypeError,ValueError):return None

def write(name,rows,fields=None):
 rows=list(rows)
 if fields is None: fields=list(rows[0].keys())
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
 return len(rows)

# Existing prejoined table is 24h complete despite previous three-window analysis; reuse original unaltered observations.
D=collections.defaultdict(lambda:{'valid':0,'total':0,'speed':[],'ratios':[],'deficits':[],'w':None,'weather_consistency':False})
state=collections.Counter(); by_node=collections.Counter()
with gzip.open(SRC,'rt',newline='',encoding='utf-8-sig') as f:
 for r in csv.DictReader(f):
  a=r['area'];ts=r['timestamp_local'];hour=int(r['hour_local']);date=r['date_local'];t=f'{date} {hour:02d}'
  assert a in NODES and ts[:10]==date,(a,ts,date)
  st=(a,t);g=D[st];g['total']+=1;by_node[(a,r['node_id'])]+=1
  wx=tuple(r[k] for k in ['precip_mm_hour','wind10_ms','wind100_ms','gust10_ms','gust_high_devP75','weather_point','weather_grid'])
  if g['w'] is not None and wx!=g['w']:g['weather_consistency']=True
  g['w']=wx
  good=int(r['speed_valid'])==1 and num(r['speed_raw']) is not None and num(r['speed_raw'])>0
  if good:
   v=num(r['speed_raw']); ratio=num(r['speed_ratio_to_P90']);defi=num(r['speed_deficit_fraction'])
   assert ratio is not None and defi is not None
   g['valid']+=1;g['speed'].append(v);g['ratios'].append(ratio);g['deficits'].append(defi)
  state[(a,'total')]+=1;state[(a,'valid')]+=good;state[(a,'missing')]+=not good
  if r['weather_provenance']!='ERA5_GRID_REANALYSIS':raise ValueError('unexpected weather source')
assert len(D)==2*DAYS*24,(len(D),DAYS)
for a,n in NODES.items():
 assert state[(a,'total')]==n*DAYS*24
 assert len([x for x in by_node if x[0]==a])==n
 assert all(by_node[(a,node)]==DAYS*24 for x,node in by_node if x==a)

# Aggregate at independent corridor-hour level rather than treating 214 sensor points as independent time observations.
hours=[]
for (a,t),g in sorted(D.items()):
 day=t[:10];h=int(t[11:]);date=datetime.date.fromisoformat(day)
 assert g['total']==NODES[a] and not g['weather_consistency'],(a,t,g['total'])
 w=g['w']; cov=g['valid']/NODES[a]
 row={'area':a,'timestamp_local_hour':t,'date_local':day,'month':date.month,
 'weekday_Mon0':date.weekday(),'is_weekend':int(date.weekday()>=5),'hour_local':h,'daypart':daypart(h),
 'data_split':'dev_MayJul' if date.month<=7 else 'holdout_AugSep',
 'n_fcd_nodes':NODES[a],'n_positive_speeds':g['valid'],'fcd_positive_speed_coverage':round(cov,7),
 'passes_70pct_fcd_speed':int(cov>=HOUR_MIN_COVERAGE),
 'median_speed_raw':round(float(np.median(g['speed'])),6) if g['speed'] else '',
 'median_ratio_to_dev_P90':round(float(np.median(g['ratios'])),7) if g['ratios'] else '',
 'mean_node_speed_deficit':round(float(np.mean(g['deficits'])),7) if g['deficits'] else '',
 'median_node_speed_deficit':round(float(np.median(g['deficits'])),7) if g['deficits'] else '',
 'ERA5_precip_mm_hour':num(w[0]),'wet_ge_0p1mm':int(num(w[0])>=.1),'heavy_ge_5mm':int(num(w[0])>=5),
 'ERA5_wind10_ms':num(w[1]),'ERA5_wind100_ms':num(w[2]),'ERA5_gust10_ms':num(w[3]),
 'gust_ge_MayJul_P75':int(w[4]),'ERA5_point':w[5],'ERA5_grid':w[6],
 'traffic_interpretation':'FCD_NODE_HOURLY_OBSERVATION_NOT_OD_TRAVEL_TIME',
 'weather_interpretation':'ERA5_GRID_PROXY_NOT_SITE_MEASUREMENT'}
 hours.append(row)
assert len(hours)==7344
write('01_AB_24h_hourly_joint.csv',hours)

# hour-by-hour mean (24 rows per area), grouped monthly+hour (240), daypart per month (40)
def collapse(rows,keys):
 acc=collections.defaultdict(list)
 for r in rows:acc[tuple(r[k] for k in keys)].append(r)
 out=[]
 for ky,items in sorted(acc.items()):
  passed=[r for r in items if r['passes_70pct_fcd_speed']==1]
  vals=[r['mean_node_speed_deficit'] for r in passed if r['mean_node_speed_deficit']!='']
  x={key:val for key,val in zip(keys,ky)}
  x.update({'n_corridor_hours':len(items),'n_traffic_eligible_hours':len(passed),
   'traffic_hour_eligible_fraction':round(len(passed)/len(items),6),
   'mean_fcd_node_coverage':round(float(np.mean([r['fcd_positive_speed_coverage'] for r in items])),6),
   'mean_node_speed_deficit_eligible':round(float(np.mean(vals)),7) if vals else '',
   'mean_rain_mm_h':round(float(np.mean([r['ERA5_precip_mm_hour'] for r in items])),4),
   'rainy_hour_fraction':round(float(np.mean([r['wet_ge_0p1mm'] for r in items])),6),
   'high_gust_fraction':round(float(np.mean([r['gust_ge_MayJul_P75'] for r in items])),6)})
  out.append(x)
 return out
write('02_AB_hour_of_day_24h.csv',collapse(hours,['area','hour_local']))
write('03_AB_month_hour_24h.csv',collapse(hours,['area','month','hour_local']))
write('04_AB_month_daypart_24h.csv',collapse(hours,['area','month','daypart']))
write('05_AB_month_all_day.csv',collapse(hours,['area','month']))
write('06_AB_hour_weekend_split_24h.csv',collapse(hours,['area','is_weekend','hour_local']))

# Daily all-24h replicates, preserve non-eligible day labels; don't remove low-coverage nights.
daily=[]
for (a,date),samples in sorted(collections.defaultdict(list,{}).items()):pass
perday=collections.defaultdict(list)
for h in hours:perday[(h['area'],h['date_local'])].append(h)
for (a,date),rr in sorted(perday.items()):
 rr.sort(key=lambda r:r['hour_local']); assert [r['hour_local'] for r in rr]==list(range(24))
 elig=[r for r in rr if r['passes_70pct_fcd_speed']==1]
 dvals=[r['mean_node_speed_deficit'] for r in elig if r['mean_node_speed_deficit']!='']
 total_rain=sum(r['ERA5_precip_mm_hour'] for r in rr)
 daily.append({'area':a,'date_local':date,'month':int(date[5:7]),'weekday_Mon0':rr[0]['weekday_Mon0'],
  'n_hours_expected':24,'n_weather_complete_hours':sum(all(r[k] is not None for k in ['ERA5_precip_mm_hour','ERA5_wind10_ms','ERA5_gust10_ms']) for r in rr),
  'n_fcd_eligible_hours':len(elig),'passes_18of24_traffic_hours':int(len(elig)>=DAY_MIN_ELIGIBLE_HOURS),
  'mean_speed_coverage_24h':round(float(np.mean([r['fcd_positive_speed_coverage'] for r in rr])),6),
  'mean_node_speed_deficit_valid_hours':round(float(np.mean(dvals)),7) if dvals else '',
  'day_ERA5_rain_total_mm':round(total_rain,4),'wet_hours':sum(r['wet_ge_0p1mm'] for r in rr),
  'heavy_rain_hours':sum(r['heavy_ge_5mm'] for r in rr),'high_gust_hours':sum(r['gust_ge_MayJul_P75'] for r in rr),
  'max_gust10_ms':max(r['ERA5_gust10_ms'] for r in rr),
  'day_wet':int(any(r['wet_ge_0p1mm'] for r in rr)),
  'split':'dev_MayJul' if int(date[5:7])<=7 else 'holdout_AugSep'})
assert len(daily)==306
write('07_AB_daily_24h_replicates.csv',daily)

# Describe rain/wind influence by condition + sample count; these are not causal effects.
weather_groups=[]
for area in ('A','B'):
 for season in ('ALL','dev_MayJul','holdout_AugSep'):
  for wet in (0,1):
   for gust in (0,1):
    rrs=[r for r in hours if r['area']==area and (season=='ALL' or r['data_split']==season) and r['wet_ge_0p1mm']==wet and r['gust_ge_MayJul_P75']==gust]
    if not rrs:continue
    usable=[r for r in rrs if r['passes_70pct_fcd_speed']==1]
    weather_groups.append({'area':area,'data_split':season,'wet':wet,'high_gust_proxy':gust,
     'all_hours':len(rrs),'traffic_eligible_hours':len(usable),
     'eligible_hour_fraction':round(len(usable)/len(rrs),6),
     'mean_speed_deficit_eligible':round(float(np.mean([r['mean_node_speed_deficit'] for r in usable])),7) if usable else '',
     'note':'observational association; 10m gust P75 not UAV no-fly threshold'})
write('08_AB_wet_gust_descriptive_24h.csv',weather_groups)

# Strict QA counts + sequential calendar.
from collections import Counter
byarea={a:[r for r in hours if r['area']==a] for a in NODES}
qa=[]
def gate(label,expected,actual):qa.append({'gate':label,'expected':expected,'actual':actual,'pass':actual==expected})
gate('study_calendar_days',153,DAYS)
gate('study_FCD_membership_count',214,sum(NODES.values()))
gate('full_area_hour_rows',7344,len(hours))
gate('full_FCD_node_hour_rows',785808,sum(v for (a,typ),v in state.items() if typ=='total'))
gate('daily_area_replicates',306,len(daily))
gate('monthly_hour_rows',240,2*5*24)
gate('all_hours_present_each_area',3672,min(len(rows) for rows in byarea.values()))
gate('all_weather_nonmissing_area_hours',7344,sum(all(r[k] is not None for k in ('ERA5_precip_mm_hour','ERA5_wind10_ms','ERA5_gust10_ms')) for r in hours))
gate('no_hourly_node_count_mismatch',0,sum(1 for (a,t),g in D.items() if g['total']!=NODES[a]))
gate('no_weather_inconsistent_within_area_hour',0,sum(1 for (a,t),g in D.items() if g['weather_consistency']))
gate('no_repeated_area_hour',0,len(hours)-len({(r['area'],r['timestamp_local_hour']) for r in hours}))
write('09_independent_structural_QA.csv',qa)
for x in qa:assert x['pass'],x
metrics={'version':'E04_V5.2_24H','period':'2026-05-01..2026-09-30','hours':[0,23],
 'dayparts':{k:sorted(v) for k,v in PARTS.items()}, 'study_node_membership':NODES,'climate':'ERA5 2 MY 0.25deg reanalysis cells',
 'traffic':'FCD per-node hourly, no OD inference','daypart_hours':'fixed six-hour blocks, 24h primary all-hour','n_area_hours':len(hours),
 'n_node_hours':sum(v for (a,typ),v in state.items() if typ=='total'),
 'hour_pass_rule':'valid strictly positive FCD nodes / frozen nodes >=70%, not an excuse to exclude rows',
 'daily_pass_rule':'at least 18 of 24 hours pass 70%, not an excuse to delete days',
 'rain_wet':'>=0.1mm per hour ERA5','rain_heavy':'>=5mm per hour ERA5',
 'gust_high':'development May-Jul P75 of ERA5 10m gust by corridor (NOT flight-safe limit)',
 'development':'May-Jul reference P90 and gust75, holdout Aug-Sep',
 'night_UAV':'NOT AUTHORIZED BY WEATHER DATA','NASA_POWER_rain':'EXCLUDED_PRIOR_QA',
 'by_area':{a:{'node_hours':state[(a,'total')],'valid_speed_node_hours':state[(a,'valid')],
   'speed_coverage':round(state[(a,'valid')]/state[(a,'total')],6),
   'area_hours':len(byarea[a]),'traffic_eligible_hours_ge70pct':sum(r['passes_70pct_fcd_speed'] for r in byarea[a]),
   'daily_replicates':153,'daily_pass_18of24':sum(r['passes_18of24_traffic_hours'] for r in daily if r['area']==a),
   'rainy_hours':sum(r['wet_ge_0p1mm'] for r in byarea[a]),
   'heavy_rain_hours':sum(r['heavy_ge_5mm'] for r in byarea[a])} for a in NODES},
 'QA':qa, 'inputs':[str(SRC),str(WXSRC)]}
(OUT/'10_metrics_and_freeze.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(metrics['by_area'],ensure_ascii=False,indent=2))
