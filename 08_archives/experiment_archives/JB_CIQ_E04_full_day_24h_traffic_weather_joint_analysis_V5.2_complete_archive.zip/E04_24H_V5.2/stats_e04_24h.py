"""Day-clustered, hour-controlled noncausal weather-traffic association; full 24h."""
import csv,collections,datetime,json,math
from pathlib import Path
import numpy as np
import statsmodels.api as sm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=Path('/mnt/data/JB_CIQ_E04_V5_2')

def load(name):
 with (OUT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def save(name,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),extrasaction='ignore');w.writeheader();w.writerows(rows)
hrs=load('01_AB_24h_hourly_joint.csv');daily=load('07_AB_daily_24h_replicates.csv')
# Development 5-7 is fixed P90 and P75 training; the Aug-Sep association is held-out primary.
association=[];primary=[]
for area in ['A','B']:
 for split in ['holdout_AugSep','ALL']:
  R=[r for r in hrs if r['area']==area and int(r['passes_70pct_fcd_speed'])==1 and (split=='ALL' or r['data_split']==split)]
  y=np.asarray([float(r['mean_node_speed_deficit']) for r in R],dtype=float)
  # intercept + two meteorological flags + month factors + 23 hours + six weekdays.
  months=sorted({int(r['month']) for r in R})
  names=['Intercept','wet_hour','dev_high_gust']+[f'Month_{i}' for i in months[1:]]+[f'Hour_{i}' for i in range(1,24)]+[f'Weekday_{i}' for i in range(1,7)]
  XX=[]
  for r in R:
   m,h,wd=int(r['month']),int(r['hour_local']),int(r['weekday_Mon0'])
   XX.append([1.,float(r['wet_ge_0p1mm']),float(r['gust_ge_MayJul_P75'])]+[float(m==i) for i in months[1:]]+[float(h==i) for i in range(1,24)]+[float(wd==i) for i in range(1,7)])
  X=np.asarray(XX)
  assert X.shape[1]==len(names),(X.shape,len(names))
  clus=np.array([datetime.date.fromisoformat(r['date_local']).toordinal() for r in R])
  fit=sm.OLS(y,X).fit(cov_type='cluster',cov_kwds={'groups':clus})
  for k in [1,2]:
   lo,hi=fit.conf_int()[k]
   rec={'area':area,'split':split,'term':names[k], 'eligible_area_hours':len(R),
    'cluster_days':len(set(clus)), 'coefficient_speed_deficit_percentage_points':round(float(fit.params[k])*100,4),
    'CI95_low_pp':round(float(lo)*100,4),'CI95_high_pp':round(float(hi)*100,4),'p_raw':float(fit.pvalues[k]),
    'p_Holm_primary_holdout_only':'',
    'adjusted_for':'hour_24levels;calendar_month;weekday;wet_and_gust_mutually',
    'method':'OLS corridor-hour speed deficit, date clustered SE',
    'interpretation':'descriptive association, NOT causality, NOT trip time, NOT UAV flyability'}
   association.append(rec)
   if split=='holdout_AugSep':primary.append(rec)
# Holm 4 tests; Holm step-down
primary.sort(key=lambda q:q['p_raw'])
adjusted=[]
for i,x in enumerate(primary):
 adjusted.append(min(1.,max((len(primary)-j)*primary[j]['p_raw'] for j in range(i+1))))
 x['p_Holm_primary_holdout_only']=adjusted[-1]
save('11_weather_traffic_adjusted_24h.csv',association)

# Paired daily summaries: four 6-hour dayparts as descriptive comparison to night.
parts=['Night','Morning','Afternoon','Evening']
per=collections.defaultdict(list)
for r in hrs:per[(r['area'],r['date_local'],r['daypart'])].append(r)
pair=[]; effects=[]
rg=np.random.default_rng(20261027)
for area in ['A','B']:
 for split in ['holdout_AugSep','ALL']:
  for part in parts[1:]:
   deltas=[]
   for d in sorted({r['date_local'] for r in hrs if r['area']==area}):
    if split=='holdout_AugSep' and d[5:7] not in ('08','09'):continue
    r1=per[(area,d,'Night')];r2=per[(area,d,part)]
    s1=[float(r['mean_node_speed_deficit']) for r in r1 if int(r['passes_70pct_fcd_speed'])==1]
    s2=[float(r['mean_node_speed_deficit']) for r in r2 if int(r['passes_70pct_fcd_speed'])==1]
    if len(s1)<4 or len(s2)<4:continue
    delta=float(np.mean(s2)-np.mean(s1));deltas.append(delta)
    pair.append({'area':area,'split':split,'date_local':d,'comparison':part+'-Night', 'difference_deficit':round(delta,7)})
   vals=np.asarray(deltas)
   if len(vals)==0:continue
   samp=rg.integers(0,len(vals),size=(2000,len(vals)))
   boot=vals[samp].mean(axis=1);low,hi=np.quantile(boot,[.025,.975])
   effects.append({'area':area,'split':split,'comparison':part+'-Night',
    'paired_days_eligible_4of6_each_daypart':len(vals),'mean_difference_pp':round(float(np.mean(vals))*100,3),
    'bootstrap_CI95_low_pp':round(float(low)*100,3), 'bootstrap_CI95_high_pp':round(float(hi)*100,3),
    'interpretation':'positive=slower-than-own-P90 relative to night; not travel time'})
save('12_daypaired_daypart_differences_24h.csv',pair)
save('13_daypart_bootstrap_effects_24h.csv',effects)

# Matched A minus B at same calendar day+hour; only when each corridor has >=70% coverage.
kk=collections.defaultdict(dict)
for r in hrs:kk[r['timestamp_local_hour']][r['area']]=r
match=[]
for k,p in sorted(kk.items()):
 if not {'A','B'}<=p.keys():continue
 a,b=p['A'],p['B']
 if int(a['passes_70pct_fcd_speed'])!=1 or int(b['passes_70pct_fcd_speed'])!=1:continue
 match.append({'date_hour':k,'date_local':a['date_local'],'month':a['month'],'hour':a['hour_local'],
  'deficit_A_minus_B_pp':round(100*(float(a['mean_node_speed_deficit'])-float(b['mean_node_speed_deficit'])),4),
  'A_rain_mm_h':a['ERA5_precip_mm_hour'],'B_rain_mm_h':b['ERA5_precip_mm_hour'],
  'warning':'A/B different roadway mix; within-node normalization not causal equivalent'})
save('14_matched_AB_hour_24h.csv',match)

# A valid speed hours when wet vs dry; missingness diagnostic
coverage=[]
for area in ('A','B'):
 for wet in (0,1):
  q=[r for r in hrs if r['area']==area and int(r['wet_ge_0p1mm'])==wet]
  coverage.append({'area':area,'wet':wet,'hours':len(q),'share_hours_passing_70pct':round(sum(int(r['passes_70pct_fcd_speed']) for r in q)/len(q),6),
  'average_fcd_positive_speed_share':round(float(np.mean([float(r['fcd_positive_speed_coverage']) for r in q])),6),
  'note':'The wet/dry coverage difference may bias complete-case analysis'})
save('15_coverage_by_wet_dry_24h.csv',coverage)

# Three figures: 24-hour relative deficit; coverage; rain gust histogram simple
byh=load('02_AB_hour_of_day_24h.csv');bym=load('05_AB_month_all_day.csv')
for area in ('A','B'):
 q=sorted([r for r in byh if r['area']==area],key=lambda x:int(x['hour_local']))
 hh=[int(x['hour_local']) for x in q]
 defic=[100*float(x['mean_node_speed_deficit_eligible']) for x in q]
 cov=[100*float(x['traffic_hour_eligible_fraction']) for x in q]
 fig,ax=plt.subplots(figsize=(10,4.6))
 ax.plot(hh,defic,marker='o');ax.set_xlim(0,23);ax.set_xticks(range(0,24,2))
 ax.set_xlabel('Local hour (UTC+08:00)');ax.set_ylabel('Mean normalized FCD speed deficit (%)')
 ax.set_title(f'Causeway' if area=='A' else 'Second Link');ax.grid(alpha=.25)
 fig.tight_layout();fig.savefig(OUT/f'FIG_Area_{area}_24h_speed_deficit.png',dpi=170,bbox_inches='tight');plt.close(fig)
 fig,ax=plt.subplots(figsize=(10,4.6))
 ax.plot(hh,cov,marker='o');ax.set_ylim(0,105);ax.set_xlim(0,23);ax.set_xticks(range(0,24,2));ax.grid(alpha=.25)
 ax.set_xlabel('Local hour (UTC+08:00)');ax.set_ylabel('Hours passing >=70% valid FCD nodes (%)')
 ax.set_title(f'Hour-specific transport observation coverage — area {area}')
 fig.tight_layout();fig.savefig(OUT/f'FIG_Area_{area}_24h_data_coverage.png',dpi=170,bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(figsize=(10,4.5))
for a in ('A','B'):
 q=sorted([r for r in bym if r['area']==a],key=lambda x:int(x['month']))
 ax.plot([int(x['month']) for x in q],[100*float(x['mean_node_speed_deficit_eligible']) for x in q],marker='o',label=a)
ax.set_xlabel('2026 month');ax.set_ylabel('Average node-relative speed deficit (%)');ax.grid(alpha=.25);ax.legend()
ax.set_title('Full-day May–September FCD speed deficit (weather-aligned)')
fig.tight_layout();fig.savefig(OUT/'FIG_AB_month_24h_deficit.png',dpi=170,bbox_inches='tight');plt.close(fig)

findings={'hourly_by_area':{},'association':association,'paired_daypart':effects,'coverage':coverage,'matched_area_hours':len(match)}
for a in ('A','B'):
 q=[r for r in byh if r['area']==a]
 d=[r for r in q if r['mean_node_speed_deficit_eligible']!='']
 hi=max(d,key=lambda r:float(r['mean_node_speed_deficit_eligible']))
 lo=min(d,key=lambda r:float(r['mean_node_speed_deficit_eligible']))
 findings['hourly_by_area'][a]={'highest_deficit_hour':hi['hour_local'],'highest_deficit_fraction':hi['mean_node_speed_deficit_eligible'],
  'lowest_deficit_hour':lo['hour_local'],'lowest_deficit_fraction':lo['mean_node_speed_deficit_eligible'],
  'n_eligible_corridor_hours':sum(int(r['passes_70pct_fcd_speed']) for r in hrs if r['area']==a)}
(OUT/'16_findings_24h.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'areas':findings['hourly_by_area'],'primary_association':[{'area':r['area'],'term':r['term'],'coef_pp':r['coefficient_speed_deficit_percentage_points'],'p_holm':r['p_Holm_primary_holdout_only']} for r in primary], 'matched_hours':len(match),'pair_effects':[x for x in effects if x['split']=='holdout_AugSep']},ensure_ascii=False,indent=2))
