"""Research-grade historical weather harvesting and audit utilities."""
