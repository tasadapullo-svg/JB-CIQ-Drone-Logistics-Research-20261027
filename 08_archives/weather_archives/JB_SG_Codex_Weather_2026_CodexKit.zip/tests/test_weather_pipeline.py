import sys
import tempfile
import unittest
from pathlib import Path
from datetime import timedelta

import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from weather_pipeline.download_weather import (
    month_bounds_local, local_window_month, nea_reading_rows, normalize_nea_rows,
    build_nea_30min, build_nea_wide, build_hourly_master, make_hourly_comparison,
    write_xlsx, get_era5, get_nasa, LOCAL_TZ,
)

class FakeFetcher:
    def __init__(self, response): self.response = response
    def get_json(self, *a, **kw): return self.response


class WeatherTests(unittest.TestCase):
    def setUp(self):
        self.points = pd.DataFrame([
            dict(point_id='CW_MY', corridor='Causeway', country='MY', latitude=1.46502, longitude=103.76663),
            dict(point_id='CW_SG', corridor='Causeway', country='SG', latitude=1.44681, longitude=103.76919),
        ])

    def test_calendar(self):
        self.assertEqual(len(local_window_month(2026, 5, 'h')), 744)
        self.assertEqual(len(local_window_month(2026, 5, '30min')), 1488)
        self.assertEqual(len(local_window_month(2026, 6, 'h')), 720)

    def test_nea_parse(self):
        payload = {"code":0,"data":{"stations":[{"id":"S100", "name":"Test", "location":{"latitude":1.45, "longitude":103.77}}],
        "readings":[{"timestamp":"2026-05-01T00:05:00+08:00","data":[{"stationId":"S100","value":4.5}]}],"readingUnit":"mm"}}
        rows, meta = nea_reading_rows(payload, 'rainfall')
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['value_raw'],4.5)
        self.assertEqual(meta['S100']['station_name'], 'Test')

    def test_rain_30m_bin_and_wind_not_gust(self):
        readings = [{'kind':'rainfall','station_id':'S100',
                     'timestamp_raw':f'2026-05-01T00:{i:02d}:00+08:00',
                     'value_raw':0.2, 'reading_type':'', 'reading_unit':'mm'} for i in [5,10,15,20,25,30]]
        raw = normalize_nea_rows(readings)
        s = pd.DataFrame([{'point_id':'CW_SG', 'corridor':'Causeway', 'kind':'rainfall',
                           'station_id':'S100', 'distance_km':2}])
        half, _ = build_nea_30min(raw, s, 2026, 5)
        self.assertEqual(half.iloc[0]['sample_n'], 6)
        self.assertAlmostEqual(half.iloc[0]['rain_30min_mm'], 1.2)
        self.assertTrue(pd.isna(half.iloc[1]['rain_30min_mm']))
        wide = build_nea_wide(5,self.points,half)
        self.assertEqual(len(wide),1488)
        self.assertAlmostEqual(wide.iloc[0]['rain_30min_mm'],1.2)

    def test_era5_preceding_hour(self):
        data = {'hourly': {'time':['2026-05-01T00:00','2026-05-01T01:00'],
                  'precipitation':[0.5,2.3], 'wind_speed_10m':[1.0,3.0]}}
        er = get_era5(FakeFetcher(data),5,self.points.iloc[0])
        self.assertEqual(str(er.iloc[0]['rain_period_start_sgt'].hour), '7')
        self.assertEqual(str(er.iloc[0]['timestamp_sgt'].hour), '8')
        self.assertEqual(er.iloc[0]['precipitation'],0.5)
        self.assertEqual(er.iloc[0]['source_class'],'REANALYSIS_ERA5_0.25DEG')

    def test_nasa_utc_time_start(self):
        payload={'properties':{'parameter':{'PRECTOTCORR':{'2026043016':2.0},
                            'WS10M':{'2026043016':4.0}}}}
        ns=get_nasa(FakeFetcher(payload),5,self.points.iloc[0])
        self.assertEqual(len(ns),1)
        self.assertEqual(ns.iloc[0]['timestamp_sgt'].hour,0)
        self.assertEqual(ns.iloc[0]['PRECTOTCORR'],2)
        self.assertTrue(pd.isna(ns.iloc[0]['WD10M']))

    def test_excel_outputs(self):
        with tempfile.TemporaryDirectory() as d:
            dest=Path(d)/'sample.xlsx'
            test_df=pd.DataFrame({'time':['2026-05-01 00:00'],'rain_mm':[1.2]})
            write_xlsx(dest,{'Weather_Hourly':test_df,'QC_Coverage':pd.DataFrame({'status':['DATA']})})
            self.assertGreater(dest.stat().st_size,4000)
            import zipfile
            with zipfile.ZipFile(dest) as z:
                self.assertIsNone(z.testzip())

if __name__=='__main__': unittest.main()
