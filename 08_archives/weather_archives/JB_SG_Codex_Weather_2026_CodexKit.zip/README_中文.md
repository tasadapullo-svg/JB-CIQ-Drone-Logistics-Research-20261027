# JB–Singapore 2026年5–9月历史气象数据采集工具

## 说明

本工具包是提供给本地Codex的**真实API下载程序**。压缩包里**没有**2026年5–9月已经下载好的历史气象观测值；需在联网的Windows电脑运行。离线单元测试不等于真实API已连通。

研究范围：Causeway与Second Link各取马来西亚侧/新加坡侧1个参考点（共4个点）。点位通过 `weather_pipeline/points.csv` 配置；**应按你已有的GIS冻结点位进一步修改**，坐标只是检查站附近的公开地图参考，不代表合法/可用航线。

### 数据来源区分

- Open-Meteo **ERA5**：再分析模型历史小时数据，能同时提供降雨、10m/100m风速风向和10m阵风估算；不是地面原位测量。
- **NASA POWER**：模型/卫星分析数据，小时降水、10m风速风向、温湿度；属于独立对照产品，但不等于独立气象站实测。不同产品可能共用基础观测。
- 新加坡 **NEA**：真实地面站点历史降雨及风观测，只覆盖新加坡侧；本站点风速属于**10分钟均值，逐分钟采样**，并非瞬时阵风。分开存储站点与口岸距离。
- 马来西亚侧原位实测需要METMalaysia官方数据单独申请；脚本不能把新加坡站点读数当作MY测站。

## 一、解压、放置

将压缩包中的：

```
weather_pipeline/           # 新增模块
  __init__.py
  download_weather.py
  points.csv
requirements-weather.txt    # 独立依赖，不覆盖requirements.txt
tests/                      # 离线单元测试
  test_weather_pipeline.py
CODEX_完整提示词.md
README_中文.md
```

复制到 `C:\Users\DELL\Desktop\20261019` 下，保留原有 `main.py`、`.venv`、`requirements.txt`、`figures/` 和其他论文资料。

## 二、PowerShell运行（你自己运行或给Codex执行）

```powershell
cd C:\Users\DELL\Desktop\20261019

# 使用现成虚拟环境。若不存在，请让Codex创建而不是覆盖已有环境。
.\.venv\Scripts\python.exe -m pip install -r requirements-weather.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -v

# 仅2026年5月先测试各API（NEA只抓第一日第一页，非完整月）
.\.venv\Scripts\python.exe weather_pipeline\download_weather.py --probe --months 5

# 推荐先抓稳定的逐小时ERA5+NASA，确保有真实风雨数值
.\.venv\Scripts\python.exe weather_pipeline\download_weather.py --months 5 --sources openmeteo,nasa

# 再取得5月NEA历史气象站观测，注意可能耗时并触发限流
.\.venv\Scripts\python.exe weather_pipeline\download_weather.py --months 5 --sources openmeteo,nasa,nea

# 完成5月核验后，再抓剩余4个月
.\.venv\Scripts\python.exe weather_pipeline\download_weather.py --months 6 7 8 9
```

没有 `.venv` 时，需先 `py -3 -m venv .venv` 并使用新环境。可选在当前PowerShell session设置NEA API Key：

```powershell
$env:DATAGOVSG_API_KEY = '你在data.gov.sg申请的个人密钥'
```

**禁止把Key提交到Git或发给ChatGPT。** 没有Key也可低速访问公开接口，但限流严格。

## 三、输出

`data/weather_2026/processed/JB_SG_Weather_2026_05.xlsx` 等5个逐月文件；下载日志、原始压缩JSON和QC CSV保存在 `data/weather_2026/`。只要原始缓存存在，重复运行将复用已成功的数据；添加 `--refresh` 可强制重新查询。

## 四、在论文中必须解释的时序差异

1. `timezone=UTC`的ERA5时刻`t`是风场对应的时刻，而`precipitation(t)`代表此前一小时 `[t-1h,t)` 的降雨累计。主表明确将降雨对齐到真实区间开始时刻。
2. NASA POWER `time-standard=UTC`的数据时刻标记对应每小时的开始，小时降水记录代表对应小时。
3. NEA rainfall API公开说明5分钟更新。脚本将每6个5分钟站点雨量读取值汇总为30分钟雨量；在正式发表前，应通过原始`readingType`/官方API说明复核每个数值是否对应过去5分钟累计以及端点归属。6个时段有任何缺测，脚本保持30分钟累计为缺失。
4. NEA风速单位knots，脚本换算m/s；因为是10分钟平均风速的逐分钟观测，所以`wind_10min_mean_samples_max_ms`只能解释为“这一半小时内已报告的10分钟均值最大值”，**不是瞬时阵风**。
5. 风向采用圆统计均值，不做普通算术平均。
6. 默认NEA站点最大匹配距离15km，站点ID与距离有留档；这不是现场口岸实测。

## 五、检验文件是否真实有数据

查看每月文件的 `QC_Coverage`：`observed_valid_slots>0`说明对应变量确有数值，`NOT_FETCHED_OR_EMPTY`代表缺失或失败，`NOT_REQUESTED`表示没有勾选该来源。查看`API_Log`及磁盘`api_log.csv`，每个实际下载的JSON有SHA256校验。**仅有“时间索引行数正确”不能证明天气已下载成功。**

## 六、官方来源

- ERA5: https://open-meteo.com/en/docs/historical-weather-api
- NASA POWER: https://power.larc.nasa.gov/docs/services/api/temporal/hourly/
- NEA: https://guide.data.gov.sg/developer-guide/real-time-apis
- NEA wind 10min avg: https://data.gov.sg/datasets/d_7677738484067741bf3b56ab5d69c7e9/view
- Singapore rainfall: https://data.gov.sg/datasets/d_6580738cdd7db79374ed3152159fbd69/view

## 七、已知限制与需让Codex实际排查

- 本工具包**没有在本对话环境完成联网API实测**：本环境无法连接下载服务器，因此源码实际运行后的HTTP结果必须由你的本地Codex确认。
- NEA 2026年所有日期是否均返回完整历史页，需要运行后实际统计；数据站点停机/缺测不视为0。
- METMalaysia实测数据不在这三个开放API里；未来拿到原始资料后新增独立导入模块。
- 使用正统论文表述：`observed`(NEA站点)、`reanalysis`(ERA5)、`analysis/estimate`(NASA POWER)，不能全部笼统写成ground-truth observations。
