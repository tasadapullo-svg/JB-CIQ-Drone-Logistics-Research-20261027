import pandas as pd,networkx as nx,os,json
from pyproj import Transformer
from scipy.spatial import cKDTree
from shapely.geometry import Point,LineString
from shapely.strtree import STRtree
import numpy as np
base='/mnt/data/E02_independent_QA/JB_CIQ_E02_roadnet_V4_6/outputs'
T=Transformer.from_crs('EPSG:4326','EPSG:32648',always_xy=True)
final=[]
for a in 'AB':
 e=pd.read_csv(f'{base}/E02_{a}_directed_edges_OSM.csv')
 n=pd.read_csv(f'{base}/E02_{a}_road_graph_nodes.csv')
 s=pd.read_csv(f'{base}/E02_{a}_site_nearest_road_nodes_UNVERIFIED.csv')
 fcd=pd.read_csv(f'{base}/E02_{a}_FCD_to_OSM_edge_CANDIDATES_NOT_APPROVED.csv')
 G=nx.DiGraph(); G.add_edges_from(zip(e.source,e.target))
 X=dict(zip(n.osm_node_id,zip(n.longitude,n.latitude)))
 W=list(nx.weakly_connected_components(G)); comp={x:i for i,g in enumerate(W) for x in g}; compsizes={i:len(g) for i,g in enumerate(W)}
 print(a, 'components largest',sorted([len(g) for g in W],reverse=True)[:5])
 for r in s.itertuples():
  node=int(r.nearest_osm_node_id)
  d={'area':a,'site_id':r.point_id,'nearest_vertex_m':r.nearest_node_distance_m,'nearest_node_degree_out':G.out_degree(node),'nearest_node_degree_in':G.in_degree(node),'weak_component_size':compsizes[comp[node]],'weak_component_id':comp[node]}
  final.append(d)
 print(pd.DataFrame(final).loc[lambda x:x.area==a].to_string(index=False))
 # snap nearest edge by first identify 500 vertex candidates within 400 m then inspect incident edge geometries rather than all ~280k geoms
 ids=n.osm_node_id.to_numpy();xy=np.asarray(T.transform(n.longitude.to_numpy(),n.latitude.to_numpy())).T
 kd=cKDTree(xy); edges_by_node={}
 for i,(u,v) in enumerate(zip(e.source,e.target)):
  edges_by_node.setdefault(u,[]).append(i);edges_by_node.setdefault(v,[]).append(i)
 for r in s.itertuples():
  if r.nearest_node_distance_m<100 and r.point_id != 'A05': continue
  original=pd.read_csv('/mnt/data/E02_independent_QA/JB_CIQ_E02_roadnet_V4_6/inputs/19_site_reference_anchors_NOT_LAUNCH_PADS.csv')
  row=original.loc[original.site_id==r.point_id].iloc[0]
  xx=T.transform(row.longitude,row.latitude)
  nearby=kd.query_ball_point(xx,r=500)
  idx=set()
  for i in nearby: idx.update(edges_by_node.get(ids[i],[]))
  pp=Point(*xx)
  opts=[]
  for j in idx:
   ee=e.iloc[j];u,v=int(ee.source),int(ee.target)
   L=LineString([T.transform(*X[u]),T.transform(*X[v])])
   dist=pp.distance(L)
   opts.append((round(dist,2),int(ee.osm_way_id),ee.highway,str(ee.osm_name),compsizes[comp[u]], u, v))
  opts.sort()
  print('NEAREST EDGES',a,r.point_id,'vertex_dist',r.nearest_node_distance_m, 'sample',opts[:8])
  nearbest=opts[0] if opts else None
  for d in final:
   if d['area']==a and d['site_id']==r.point_id:
    d['nearest_edge_m']=nearbest[0] if nearbest else None;d['nearest_edge_road']=nearbest[3] if nearbest else None
pd.DataFrame(final).to_csv('/mnt/data/E02_independent_QA/site_snap_and_graph_components.csv',index=False)
