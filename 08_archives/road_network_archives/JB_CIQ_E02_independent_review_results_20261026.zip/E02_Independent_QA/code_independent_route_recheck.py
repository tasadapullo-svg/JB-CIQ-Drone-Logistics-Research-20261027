import os,hashlib,sys,json,glob,math,time
import pandas as pd,numpy as np,networkx as nx
from collections import Counter
base='/mnt/data/E02_independent_QA/JB_CIQ_E02_roadnet_V4_6'
out='/mnt/data/E02_independent_QA'
results={'files':{},'areas':{}}
for area in ['A','B']:
 meta=json.load(open(f'{base}/outputs/OSM_{area}_download_metadata.json'))
 raw=f'{base}/outputs/OSM_{area}_overpass_response.json'
 hh=hashlib.sha256(open(raw,'rb').read()).hexdigest()
 edge=pd.read_csv(f'{base}/outputs/E02_{area}_directed_edges_OSM.csv',encoding='utf-8-sig')
 nodes=pd.read_csv(f'{base}/outputs/E02_{area}_road_graph_nodes.csv',encoding='utf-8-sig')
 fcd=pd.read_csv(f'{base}/outputs/E02_{area}_FCD_to_OSM_edge_CANDIDATES_NOT_APPROVED.csv',encoding='utf-8-sig')
 od=pd.read_csv(f'{base}/outputs/E02_{area}_OD_OSM_MODEL_NOT_OBSERVED.csv',encoding='utf-8-sig')
 snap=pd.read_csv(f'{base}/outputs/E02_{area}_site_nearest_road_nodes_UNVERIFIED.csv',encoding='utf-8-sig')
 n_snap=pd.read_csv(f'{base}/outputs/E02_{area}_FCD_nearest_road_nodes_UNVERIFIED.csv',encoding='utf-8-sig')
 s={
  'raw_hash_ok': hh==meta['sha256'],'raw_elements':meta['elements'],
  'edge_count':len(edge),'nodes':len(nodes),
  'edge_negative_zero_length':int((edge.length_m<=0).sum()),
  'edge_invalid_speed':int((edge.speed_kmh<=0).sum()),
  'edge_endpoints_missing':int((~edge.source.isin(nodes.osm_node_id)|~edge.target.isin(nodes.osm_node_id)).sum()),
  'edge_exact_dupes':int(edge.duplicated().sum()),
  'tagged_speed_edges':int((edge.speed_source=='OSM_TAG').sum()),
  'assumed_speed_edges':int((edge.speed_source=='CLASS_ASSUMPTION').sum()),
  'od_pairs':len(od), 'od_status':od.status.value_counts().to_dict(),
  'od_model_minmax_mins':od.OSM_only_minutes_MODEL.agg(['min','median','max']).round(3).to_dict(),
  'od_model_circuity_quantiles':od.circuity_ratio.quantile([.5,.9,1]).round(3).to_dict(),
  'od_model_circuity_gt3':int((od.circuity_ratio>3).sum()),
  'od_model_circuity_gt5':int((od.circuity_ratio>5).sum(),),
  'od_travel_time_missing':int(od.OSM_only_minutes_MODEL.isna().sum()),
  'od_beeline_gt_route_length':int(((od.route_length_km+0.0001)<od.beeline_km).sum()),
  'od_origin_gt100m':int((od.snap_origin_m>100).sum()),
  'od_dest_gt100m':int((od.snap_destination_m>100).sum()),
  'fcd':len(fcd),'fcd_approved':int((fcd.match_approved.astype(str).str.lower()=='true').sum()),
  'fcd_spatial_distance_q95':float(fcd.match_distance_m.quantile(.95)),
  'fcd_evidence_status':fcd.frozen_road_name_evidence.value_counts().to_dict(),
  'fcd_nearest_road_name_missing':int(fcd.nearest_osm_road_name.isna().sum()),
  'fcd_road_candidate_gt30m':int((fcd.match_distance_m>30).sum()),
  'site_snaps_gt100m':int((snap.nearest_node_distance_m>100).sum()),
  'site_snaps_max':float(snap.nearest_node_distance_m.max()),
  'unique_site_count':len(snap),
  'osm_SG_named_road_edges':int(edge.osm_name.fillna('').str.contains('Bukit Timah|Kranji|Woodlands|Tuas|Singapore|SLE|BKE|PIE',case=False,regex=True).sum()),
  'OSM_road_classes':edge.highway.value_counts().to_dict(),
 }
 results['areas'][area]=s
 print('AREA',area,json.dumps({k:v for k,v in s.items() if k not in ('OSM_road_classes',)},ensure_ascii=False,indent=1))
 # Full directed graph derived only from provided edge CSV, recompute shortest path for each OD with full orientation and assumptions
 G=nx.DiGraph()
 for x in edge.itertuples(index=False):
  sec=float(x.length_m)/1000/float(x.speed_kmh)*60
  if not G.has_edge(int(x.source),int(x.target)) or sec<G[int(x.source)][int(x.target)]['weight']:
   G.add_edge(int(x.source),int(x.target),weight=sec,length=float(x.length_m),name=x.osm_name)
 print('GRAPH BUILT',G.number_of_nodes(),G.number_of_edges(),flush=True)
 assert len(nodes)==len(G.nodes)
 idx={v.point_id:int(v.nearest_osm_node_id) for v in snap.itertuples(index=False)}
 # single source dijkstra for efficiency
 recompute=[]
 for origin in sorted(od.origin_id.unique()):
  dist,paths=nx.single_source_dijkstra(G,idx[origin],weight='weight')
  for r in od.loc[od.origin_id==origin].itertuples(index=False):
   dest=idx[r.destination_id]; destsnap=r.snap_destination_m; originsnap=r.snap_origin_m
   if originsnap>100 or destsnap>100:
    status='SNAP_REVIEW_REQUIRED';tm=float('nan');length=float('nan');names=[]
   elif dest not in dist:
    status='DISCONNECTED_IN_OSM';tm=float('nan');length=float('nan');names=[]
   else:
    path=paths[dest];tm=dist[dest];length=sum(G[u][v]['length'] for u,v in zip(path,path[1:]))/1000;status='MODEL_ROUTE_REQUIRES_QA';names=[G[u][v]['name'] for u,v in zip(path,path[1:])];
   has_sg=sum(any(token in str(n).lower() for token in ['bukit timah','kranji','woodlands','singapore','tuas','mandai','seletar']) for n in names)
   recompute.append(dict(area=area,origin_id=r.origin_id,destination_id=r.destination_id,reported_status=r.status,recomputed_status=status,
          reported_min=r.OSM_only_minutes_MODEL,recomputed_min=round(tm,4) if not math.isnan(tm) else np.nan,
          reported_length_km=r.route_length_km,recomputed_length_km=round(length,4) if not math.isnan(length) else np.nan,
          singapore_named_path_edge_count=has_sg,problem_name_examples=';'.join(list(dict.fromkeys(str(x) for x in names if any(k in str(x).lower() for k in ['bukit timah','kranji','woodlands','tuas']))))[:150],
          snap_origin_m=originsnap,snap_destination_m=destsnap))
 match=pd.DataFrame(recompute)
 match['time_diff']=np.abs(match.reported_min-match.recomputed_min)
 match['length_diff']=np.abs(match.reported_length_km-match.recomputed_length_km)
 s['route_recompute_status_mismatch']=int((match.reported_status!=match.recomputed_status).sum())
 s['route_recompute_time_abs_max']=float(match.time_diff.max())
 s['route_recompute_length_abs_max']=float(match.length_diff.max())
 s['routes_using_SG_named_roads']=int((match.singapore_named_path_edge_count>0).sum())
 match.to_csv(f'{out}/OD_independent_recheck_{area}.csv',index=False)
 print('RECALCULATED',area,match[['reported_status','recomputed_status']].value_counts().to_dict(), 'mismatches',s['route_recompute_status_mismatch'],'max time error',s['route_recompute_time_abs_max'],'route SG names',s['routes_using_SG_named_roads'],flush=True)
# Totals and report
json.dump(results,open(f'{out}/audit_metrics.json','w'),indent=2,ensure_ascii=False)
print('DONE')
