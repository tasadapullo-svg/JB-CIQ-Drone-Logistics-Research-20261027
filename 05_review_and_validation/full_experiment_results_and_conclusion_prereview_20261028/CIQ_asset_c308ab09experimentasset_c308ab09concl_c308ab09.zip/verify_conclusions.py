#!/usr/bin/env python3
"""Read-only independent arithmetic checks over the archived G11/G12 exports.
Inputs: original G11 ZIP. No simulation is run, no parameters are changed.
"""
import zipfile,io,hashlib,json,os
from pathlib import Path
import pandas as pd, numpy as np
HERE=Path(__file__).resolve().parent
ZIP=Path('/mnt/data/CIQ_Stage7_G11_G12_联合不确定性_固定车种资源池_论文候选证据包_20261028.zip')
if not ZIP.exists():
 ZIP=HERE.parent/'CIQ_Stage7_G11_G12_联合不确定性_固定车种资源池_论文候选证据包_20261028.zip'
with zipfile.ZipFile(ZIP) as z:
 assert z.testzip() is None
 def frame(name):return pd.read_csv(io.BytesIO(z.read(name)))
 daily=frame('reference/G11_POOL_BASE/daily_runlevel.csv')
 pool=frame('outputs/g11_all_case_pooled.csv')
 r=frame('outputs/g12_conditional_candidate_register.csv')
 ci=frame('reference/G11_POOL_BASE/paired_ci_vs_M0.csv')
 assert len(pool)==96 and len(r)==12
 assert len(daily)==1800 and daily.groupby('configuration_id').size().eq(150).all()
 assert daily.seed.nunique()==30 and daily.date.nunique()==5
 assert daily.groupby(['seed','date','area']).input_orders.nunique().max()==1
 assert daily.groupby(['seed','date','area']).evaluable_orders.nunique().max()==1
 pre={'2026-05-15':(3.87,4.87),'2026-06-15':(3.72,4.67),'2026-07-15':(3.37,3.97),'2026-08-15':(3.62,4.47),'2026-09-15':(4.02,4.92)}
 daily['gas_price']=daily.date.map(lambda x:pre[x][0]);daily['diesel_price']=daily.date.map(lambda x:pre[x][1]);daily['fuel_cost']=daily.petrol_L*daily.gas_price+daily.diesel_L*daily.diesel_price
 daily['electric_cost']=daily.drone_grid_kwh*.50
 daily['nonfuel_cost']=daily.sum_cost_MYR-daily.fuel_cost-daily.electric_cost
 daily['recovered_co2']=daily.petrol_L*2.06916+daily.diesel_L*2.57082+daily.drone_grid_kwh*.74
 assert np.allclose(daily.recovered_co2,daily.sum_operational_CO2e_kg,atol=.005,rtol=0)
 rows=[]
 for conf,d in daily.groupby('configuration_id'):
  n=d.input_orders.sum();eva=d.evaluable_orders.sum();p=pool[(pool.case_id=='G11_POOL_BASE')&(pool.configuration_id==conf)].iloc[0]
  mean=d.sum_evaluable_time_min.sum()/eva;cost=d.sum_cost_MYR.sum()/n;co2=d.sum_operational_CO2e_kg.sum()/n
  assert np.allclose([mean,cost,co2],[p.mean_time_min,p.cost_MYR_per_input,p.op_kg_per_input],rtol=0,atol=1e-8)
  rows.append(dict(configuration_id=conf,area=conf[0],mode=p['mode'],input_orders=int(n),evaluable_orders=int(eva),coverage_pct=eva/n*100,
    mean_time_min=mean,cost_MYR_per_input=cost,op_kg_per_input=co2,sorties=int(d.flight_sorties.sum()),
    fuel_cost_MYR_per_input=d.fuel_cost.sum()/n,drone_electric_cost_MYR_per_input=d.electric_cost.sum()/n,
    nonfuel_cost_MYR_per_input=d.nonfuel_cost.sum()/n,nonfuel_share_pct=d.nonfuel_cost.sum()/d.sum_cost_MYR.sum()*100,
    petrol_CO2e_per_input=d.petrol_L.sum()*2.06916/n,diesel_CO2e_per_input=d.diesel_L.sum()*2.57082/n,
    drone_CO2e_per_input=d.drone_grid_kwh.sum()*.74/n))
 summary=pd.DataFrame(rows).sort_values('configuration_id').reset_index(drop=True)
 refs={a:summary[summary.configuration_id==a+'_M0_REF'].iloc[0] for a in ('A','B')}
 for f in ['mean_time_min','cost_MYR_per_input','op_kg_per_input']:
  summary['delta_'+f]=summary.apply(lambda x:x[f]-refs[x.area][f],axis=1)
  summary['pct_'+f]=summary.apply(lambda x:100*(x[f]/refs[x.area][f]-1),axis=1)
 out=HERE/'model_results_independently_reconciled.csv';summary.to_csv(out,index=False,encoding='utf-8-sig')
 check=summary[['configuration_id','nonfuel_share_pct','delta_mean_time_min','delta_cost_MYR_per_input','delta_op_kg_per_input']].copy()
 check.to_csv(HERE/'cost_emission_contrast.csv',index=False,encoding='utf-8-sig')
 cols=['configuration_id','strict_pareto','near1pct_non_dominated','emission_reduction_ge_5pct','time_reduction_ge_1pct','conditional_grade']
 r[cols].to_csv(HERE/'robustness_conditional_grades_verified.csv',index=False,encoding='utf-8-sig')
 ci.to_csv(HERE/'paired_seed_ci_G11_POOL_BASE.csv',index=False,encoding='utf-8-sig')
 manifest={'source_zip_file':ZIP.name,'source_sha256':hashlib.sha256(ZIP.read_bytes()).hexdigest(), 'source_crc':'PASS',
  'daily_units':len(daily),'unique_seeds':int(daily.seed.nunique()),'dates':sorted(daily.date.unique().tolist()),
  'configs':int(daily.configuration_id.nunique()), 'assertions':['same per-area cohort','archived pooled mean_time cost co2 exact','Scope 1 plus Scope 2 calculation matches','30 matched seeds x 5 dates per config'],
  'note':'Only G11_POOL_BASE daily accounting independently recalculated. Robustness grades copied and checked for source counts, not independent Monte Carlo rerun.'}
 (HERE/'audit_QA.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
 print('VERIFIED',json.dumps({k:manifest[k] for k in ['source_crc','daily_units','unique_seeds','configs']},ensure_ascii=False))
