# CIQ全文结论预审交付包

报告：`全文实验结果与结论预审报告.md`。

过程：`verify_conclusions.py`（只读原 G11 ZIP）、`model_results_independently_reconciled.csv`、`cost_emission_contrast.csv`、`robustness_conditional_grades_verified.csv`、`paired_seed_ci_G11_POOL_BASE.csv`、`结论逐条审核清单.csv`、`最小补实验与验收矩阵.csv`、`audit_QA.json`。

**非新实验：**没有对无人机/燃油车模型新增运行，本次是结果审计、公式复算与论文证据等级检查。

如要重跑 `verify_conclusions.py`，需将最新 G11 ZIP 与本包放在相同父目录或修改脚本中的输入路径。
